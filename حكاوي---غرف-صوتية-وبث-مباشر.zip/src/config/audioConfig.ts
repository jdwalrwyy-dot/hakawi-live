/**
 * إعدادات الصوت وخدمة البث الصوتي المباشر (Agora RTC Audio Settings)
 * معرّف تطبيق أجورا (Agora App ID) المعتمد لتشغيل المايكات والبث الصوتي تلقائياً
 */

export interface AgoraAudioConfig {
  appId: string;
  appCertificate: string;
  mode: 'live' | 'rtc';
  codec: 'vp8' | 'h264';
  channelProfile: 'live-broadcasting' | 'communication';
  audioProfile: 'music_standard' | 'speech_standard' | 'high_quality_stereo';
  autoSubscribeAudio: boolean;
  enableVolumeIndicator: boolean;
}

export const AGORA_CONFIG: AgoraAudioConfig = {
  // معرّف تطبيق أجورا الأساسي المباشر في الكود ليعمل المايك تلقائياً
  appId: (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_AGORA_APP_ID)
    ? (import.meta as any).env.VITE_AGORA_APP_ID
    : '311c0af3a0be443dbb41cba431f7adb9',

  // شهادة تطبيق أجورا (App Certificate) لتوليد رموز التوثيق والتشفير
  appCertificate: (typeof import.meta !== 'undefined' && (import.meta as any).env?.AGORA_APP_CERTIFICATE)
    ? (import.meta as any).env.AGORA_APP_CERTIFICATE
    : '66ceb133b08645babc8d30d673656015',

  // نمط البث الصوتي الحي
  mode: 'live',
  codec: 'vp8',
  channelProfile: 'live-broadcasting',

  // جودة الصوت الاحترافية للغرف الصوتية
  audioProfile: 'music_standard',
  autoSubscribeAudio: true,
  enableVolumeIndicator: true
};

export default AGORA_CONFIG;

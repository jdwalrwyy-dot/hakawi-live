import AgoraRTC, {
  IAgoraRTCClient,
  IMicrophoneAudioTrack,
  UID
} from 'agora-rtc-sdk-ng';
import { AGORA_CONFIG } from '../config/audioConfig';

export type AgoraVolumeCallback = (volumes: { uid: UID; level: number }[]) => void;
export type AgoraSpeakingCallback = (level: number, isSpeaking: boolean) => void;

class AgoraAudioService {
  private client: IAgoraRTCClient | null = null;
  private localAudioTrack: IMicrophoneAudioTrack | null = null;
  private currentChannel: string | null = null;
  private isJoined: boolean = false;
  private isPublishing: boolean = false;
  private currentUid: number | null = null;
  private volumeCallback: AgoraVolumeCallback | null = null;
  private localSpeakingCallback: AgoraSpeakingCallback | null = null;
  private appId: string = AGORA_CONFIG.appId;

  constructor() {
    // AgoraRTC config
    try {
      AgoraRTC.setLogLevel(1); // 1 = warning only
    } catch {}
  }

  public getAppId(): string {
    return this.appId;
  }

  public setAppId(newAppId: string) {
    if (newAppId && newAppId.trim()) {
      this.appId = newAppId.trim();
    }
  }

  private initClient(): IAgoraRTCClient {
    if (!this.client) {
      this.client = AgoraRTC.createClient({
        mode: AGORA_CONFIG.mode,
        codec: AGORA_CONFIG.codec
      });

      // Handle remote audio subscription
      this.client.on('user-published', async (user, mediaType) => {
        try {
          if (!this.client) return;
          await this.client.subscribe(user, mediaType);
          if (mediaType === 'audio' && user.audioTrack) {
            user.audioTrack.play();
          }
        } catch (err) {
          console.warn('[Agora] Failed to subscribe remote user:', err);
        }
      });

      this.client.on('user-unpublished', (user, mediaType) => {
        if (mediaType === 'audio' && user.audioTrack) {
          user.audioTrack.stop();
        }
      });

      // Enable volume indicator
      if (AGORA_CONFIG.enableVolumeIndicator) {
        this.client.enableAudioVolumeIndicator();
        this.client.on('volume-indicator', (volumes) => {
          if (this.volumeCallback) {
            this.volumeCallback(volumes);
          }

          // Local speaking check
          const localVol = volumes.find(v => v.uid === 0 || String(v.uid) === String(this.client?.uid));
          if (localVol && this.localSpeakingCallback) {
            const normalized = Math.min(100, Math.round(localVol.level * 100));
            this.localSpeakingCallback(normalized, normalized > 10);
          }
        });
      }
    }
    return this.client;
  }

  /**
   * Join an Agora Audio Room Channel
   */
  public async joinRoom(
    roomId: string,
    userId: string,
    role: 'host' | 'audience' = 'audience',
    token?: string | null
  ): Promise<{ success: boolean; error?: string }> {
    try {
      if (!this.appId) {
        return { success: false, error: 'معرّف تطبيق أجورا غير متوفر.' };
      }

      const client = this.initClient();

      if (this.isJoined && this.currentChannel === roomId) {
        await client.setClientRole(role);
        return { success: true };
      }

      if (this.isJoined) {
        await this.leaveRoom();
      }

      await client.setClientRole(role);
      
      // Use numeric hash or string for Agora UID
      const uid = parseInt(userId.replace(/\D/g, '').slice(0, 8), 10) || Math.floor(100000 + Math.random() * 900000);
      this.currentUid = uid;

      // Auto-fetch token from server generated with App Certificate if not provided
      let effectiveToken = token || null;
      if (!effectiveToken) {
        try {
          const res = await fetch('/api/agora/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              channelName: roomId,
              uid,
              role
            })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.token) {
              effectiveToken = data.token;
            }
          }
        } catch (tokenErr) {
          console.warn('[Agora] Token fetch fallback:', tokenErr);
        }
      }

      await client.join(this.appId, roomId, effectiveToken, uid);
      this.isJoined = true;
      this.currentChannel = roomId;

      return { success: true };
    } catch (err: any) {
      console.warn('[Agora] Join room error:', err);
      return {
        success: false,
        error: err.message || 'تعذر الاتصال بقناة الصوت عبر أجورا'
      };
    }
  }

  /**
   * Publish microphone audio track to the channel (Taking a Mic)
   */
  public async publishMicrophone(
    onSpeaking?: AgoraSpeakingCallback
  ): Promise<{ success: boolean; track?: IMicrophoneAudioTrack; error?: string }> {
    try {
      if (!this.client || !this.isJoined) {
        return { success: false, error: 'يجب الانضمام إلى الغرفة الصوتية أولاً.' };
      }

      // Switch to host role
      await this.client.setClientRole('host');

      // Renew token with publisher permissions if channel is active
      if (this.currentChannel && this.currentUid) {
        try {
          const res = await fetch('/api/agora/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              channelName: this.currentChannel,
              uid: this.currentUid,
              role: 'host'
            })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.token && this.client) {
              await this.client.renewToken(data.token);
            }
          }
        } catch {}
      }

      if (onSpeaking) {
        this.localSpeakingCallback = onSpeaking;
      }

      if (!this.localAudioTrack) {
        this.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack({
          encoderConfig: AGORA_CONFIG.audioProfile,
          AEC: true,
          ANS: true,
          AGC: true
        });
      }

      if (!this.isPublishing) {
        await this.client.publish([this.localAudioTrack]);
        this.isPublishing = true;
      }

      return { success: true, track: this.localAudioTrack };
    } catch (err: any) {
      console.warn('[Agora] Publish microphone error:', err);
      let errorMsg = 'تعذر تشغيل ونشر الميكروفون عبر أجورا.';
      if (err.name === 'NotAllowedError' || err.code === 'PERMISSION_DENIED') {
        errorMsg = 'تم رفض إذن الميكروفون. يرجى السماح بالوصول في المتصفح.';
      }
      return { success: false, error: errorMsg };
    }
  }

  /**
   * Mute or Unmute the local microphone track
   */
  public async setMuted(muted: boolean): Promise<boolean> {
    try {
      if (this.localAudioTrack) {
        await this.localAudioTrack.setEnabled(!muted);
        return true;
      }
      return false;
    } catch (err) {
      console.warn('[Agora] Set muted error:', err);
      return false;
    }
  }

  /**
   * Unpublish and stop microphone (Leaving the Mic)
   */
  public async unpublishMicrophone(): Promise<void> {
    try {
      if (this.client && this.isPublishing && this.localAudioTrack) {
        await this.client.unpublish([this.localAudioTrack]);
        this.isPublishing = false;
      }
      if (this.localAudioTrack) {
        this.localAudioTrack.stop();
        this.localAudioTrack.close();
        this.localAudioTrack = null;
      }
      if (this.client && this.isJoined) {
        await this.client.setClientRole('audience');
      }
    } catch (err) {
      console.warn('[Agora] Unpublish error:', err);
    }
  }

  /**
   * Leave room and clean up tracks
   */
  public async leaveRoom(): Promise<void> {
    try {
      await this.unpublishMicrophone();
      if (this.client && this.isJoined) {
        await this.client.leave();
      }
    } catch (err) {
      console.warn('[Agora] Leave error:', err);
    } finally {
      this.isJoined = false;
      this.currentChannel = null;
      this.localSpeakingCallback = null;
    }
  }

  public onVolumeIndicator(callback: AgoraVolumeCallback) {
    this.volumeCallback = callback;
  }
}

export const agoraAudioService = new AgoraAudioService();
export default agoraAudioService;

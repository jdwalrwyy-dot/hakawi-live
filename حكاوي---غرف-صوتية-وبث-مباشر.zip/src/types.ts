export type UserRole = 'USER' | 'HOST' | 'AGENT' | 'STAFF' | 'MODERATOR' | 'ADMIN' | 'OWNER';

export const SYSTEM_OWNER_EMAILS = [
  'jdwalrwyy@gmail.com',
  'waledwwwz41@gmail.com'
];

export function isUserOwner(user?: User | PublicUserProfile | null): boolean {
  if (!user) return false;
  if (user.role === 'OWNER' || user.isOwner === true || user.is_owner === true) return true;
  if (user.id === 'user_admin' || user.id === 'user_owner_waled' || user.id === 'user_1788450708278_wtpv') return true;
  const username = user.username?.toLowerCase();
  if (username === 'jdwalrwyy' || username === 'waledwwwz41' || username === 'waled') return true;
  if ('email' in user && user.email) {
    const email = user.email.toLowerCase();
    if (SYSTEM_OWNER_EMAILS.some(e => e.toLowerCase() === email)) return true;
  }
  return false;
}

export interface DeviceSavedAccount {
  id: string;
  numericId?: string;
  name: string;
  username: string;
  avatar: string;
  role: UserRole;
  isOwner?: boolean;
  ownerToken?: string;
  level?: number;
  diamonds: number;
  coins: number;
  phone?: string;
  email?: string;
  lastUsedAt: string;
}

export interface User {
  id: string;
  numericId?: string;
  isVipNumericId?: boolean;
  name: string;
  username: string;
  avatar: string;
  gender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  isVerified?: boolean;
  verifiedGender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  verificationPhoto?: string;
  livenessFrontPhoto?: string;
  livenessRightPhoto?: string;
  livenessLeftPhoto?: string;
  verifiedAt?: string;
  phone?: string;
  email?: string;
  googleId?: string;
  facebookId?: string;
  bio?: string;
  level: number;
  exp: number;
  coins: number;
  diamonds: number;
  role: UserRole;
  isOwner?: boolean;
  is_owner?: boolean;
  canRecharge?: boolean;
  followersCount: number;
  followingCount: number;
  friendsCount: number;
  activeFrameId?: string;
  customFrameUrl?: string | null;
  activeEntranceId?: string;
  referralCode: string;
  referredBy?: string;
  isBanned?: boolean;
  status?: 'active' | 'banned' | string;
  banReason?: string;
  violationCount?: number;
  temporaryBanUntil?: number | null;
  temporaryBanType?: '15m' | '1h' | '2h' | 'pending_admin_review' | 'perm';
  isPendingAdminReview?: boolean;
  isFrozen?: boolean;
  createdAt: string;
  isOnline?: boolean;
  isStealthMode?: boolean;
}

export interface StorePackage {
  id: string;
  priceUsd: number;
  approxEgp: number;
  coins: number;
  label: string;
}

export const OFFICIAL_COIN_PACKAGES: StorePackage[] = [
  { id: 'coin_pkg_50k', priceUsd: 3.99, approxEgp: 200, coins: 50000, label: '50,000 كوينز' },
  { id: 'coin_pkg_100k', priceUsd: 7.99, approxEgp: 400, coins: 100000, label: '100,000 كوينز' },
  { id: 'coin_pkg_250k', priceUsd: 19.99, approxEgp: 1000, coins: 250000, label: '250,000 كوينز' },
  { id: 'coin_pkg_500k', priceUsd: 39.99, approxEgp: 2000, coins: 500000, label: '500,000 كوينز' },
  { id: 'coin_pkg_1m', priceUsd: 79.99, approxEgp: 4000, coins: 1000000, label: '1,000,000 كوينز' },
  { id: 'coin_pkg_2.5m', priceUsd: 199.99, approxEgp: 10000, coins: 2500000, label: '2,500,000 كوينز' }
];

// منطق تحويل الهدايا (كل 5 كوينز = 1 ماسة)
export function sendGift(
  sender: { coins: number },
  receiver: { diamonds: number },
  giftCostInCoins: number
): { success: boolean; message?: string; earnedDiamonds?: number } {
  if (sender.coins < giftCostInCoins) {
    return { success: false, message: "رصيد الكوينز لا يكفي" };
  }
  
  sender.coins -= giftCostInCoins;
  const earnedDiamonds = Math.floor(giftCostInCoins / 5);
  receiver.diamonds += earnedDiamonds;
  
  return { success: true, earnedDiamonds: earnedDiamonds };
}

export interface PublicUserProfile {
  id: string;
  numericId?: string;
  isVipNumericId?: boolean;
  name: string;
  username: string;
  avatar: string;
  gender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  isVerified?: boolean;
  verifiedGender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  verificationPhoto?: string;
  verifiedAt?: string;
  email?: string;
  bio?: string;
  level: number;
  exp?: number;
  role: UserRole;
  isOwner?: boolean;
  is_owner?: boolean;
  followersCount: number;
  followingCount: number;
  friendsCount: number;
  activeFrameId?: string;
  activeEntranceId?: string;
  referralCode?: string;
  createdAt: string;
  isOnline?: boolean;
  isFollowing?: boolean;
  friendshipStatus?: 'NONE' | 'PENDING' | 'ACCEPTED';
  currentRoomRole?: RoomRole | 'HOST';
  currentSeatIndex?: number | null;
  isMutedInRoom?: boolean;
  isSpeakingInRoom?: boolean;
}

export type RoomType = 'PUBLIC' | 'PRIVATE';
export type RoomStatus = 'LIVE' | 'WAITING' | 'ENDED';
export type RoomRole = 'HOST' | 'MODERATOR' | 'SPEAKER' | 'LISTENER';
export type MicLayoutType = '2+10' | '10' | '15' | '2+15' | '2+20' | '2+25' | '22' | '27' | '5' | '8' | '4' | '12' | 'auto';

export interface Room {
  id: string;
  roomCode: string;
  title: string;
  description: string;
  coverImage: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostFrameId?: string;
  type: RoomType;
  roomType?: 'audio' | 'video' | 'mixed';
  password?: string;
  status: RoomStatus;
  allowAudio: boolean;
  allowVideo: boolean;
  viewerCount: number;
  currentCategory: string;
  createdAt: string;
  tags: string[];
  endedAt?: string;
  micLayout?: MicLayoutType;
  seatsCount?: number;
  requireHostApproval?: boolean;
}

export interface RoomMember {
  roomId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userGender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  userFrameId?: string;
  userEntranceId?: string;
  roleInRoom: RoomRole;
  isMuted: boolean;
  isCameraOn: boolean;
  isSpeaking: boolean;
  isStealth?: boolean;
  joinedAt: string;
}

export interface RoomSeat {
  seatIndex: number; // 0 to N
  userId: string | null;
  userName?: string;
  userAvatar?: string;
  userGender?: 'male' | 'female' | 'MALE' | 'FEMALE';
  userFrameId?: string;
  isMuted: boolean;
  isCameraOn: boolean;
  isSpeaking: boolean;
  isLocked: boolean;
  isHostSeat: boolean;
  isVipSeat?: boolean;
  seatLabel?: string;
  customFrameUrl?: string | null;
}

export interface MicRequest {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userFrameId?: string;
  customFrameUrl?: string | null;
  userRole?: string;
  targetSeatIndex?: number;
  seatLabel?: string;
  requestedAt: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'CANCELLED';
}

export interface RoomMessage {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userFrameId?: string;
  userRole: UserRole;
  text: string;
  createdAt: string;
  isModerated?: boolean;
  giftData?: {
    giftId: string;
    giftName: string;
    giftIcon: string;
    count: number;
    receiverName: string;
  };
}

export type OfficialMessageTarget = 'ALL' | 'HOSTS' | 'AGENTS' | 'STAFF' | 'ADMINS' | 'USER_SPECIFIC';

export interface OfficialHekawyMessage {
  id: string;
  senderId: 'HEKAWY_OFFICIAL';
  senderName: string; // 'حكاوي'
  senderAvatar: string;
  targetCategory: OfficialMessageTarget;
  targetCategoryLabel: string;
  receiverId: string;
  receiverName?: string;
  text: string;
  createdAt: string;
  read: boolean;
  isOfficial: true;
}

export interface PrivateMessage {
  id: string;
  senderId: string;
  receiverId: string;
  senderName?: string;
  senderAvatar?: string;
  text: string;
  createdAt: string;
  read: boolean;
  isOfficial?: boolean;
  targetCategory?: OfficialMessageTarget;
  targetCategoryLabel?: string;
}

export interface Friendship {
  id: string;
  user1Id: string;
  user2Id: string;
  status: 'PENDING' | 'ACCEPTED';
  requestedBy: string;
  createdAt: string;
  otherUser?: User;
}

export type GiftTierLevel = 'COMMON' | 'PRETTY' | 'LUXURY' | 'LEGENDARY' | 'VIP' | 'STANDARD' | 'FEATURED' | 'RARE';
export type GiftCategory = 'all' | 'common' | 'pretty' | 'luxury' | 'legendary' | 'vip';

export interface Gift {
  id: string;
  nameAr: string;
  icon: string;
  diamondCost: number;
  coinReward: number;
  animationType: string;
  soundKey: string;
  category: 'common' | 'pretty' | 'luxury' | 'legendary' | 'vip' | string;
  tierLevel?: GiftTierLevel;
  badge?: string;
  descriptionAr?: string;
  soundUrl?: string;
  isMuted?: boolean;
  displayScale?: number;
  displayDurationSec?: number;
}

export interface GiftTransaction {
  id: string;
  giftId: string;
  giftName: string;
  giftIcon: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  roomId?: string;
  count: number;
  totalDiamonds: number;
  createdAt: string;
  idempotencyKey?: string;
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: 'COIN' | 'DIAMOND';
  amount: number;
  newBalance: number;
  reason: string;
  createdAt: string;
}

export interface DailyTask {
  id: string;
  titleAr: string;
  descriptionAr?: string;
  rewardCoins: number;
  rewardExp: number;
  taskType: 'DAILY_LOGIN' | 'JOIN_ROOM' | 'STAY_10_MIN' | 'SEND_GIFT' | 'RECEIVE_GIFT' | 'INVITE_FRIEND' | 'SHARE_APP';
  requiredCount: number;
  progress: number;
  completed: boolean;
  claimed: boolean;
}

export interface TaskCompletionLog {
  id: string;
  userId: string;
  user_id?: string;
  taskId: string;
  task_id?: string;
  reward: number;
  completedAt: string;
  completed_at?: string;
  date: string;
}

export interface ReferralRecord {
  referral_id: string;
  referrer_user_id: string;
  referred_user_id: string;
  referral_code: string;
  status: 'COMPLETED' | 'REJECTED';
  reward_amount: number;
  created_at: string;
  completed_at: string;
  referredUserName?: string;
  referredUserAvatar?: string;
}

export interface ReferralStats {
  success: boolean;
  referralCode: string;
  shareUrl: string;
  successfulInvites: number;
  earnedCoins: number;
  history?: ReferralRecord[];
}

export interface Frame {
  id: string;
  nameAr: string;
  icon: string;
  imageUrl?: string;
  previewGradient: string;
  borderStyle: string;
  diamondPrice: number;
  coinPrice: number;
  isExclusiveOwner: boolean;
  descriptionAr: string;
  description?: string;
  category?: string;
  requiredLevel: number;
}

export type EntranceCategory = 'FREE' | 'VEHICLE' | 'AERIAL' | 'CREATURE' | 'MYTHIC' | 'OWNER' | '3D' | '5D' | string;
export type EntranceTier = 'COMMON' | 'LUXURY' | 'LEGENDARY' | 'ROYAL_VIP' | 'OWNER_EXCLUSIVE';
export type EntranceSoundType = 'jet' | 'supercar' | 'bike' | 'yacht' | 'falcon' | 'eagle' | 'dove' | 'steed' | 'helicopter' | 'space' | 'dragon' | 'sparkle' | 'royal_fanfare';

export interface Entrance {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  diamondPrice: number;
  category: EntranceCategory;
  tier: EntranceTier;
  durationSeconds: number;
  soundType: EntranceSoundType;
  isExclusiveOwner?: boolean;
  badgeLabel?: string;
  previewColor: string;
  isDisabled?: boolean;
}

export interface UserEntrance {
  id: string;
  userId: string;
  entranceId: string;
  acquiredAt: string;
}

export interface ReportDocument {
  reportId: string;
  reporterId: string;
  reportedUserId: string;
  reason: string;
  roomId?: string;
  details?: string;
  timestamp: number;
  status: 'pending' | 'reviewed' | 'banned' | 'PENDING' | 'RESOLVED' | 'DISMISSED';
}

export interface Report {
  id: string;
  reportId?: string;
  reporterId: string;
  reporterName?: string;
  reportedUserId?: string;
  targetType: 'USER' | 'ROOM' | 'MESSAGE' | 'STREAM';
  targetId: string;
  targetName?: string;
  reason: string;
  details: string;
  roomId?: string;
  timestamp?: number;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED' | 'pending' | 'reviewed' | 'banned';
  createdAt: string;
}

export interface Ban {
  id: string;
  userId: string;
  userName: string;
  bannedBy: string;
  reason: string;
  category?: string;
  mediaSnapshot?: string;
  isPermanent: boolean;
  expiresAt: string | null;
  createdAt: string;
}

export type ModerationCategory =
  | 'MALE_NUDITY'
  | 'UNDERWEAR_EXPOSURE'
  | 'GENITALIA_EXPOSURE'
  | 'SEXUAL_CONTENT'
  | 'EXCESSIVE_SKIN'
  | 'SUSPICIOUS_UNVERIFIED';

export type ModerationAction =
  | 'AUTO_BAN_PERMANENT'
  | 'QUEUED_FOR_REVIEW'
  | 'AUTO_BLUR_WARN'
  | 'ALLOWED'
  | 'TEMP_BAN_15M'
  | 'TEMP_BAN_1H'
  | 'TEMP_BAN_2H';

export interface ModerationIncident {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  userAvatar: string;
  targetType: 'AVATAR' | 'ROOM_COVER' | 'LIVE_STREAM' | 'CHAT_MEDIA' | 'VIDEO' | 'ROOM_TEXT';
  targetId?: string;
  reason: string;
  category: ModerationCategory;
  confidenceScore: number;
  status: 'BLOCKED_BANNED' | 'NEEDS_REVIEW' | 'APPROVED' | 'DISMISSED';
  actionTaken: ModerationAction;
  mediaSnapshot?: string;
  details?: string;
  detectedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface BannedIdentifier {
  id: string;
  type: 'USER_ID' | 'PHONE' | 'EMAIL' | 'GOOGLE_ID' | 'USERNAME';
  value: string;
  reason: string;
  bannedAt: string;
}

export interface AuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  mediaSnapshot?: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'MESSAGE' | 'FRIEND_REQUEST' | 'FRIEND_ACCEPT' | 'FOLLOW' | 'GIFT' | 'INVITE' | 'ROOM_JOIN' | 'ADMIN' | 'SYSTEM';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalRooms: number;
  liveRooms: number;
  totalLiveStreams: number;
  totalMessages: number;
  totalGiftsSent: number;
  totalTransactions: number;
  totalReports: number;
  totalDiamondsSpent: number;
  totalCoinsCirculating: number;
  totalAgencies?: number;
  totalHosts?: number;
  totalTargetAchieved?: number;
}

// --- HOSTS, AGENTS, AGENCIES & TARGETS SYSTEM ---

export type WithdrawalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface HostWithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userNumericId?: string;
  role: 'HOST' | 'AGENT' | 'USER' | UserRole;
  hostCode?: string;
  agencyName?: string;
  agencyCode?: string;

  // Monthly Target & Earnings Detailed Report
  monthPeriod: string; // e.g. "2026-09"
  targetAchievedDiamonds: number;
  targetAchievedTitle: string;
  targetLiveMinutes: number;
  targetActiveDays: number;

  // Wallet & Gift breakdown
  giftCoinsReceived: number;
  diamondsConverted: number;

  // Financial request details
  requestedDiamonds: number;
  requestedAmountUsdOrEgp: number;
  currency: 'USD' | 'EGP' | 'SAR';
  paymentMethod: string; // 'Vodafone Cash' | 'Instapay' | 'Bank Transfer' | 'USDT (TRC20)' | 'STC Pay' | 'Binance Pay'
  paymentAccountDetails: string;

  status: WithdrawalStatus;
  requestedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  reviewedByName?: string;
  rejectionReason?: string;
  transactionRef?: string;
}

export type HostApplicationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface HostApplication {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userUsername: string;
  phone: string;
  country?: string;
  experienceBio: string;
  specialTalent: string;
  sampleLink?: string;
  agentInviteCode?: string;
  agencyId?: string;
  agencyName?: string;
  agencyCode?: string;
  status: HostApplicationStatus;
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  hostCode?: string;
  createdAt: string;
}

export type AgentApplicationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface AgentApplication {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userUsername: string;
  agencyName: string;
  phone: string;
  country: string;
  expectedHostsCount: number;
  experienceBio: string;
  status: AgentApplicationStatus;
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  agencyCode?: string;
  createdAt: string;
}

export interface Agency {
  id: string;
  ownerUserId: string;
  ownerName: string;
  ownerAvatar: string;
  agencyName: string;
  agencyCode: string;
  inviteCode: string;
  status: 'ACTIVE' | 'SUSPENDED';
  contactPhone: string;
  country: string;
  hostsCount: number;
  activeHostsCount: number;
  totalDiamondsEarned: number;
  commissionPercentage: number;
  createdAt: string;
}

export interface HostAgencyRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userNumericId?: string;
  phone: string;
  agencyCode: string;
  agencyId: string;
  agencyName: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  createdAt: string;
  reviewedAt?: string;
}

export interface AgencyDispute {
  id: string;
  hostUserId: string;
  hostName: string;
  hostAvatar: string;
  hostNumericId?: string;
  phone?: string;
  agencyCode: string;
  agencyName: string;
  agencyOwnerUserId: string;
  agencyOwnerName: string;
  reason: string;
  status: 'PENDING' | 'FORCE_RELEASED' | 'REJECTED';
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

export interface HostProfile {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  hostCode: string;
  agencyId?: string;
  agencyName?: string;
  agencyCode?: string;
  status: 'ACTIVE' | 'SUSPENDED';
  category: string;
  bio: string;
  totalLiveMinutes: number;
  totalDiamondsReceived: number;
  totalValidDays: number;
  approvedAt: string;
  approvedBy: string;
}

export interface TargetConfig {
  id: string;
  title: string;
  period: 'MONTHLY' | 'WEEKLY';
  monthYear: string;
  requiredDiamonds: number;
  requiredLiveMinutes: number;
  requiredActiveDays: number;
  rewardCoins: number;
  rewardDiamonds: number;
  agentCommissionPct: number;
  isActive: boolean;
  createdAt: string;
}

export interface HostTargetProgress {
  hostId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  hostCode: string;
  agencyId?: string;
  agencyName?: string;
  agencyCode?: string;
  targetConfigId: string;
  targetTitle: string;
  period: 'MONTHLY' | 'WEEKLY';
  targetDiamonds: number;
  currentDiamonds: number;
  remainingDiamonds: number;
  targetLiveMinutes: number;
  currentLiveMinutes: number;
  targetActiveDays: number;
  currentActiveDays: number;
  progressPercentage: number;
  isAchieved: boolean;
  rewardClaimed: boolean;
  lastUpdated: string;
}

export interface AgencyDashboardData {
  agency: Agency;
  hosts: Array<{
    hostProfile: HostProfile;
    user: User;
    targetProgress: HostTargetProgress;
  }>;
  summary: {
    totalHosts: number;
    activeHosts: number;
    suspendedHosts: number;
    totalAgencyDiamonds: number;
    totalAgencyTargetDiamonds: number;
    averageCompletionRate: number;
    achievedTargetsCount: number;
  };
}

export interface HostDashboardData {
  hostProfile: HostProfile;
  agency?: Agency;
  targetProgress: HostTargetProgress;
  targetHistory: HostTargetProgress[];
  eligibleLiveHours: number;
  eligibleGiftsCount: number;
  accountStatus: 'PENDING' | 'APPROVED' | 'SUSPENDED' | 'NOT_APPLIED';
}

export interface GiftTierConfig {
  level: GiftTierLevel;
  nameAr: string;
  minDiamonds: number;
  maxDiamonds: number;
  hasSound: boolean;
  soundType: 'none' | 'common_chime' | 'pretty_crystal' | 'rare_chime' | 'luxury_fanfare' | 'legendary_grand' | 'vip_imperial';
  hasFullscreenAura: boolean;
  celebrationDurationMs: number;
  screenGlowColor: string;
  descriptionAr: string;
}

export interface SystemGiftTierSettings {
  tiers: GiftTierConfig[];
  globalSoundEnabled: boolean;
  bigGiftThreshold?: number;
  globalBannerEnabled?: boolean;
  globalBannerDurationMs?: number;
  lastUpdated?: string;
}

export interface VerifiedUserRecord {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userNumericId?: string;
  gender: 'male' | 'female' | 'MALE' | 'FEMALE';
  verificationPhoto: string;
  livenessFrontPhoto?: string;
  livenessRightPhoto?: string;
  livenessLeftPhoto?: string;
  verifiedAt: string;
  isVerified: boolean;
  revokedAt?: string;
  revokedBy?: string;
}

export interface LuckyWheelMatch {
  matchId: string;
  betAmount: number; // 100 | 10000 | 20000
  status: 'WAITING_FOR_OPPONENT' | 'SPINNING' | 'FINISHED';
  player1: {
    id: string;
    name: string;
    avatar: string;
    numericId?: string;
    isBot: boolean;
  };
  player2?: {
    id: string;
    name: string;
    avatar: string;
    numericId?: string;
    isBot: boolean;
  };
  winnerId?: string;
  winningAngle?: number;
  winnerPrize?: number;
  commissionDeducted?: number;
  createdAt: string;
  finishedAt?: string;
}

export interface LuckyFarmItem {
  id: string;
  nameAr: string;
  icon: string;
  group: 'fruit' | 'meat';
  multiplier: number;
}

export interface LuckyFarmWinner {
  userId: string;
  userName: string;
  userAvatar: string;
  winAmount: number;
  itemName: string;
  itemIcon: string;
  timestamp: string;
}

export interface LuckyFarmGlobalWinBanner {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  winAmount: number;
  itemName: string;
  itemIcon: string;
  timestamp: string;
}

export interface LuckyFarmRoundState {
  roundId: string;
  status: 'BETTING' | 'SPINNING' | 'RESULT';
  remainingSeconds: number;
  winningItemId: string | null;
  totalBetsPerItem: Record<string, number>;
  userBets: Record<string, number>; // itemId -> amount for current user
  recentWinners: LuckyFarmWinner[];
  latestBigWin?: LuckyFarmGlobalWinBanner | null;
}

export interface ScheduledRoom {
  id: string;
  title: string;
  description?: string;
  coverImage?: string;
  category?: string;
  scheduledTime: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  notified?: boolean;
  createdAt: string;
}



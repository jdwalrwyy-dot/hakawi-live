import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { API } from '../services/api';
import { triggerGoogleSignIn, renderGoogleSignInButton, GoogleUserProfile } from '../services/googleAuth';
import { soundEffects } from '../services/soundEffects';
import {
  Radio,
  Phone,
  User as UserIcon,
  X,
  AlertCircle,
  Loader2,
  KeyRound,
  CheckCircle2
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User, ownerToken?: string) => void;
  currentUser: User | null;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentUser
}) => {
  const [mode, setMode] = useState<'google' | 'phone' | 'facebook'>('google');
  const googleBtnContainerRef = useRef<HTMLDivElement>(null);
  
  // Login fields
  const [phone, setPhone] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [ownerPin, setOwnerPin] = useState('');
  const [requiresOwnerPin, setRequiresOwnerPin] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isFacebookLoading, setIsFacebookLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setErrorMsg(null);
      setIsOtpSent(false);
      setOtpCode('');
      setOwnerPin('');
      setRequiresOwnerPin(false);
      setIsGoogleLoading(false);
      setIsFacebookLoading(false);
      setIsLoading(false);
      setMode('google');
    }
  }, [isOpen]);

  // Render official Google Sign In button onto container when in google mode
  useEffect(() => {
    if (isOpen && mode === 'google' && googleBtnContainerRef.current) {
      const cleanup = renderGoogleSignInButton(
        googleBtnContainerRef.current,
        async (profile: GoogleUserProfile) => {
          setIsGoogleLoading(true);
          setErrorMsg(null);
          try {
            const res = await API.loginWithGoogle({
              googleId: profile.googleId,
              email: profile.email,
              name: profile.name,
              avatar: profile.avatar || undefined
            });
            finalizeAuth(res.user, res.ownerToken);
          } catch (err: any) {
            console.warn('Google auth error:', err);
            setErrorMsg(err.message || 'تعذر تسجيل الدخول بحساب Google');
          } finally {
            setIsGoogleLoading(false);
          }
        },
        (err) => {
          console.warn('Google button init error:', err);
        }
      );
      return cleanup;
    }
  }, [isOpen, mode]);

  if (!isOpen) return null;

  const finalizeAuth = (user: User, ownerToken?: string) => {
    if (ownerToken) {
      localStorage.setItem('hekawy_owner_token', ownerToken);
    }
    soundEffects.playJoinRoom();
    onLoginSuccess(user, ownerToken);
    onClose();
  };

  // Google Authentication Trigger
  const handleGoogleLogin = async () => {
    setIsGoogleLoading(true);
    setErrorMsg(null);
    try {
      const profile: GoogleUserProfile = await triggerGoogleSignIn();
      const res = await API.loginWithGoogle({
        googleId: profile.googleId,
        email: profile.email,
        name: profile.name,
        avatar: profile.avatar || undefined
      });
      finalizeAuth(res.user, res.ownerToken);
    } catch (err: any) {
      console.warn('Google sign-in error:', err);
      if (err.message && err.message.includes('إلغاء')) {
        setErrorMsg('تم إلغاء تسجيل الدخول أو اختيار الحساب');
      } else {
        setErrorMsg(err.message || 'تعذر تسجيل الدخول بحساب Google');
      }
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Facebook Authentication Trigger
  const handleFacebookLogin = async () => {
    setIsFacebookLoading(true);
    setErrorMsg(null);
    try {
      const fbId = `fb_${Date.now()}`;
      const res = await API.loginWithFacebook({
        facebookId: fbId,
        name: 'مستخدم فيسبوك',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + fbId
      });
      finalizeAuth(res.user, res.ownerToken);
    } catch (err: any) {
      console.warn('Facebook sign-in error:', err);
      setErrorMsg(err.message || 'تعذر تسجيل الدخول عبر Facebook');
    } finally {
      setIsFacebookLoading(false);
    }
  };

  // Phone Login Flow
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.trim().length < 8) {
      setErrorMsg('يرجى إدخال رقم هاتف صحيح');
      return;
    }
    setIsOtpSent(true);
    setErrorMsg(null);
    setOtpCode('');
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || otpCode.length !== 4) {
      setErrorMsg('يرجى إدخال رمز التحقق المكون من 4 أرقام');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await API.login({ 
        phone: phone.trim(),
        ownerPin: ownerPin.trim() || undefined
      });
      finalizeAuth(res.user, res.ownerToken);
    } catch (err: any) {
      if (err.requiresOwnerPin) {
        setRequiresOwnerPin(true);
        setErrorMsg(err.message || 'حساب المالك العام محمي برمز أمان خاص. يرجى إدخال رمز الأمان (PIN).');
      } else {
        setErrorMsg(err.message || 'فشل تسجيل الدخول برقم الهاتف');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-5 shadow-2xl flex flex-col gap-4 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-black text-lg text-amber-400">
                مرحبًا بك في حكاوي 🎙️
              </h2>
              <p className="text-xs text-slate-400">
                سجّل دخولك لحسابك الخاص عبر Google، رقم الهاتف، أو Facebook
              </p>
            </div>
          </div>
          {currentUser && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200 cursor-pointer"
              title="إغلاق النافذة"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Primary Screen Tabs: Google vs Phone vs Facebook */}
        <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-[11px] font-black">
          <button
            type="button"
            onClick={() => {
              setMode('google');
              setErrorMsg(null);
            }}
            className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              mode === 'google'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
              <path fill={mode === 'google' ? '#0f172a' : '#4285F4'} d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill={mode === 'google' ? '#0f172a' : '#34A853'} d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill={mode === 'google' ? '#0f172a' : '#FBBC05'} d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill={mode === 'google' ? '#0f172a' : '#EA4335'} d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>Google</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('phone');
              setErrorMsg(null);
            }}
            className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              mode === 'phone'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>رقم الهاتف</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMode('facebook');
              setErrorMsg(null);
            }}
            className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              mode === 'facebook'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            <span>Facebook</span>
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* MODE: GOOGLE */}
        {mode === 'google' && (
          <div className="flex flex-col gap-4 py-1">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col gap-3 text-center">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-white flex items-center justify-center shadow-lg shadow-white/5 border border-slate-200">
                <svg className="w-8 h-8" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
              </div>

              <div>
                <h3 className="text-sm font-black text-slate-100">
                  تسجيل الدخول عبر Google
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  يفتح نافذة اختيار الحسابات الرسمية للدخول فوراً بنقرة واحدة ودون الحاجة لأي خطوات إضافية.
                </p>
              </div>

              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isGoogleLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-sm flex items-center justify-center gap-3 shadow-xl active:scale-98 transition-all border border-slate-200 cursor-pointer disabled:opacity-75"
              >
                {isGoogleLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-slate-900" />
                ) : (
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                )}
                <span>{isGoogleLoading ? 'جاري الاتصال...' : 'الدخول باستخدام Google'}</span>
              </button>

              <div ref={googleBtnContainerRef} className="flex justify-center my-0.5 overflow-hidden" />
            </div>
          </div>
        )}

        {/* MODE: PHONE */}
        {mode === 'phone' && (
          <div className="flex flex-col gap-3">
            {!isOtpSent ? (
              <form onSubmit={handleSendOtp} className="flex flex-col gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">رقم الهاتف</label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      placeholder="+966501234567"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-100 text-sm font-mono focus:border-amber-400 focus:outline-none"
                    />
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>إرسال كود التحقق (OTP)</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="flex flex-col gap-3">
                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
                  تم إرسال رمز التحقق إلى <b>{phone}</b>. كود التجربة: <b>1234</b>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1.5">رمز التحقق (4 أرقام)</label>
                  <input
                    type="text"
                    maxLength={4}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    className="w-full text-center tracking-widest text-2xl font-mono px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                {requiresOwnerPin && (
                  <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-400/30 flex flex-col gap-1.5">
                    <label className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                      <KeyRound className="w-4 h-4 text-amber-400" />
                      <span>رمز أمان المالك (PIN)</span>
                    </label>
                    <input
                      type="password"
                      placeholder="أدخل رمز أمان المالك"
                      value={ownerPin}
                      onChange={(e) => setOwnerPin(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-amber-400/40 text-amber-300 text-sm font-mono tracking-widest text-center focus:outline-none"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-slate-950 shrink-0" />
                      <span>جاري تسجيل الدخول...</span>
                    </>
                  ) : (
                    <span>تأكيد والدخول فوراً</span>
                  )}
                </button>
              </form>
            )}
          </div>
        )}

        {/* MODE: FACEBOOK */}
        {mode === 'facebook' && (
          <div className="flex flex-col gap-4 py-1">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col gap-3 text-center">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-[#1877F2] text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
                <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </div>

              <div>
                <h3 className="text-sm font-black text-slate-100">
                  تسجيل الدخول عبر Facebook
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  ربط وتجسيد الدخول عبر حسابك في Facebook بنقرة واحدة وسريعة.
                </p>
              </div>

              <button
                type="button"
                onClick={handleFacebookLogin}
                disabled={isFacebookLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] text-white font-extrabold text-sm flex items-center justify-center gap-3 shadow-xl shadow-blue-500/20 active:scale-98 transition-all cursor-pointer disabled:opacity-75"
              >
                {isFacebookLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-white" />
                ) : (
                  <svg className="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                )}
                <span>{isFacebookLoading ? 'جاري الاتصال...' : 'الدخول باستخدام Facebook'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

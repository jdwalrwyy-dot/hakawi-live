import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { API } from '../services/api';
import {
  Camera,
  CheckCircle2,
  AlertCircle,
  X,
  Sparkles,
  ArrowUp,
  ArrowDown,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

interface LivenessCameraVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: User | null;
  registrationData?: {
    name: string;
    username: string;
    gender: 'MALE' | 'FEMALE';
    phone?: string;
    referredBy?: string;
    dob: string;
    age: number;
  };
  gender: 'MALE' | 'FEMALE' | 'male' | 'female';
  onVerified: (user: User) => void;
}

type LivenessStep = 'UP' | 'DOWN' | 'RIGHT' | 'LEFT' | 'COMPLETED';

export const LivenessCameraVerificationModal: React.FC<LivenessCameraVerificationModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  registrationData,
  gender,
  onVerified
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<LivenessStep>('UP');

  const [upPhoto, setUpPhoto] = useState<string | null>(null);
  const [downPhoto, setDownPhoto] = useState<string | null>(null);
  const [rightPhoto, setRightPhoto] = useState<string | null>(null);
  const [leftPhoto, setLeftPhoto] = useState<string | null>(null);

  const [isCapturing, setIsCapturing] = useState(false);
  const [stepSuccessAnimation, setStepSuccessAnimation] = useState<LivenessStep | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Progress percentage calculation
  const getProgressPercent = () => {
    switch (currentStep) {
      case 'UP': return 25;
      case 'DOWN': return 50;
      case 'RIGHT': return 75;
      case 'LEFT': return 90;
      case 'COMPLETED': return 100;
      default: return 0;
    }
  };

  const startCamera = async () => {
    try {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
      setCameraError(null);

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: 'user',
          width: { ideal: 720 },
          height: { ideal: 720 }
        }
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play().catch(console.warn);
      }
    } catch (err: any) {
      console.error('Liveness camera access error:', err);
      setCameraError('لم نتمكن من الوصول للكاميرا الأمامية. يرجى السماح بالصلاحيات لإتمام فحص الحيوية التفاعلي.');
    }
  };

  useEffect(() => {
    if (isOpen) {
      setCurrentStep('UP');
      setUpPhoto(null);
      setDownPhoto(null);
      setRightPhoto(null);
      setLeftPhoto(null);
      setErrorMessage(null);
      setStepSuccessAnimation(null);
      startCamera();
    } else {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
        setStream(null);
      }
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, [isOpen]);

  const captureCurrentFrame = (): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 640;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    return canvas.toDataURL('image/jpeg', 0.85);
  };

  const handlePerformMovementCapture = () => {
    if (isCapturing || submitting) return;
    setIsCapturing(true);

    setTimeout(() => {
      const snapshot = captureCurrentFrame();
      if (!snapshot) {
        setErrorMessage('تعذر التقاط الصورة من الكاميرا، يرجى المحاولة مرة أخرى.');
        setIsCapturing(false);
        return;
      }

      if (currentStep === 'UP') {
        setUpPhoto(snapshot);
        setStepSuccessAnimation('UP');
        setTimeout(() => {
          setStepSuccessAnimation(null);
          setCurrentStep('DOWN');
          setIsCapturing(false);
        }, 1000);
      } else if (currentStep === 'DOWN') {
        setDownPhoto(snapshot);
        setStepSuccessAnimation('DOWN');
        setTimeout(() => {
          setStepSuccessAnimation(null);
          setCurrentStep('RIGHT');
          setIsCapturing(false);
        }, 1000);
      } else if (currentStep === 'RIGHT') {
        setRightPhoto(snapshot);
        setStepSuccessAnimation('RIGHT');
        setTimeout(() => {
          setStepSuccessAnimation(null);
          setCurrentStep('LEFT');
          setIsCapturing(false);
        }, 1000);
      } else if (currentStep === 'LEFT') {
        setLeftPhoto(snapshot);
        setStepSuccessAnimation('LEFT');
        setTimeout(() => {
          setStepSuccessAnimation(null);
          setCurrentStep('COMPLETED');
          setIsCapturing(false);
          completeVerificationProcess(snapshot);
        }, 1000);
      }
    }, 500);
  };

  const completeVerificationProcess = async (lastSnapshot: string) => {
    setSubmitting(true);
    setErrorMessage(null);

    try {
      let verifiedUser: User;

      if (registrationData) {
        // Register user with gender, DOB, age, and instant verification
        const regRes = await API.register({
          name: registrationData.name,
          username: registrationData.username,
          gender: registrationData.gender,
          phone: registrationData.phone,
          referredBy: registrationData.referredBy
        });
        verifiedUser = regRes.user;

        // Apply instant verification & golden credibility badge
        const verRes = await API.submitInstantVerification({
          userId: verifiedUser.id,
          gender: registrationData.gender,
          verificationPhoto: lastSnapshot,
          livenessFrontPhoto: upPhoto || lastSnapshot,
          livenessRightPhoto: rightPhoto || lastSnapshot,
          livenessLeftPhoto: leftPhoto || lastSnapshot
        });

        if (verRes.success && verRes.user) {
          verifiedUser = verRes.user;
        }
      } else if (currentUser) {
        const verRes = await API.submitInstantVerification({
          userId: currentUser.id,
          gender: gender,
          verificationPhoto: lastSnapshot,
          livenessFrontPhoto: upPhoto || lastSnapshot,
          livenessRightPhoto: rightPhoto || lastSnapshot,
          livenessLeftPhoto: leftPhoto || lastSnapshot
        });
        if (verRes.success && verRes.user) {
          verifiedUser = verRes.user;
        } else {
          verifiedUser = currentUser;
        }
      } else {
        throw new Error('بيانات المستخدم أو التسجيل غير متوفرة');
      }

      onVerified(verifiedUser);
      try {
        localStorage.setItem('currentUser', JSON.stringify(verifiedUser));
        localStorage.setItem('hekawy_current_user', JSON.stringify(verifiedUser));
      } catch {}

      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      setErrorMessage(err.message || 'فشل إتمام توثيق الهوية الحيوية');
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const progress = getProgressPercent();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-lg p-4 animate-in fade-in duration-200 dir-rtl font-sans select-none">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-amber-500/60 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 shadow-inner">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-100 flex items-center gap-2">
                <span>فحص الحيوية التفاعلي بالكاميرا</span>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-extrabold border border-amber-500/30">
                  شارة المصداقية الذهبية 🛡️
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">اتبع التوجيهات الأربع بدقة لإثبات الهوية البشرية</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Golden Circular Progress Indicator & Instruction Bar */}
        <div className="p-3.5 bg-gradient-to-r from-amber-500/10 via-slate-900 to-amber-500/10 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative w-10 h-10 flex items-center justify-center rounded-full bg-slate-950 border-2 border-amber-400 text-amber-300 font-black text-xs shadow-md">
              <span>{progress}%</span>
            </div>
            <div>
              {currentStep === 'UP' && (
                <div className="text-amber-300 font-extrabold text-xs flex items-center gap-1.5 animate-pulse">
                  <ArrowUp className="w-4 h-4 text-amber-400" />
                  <span>1. انظر إلى الأعلى ⬆️ (ارفع رأسك قليلًا)</span>
                </div>
              )}
              {currentStep === 'DOWN' && (
                <div className="text-cyan-300 font-extrabold text-xs flex items-center gap-1.5 animate-pulse">
                  <ArrowDown className="w-4 h-4 text-cyan-400" />
                  <span>2. انظر إلى الأسفل ⬇️ (أخفض ذقنك قليلًا)</span>
                </div>
              )}
              {currentStep === 'RIGHT' && (
                <div className="text-emerald-300 font-extrabold text-xs flex items-center gap-1.5 animate-pulse">
                  <ArrowRight className="w-4 h-4 text-emerald-400" />
                  <span>3. التفت إلى اليمين ➡️</span>
                </div>
              )}
              {currentStep === 'LEFT' && (
                <div className="text-rose-300 font-extrabold text-xs flex items-center gap-1.5 animate-pulse">
                  <ArrowLeft className="w-4 h-4 text-rose-400" />
                  <span>4. التفت إلى اليسار ⬅️</span>
                </div>
              )}
              {currentStep === 'COMPLETED' && (
                <div className="text-emerald-300 font-black text-xs flex items-center gap-1.5 animate-bounce">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>تم تأكيد الهوية البشرية بنجاح ✅</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Golden Circular Camera Frame Viewfinder */}
        <div className="relative p-6 bg-slate-950 flex flex-col items-center justify-center">
          <canvas ref={canvasRef} className="hidden" />

          <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.35)] bg-slate-900 flex items-center justify-center">
            {cameraError ? (
              <div className="p-4 text-center space-y-2">
                <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
                <p className="text-xs font-bold text-rose-300">{cameraError}</p>
                <button
                  onClick={startCamera}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-extrabold cursor-pointer"
                >
                  إعادة تشغيل الكاميرا 🔄
                </button>
              </div>
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover scale-x-[-1]"
              />
            )}

            {/* Target Alignment Guide */}
            {!cameraError && currentStep !== 'COMPLETED' && (
              <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-amber-400/60 rounded-full animate-pulse flex items-center justify-center">
                <div className="w-24 h-24 border border-cyan-400/40 rounded-full" />
              </div>
            )}

            {/* Step Success Overlay */}
            {stepSuccessAnimation && (
              <div className="absolute inset-0 bg-emerald-950/85 backdrop-blur-sm flex flex-col items-center justify-center gap-2 animate-in zoom-in-50 duration-200">
                <div className="p-3 rounded-full bg-emerald-500 text-slate-950 shadow-2xl animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <span className="font-black text-xs text-emerald-200">تم تسجيل الحركة بنجاح! ✅</span>
              </div>
            )}

            {/* Completed Celebration */}
            {currentStep === 'COMPLETED' && (
              <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-4 text-center space-y-3 animate-in zoom-in-75 duration-300">
                <div className="p-4 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 shadow-2xl animate-bounce">
                  <ShieldCheck className="w-12 h-12" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-black text-sm text-slate-100">تم تأكيد الهوية البشرية بنجاح ✅</h4>
                  <p className="text-[11px] text-amber-300 font-bold">
                    تم منحك "شارة المصداقية الذهبية" وتوثيق الحساب بسلام!
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* 4 Step Badges */}
          <div className="flex items-center justify-center gap-2 mt-4 text-[11px] font-bold">
            <span className={`px-2.5 py-1 rounded-full border ${upPhoto ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : currentStep === 'UP' ? 'bg-amber-500/20 text-amber-300 border-amber-400 ring-2 ring-amber-400' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
              {upPhoto ? '✓ أعلى' : '1. أعلى ⬆️'}
            </span>
            <span className={`px-2.5 py-1 rounded-full border ${downPhoto ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : currentStep === 'DOWN' ? 'bg-amber-500/20 text-amber-300 border-amber-400 ring-2 ring-amber-400' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
              {downPhoto ? '✓ أسفل' : '2. أسفل ⬇️'}
            </span>
            <span className={`px-2.5 py-1 rounded-full border ${rightPhoto ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : currentStep === 'RIGHT' ? 'bg-amber-500/20 text-amber-300 border-amber-400 ring-2 ring-amber-400' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
              {rightPhoto ? '✓ يمين' : '3. يمين ➡️'}
            </span>
            <span className={`px-2.5 py-1 rounded-full border ${leftPhoto ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : currentStep === 'LEFT' ? 'bg-amber-500/20 text-amber-300 border-amber-400 ring-2 ring-amber-400' : 'bg-slate-900 text-slate-500 border-slate-800'}`}>
              {leftPhoto ? '✓ يسار' : '4. يسار ⬅️'}
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 space-y-2">
          {errorMessage && (
            <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold text-center">
              {errorMessage}
            </div>
          )}

          {currentStep !== 'COMPLETED' && (
            <button
              type="button"
              onClick={handlePerformMovementCapture}
              disabled={isCapturing || Boolean(cameraError) || submitting}
              className={`w-full py-3.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all shadow-xl cursor-pointer ${
                isCapturing || Boolean(cameraError) || submitting
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 text-slate-950 shadow-amber-500/30 active:scale-95'
              }`}
            >
              {isCapturing || submitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>جاري معالجة الحركة والتحقق...</span>
                </>
              ) : (
                <>
                  <Camera className="w-4 h-4" />
                  <span>
                    {currentStep === 'UP' && 'التقاط حركة "الأعلى ⬆️"'}
                    {currentStep === 'DOWN' && 'التقاط حركة "الأسفل ⬇️"'}
                    {currentStep === 'RIGHT' && 'التقاط حركة "اليمين ➡️"'}
                    {currentStep === 'LEFT' && 'التقاط وتأكيد نهائي "اليسار ⬅️" ✅'}
                  </span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

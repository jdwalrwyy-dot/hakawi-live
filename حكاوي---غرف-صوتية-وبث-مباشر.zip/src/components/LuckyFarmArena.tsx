import React, { useState, useEffect } from 'react';
import { User, LuckyFarmRoundState, LuckyFarmGlobalWinBanner } from '../types';
import { API } from '../services/api';
import { socketService } from '../services/socketService';
import { soundEffects } from '../services/soundEffects';
import {
  Gem,
  RefreshCw,
  Clock,
  Volume2,
  VolumeX,
  X,
  PartyPopper,
  DoorOpen,
  Trophy,
  Coins,
  Sparkles,
  ArrowRightLeft
} from 'lucide-react';

interface LuckyFarmArenaProps {
  currentUser: User;
  onUserUpdated: (user: User) => void;
  onOpenWallet: () => void;
  onExitGame?: () => void;
  isEmbeddedInRoom?: boolean;
}

// 8 Items matching server IDs & exact user specs
export const LUCKY_FARM_ITEMS = [
  { id: 'tomato', nameAr: 'طماطم/سلطة', icon: '🍅', multiplier: 5, sliceIndex: 0, badgeBg: 'bg-red-600 text-white' },
  { id: 'carrot', nameAr: 'جزر', icon: '🥕', multiplier: 5, sliceIndex: 1, badgeBg: 'bg-orange-500 text-white' },
  { id: 'corn', nameAr: 'ذرة', icon: '🌽', multiplier: 5, sliceIndex: 2, badgeBg: 'bg-amber-500 text-white' },
  { id: 'grilled_meat', nameAr: 'لحم مشوي', icon: '🍖', multiplier: 15, sliceIndex: 3, badgeBg: 'bg-red-700 text-white' },
  { id: 'shrimp', nameAr: 'جمبري', icon: '🍤', multiplier: 10, sliceIndex: 4, badgeBg: 'bg-pink-600 text-white' },
  { id: 'blue_fish', nameAr: 'سمكة زرقاء', icon: '🐟', multiplier: 25, sliceIndex: 5, badgeBg: 'bg-blue-600 text-white' },
  { id: 'white_chicken', nameAr: 'دجاجة بيضاء', icon: '🐔', multiplier: 10, sliceIndex: 6, badgeBg: 'bg-slate-200 text-slate-800' },
  { id: 'special_plate', nameAr: 'طبق مميز', icon: '🍽️', multiplier: 45, sliceIndex: 7, badgeBg: 'bg-purple-600 text-white' }
];

export const LuckyFarmArena: React.FC<LuckyFarmArenaProps> = ({
  currentUser,
  onUserUpdated,
  onOpenWallet,
  onExitGame,
  isEmbeddedInRoom = false
}) => {
  // Selected Bet Amount (Default 100)
  const [selectedBet, setSelectedBet] = useState<number>(100);
  const [gameState, setGameState] = useState<LuckyFarmRoundState | null>(null);
  const [placedBets, setPlacedBets] = useState<Record<string, number>>({});
  const [isBettingLoading, setIsBettingLoading] = useState(false);
  const [showResultModal, setShowResultModal] = useState(false);
  const [myRoundWin, setMyRoundWin] = useState<number>(0);
  const [globalBanner, setGlobalBanner] = useState<LuckyFarmGlobalWinBanner | null>(null);
  const [soundMuted, setSoundMuted] = useState(false);

  // Wheel Rotation State
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [isSpinningActive, setIsSpinningActive] = useState<boolean>(false);

  // Smooth 1s Countdown Timer Fallback
  useEffect(() => {
    const timer = setInterval(() => {
      setGameState(prev => {
        if (!prev || prev.remainingSeconds <= 0) return prev;
        return {
          ...prev,
          remainingSeconds: prev.remainingSeconds - 1
        };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Initial fetch
  useEffect(() => {
    API.getLuckyFarmState(currentUser.id)
      .then(state => {
        setGameState(state);
        setPlacedBets(state.userBets || {});
        if (state.latestBigWin) {
          setGlobalBanner(state.latestBigWin);
        }
        if (state.winningItemId) {
          if (state.status === 'SPINNING') {
            spinWheelToItem(state.winningItemId);
          } else {
            alignWheelToItemImmediate(state.winningItemId);
          }
        }
      })
      .catch(err => console.warn('Lucky Farm fetch state error:', err));
  }, [currentUser.id]);

  const alignWheelToItemImmediate = (winningItemId: string) => {
    const item = LUCKY_FARM_ITEMS.find(i => i.id === winningItemId);
    if (!item) return;
    const sliceIndex = item.sliceIndex;
    const baseTargetAngle = (247.5 - (sliceIndex * 45) + 360) % 360;
    setIsSpinningActive(false);
    setWheelRotation(baseTargetAngle);
  };

  const spinWheelToItem = (winningItemId: string) => {
    const item = LUCKY_FARM_ITEMS.find(i => i.id === winningItemId);
    if (!item) return;

    setIsSpinningActive(true);
    const sliceIndex = item.sliceIndex;
    const revolutions = 10;
    const baseTargetAngle = (247.5 - (sliceIndex * 45) + 360) % 360;

    setWheelRotation(prev => {
      const currentRevolutions = Math.floor(prev / 360);
      return (currentRevolutions + revolutions) * 360 + baseTargetAngle;
    });
  };

  // WebSocket Live Sync
  useEffect(() => {
    const unsubTick = socketService.on('lucky_farm_tick', (data: any) => {
      setGameState(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          status: data.status,
          remainingSeconds: data.remainingSeconds,
          roundId: data.roundId,
          winningItemId: data.winningItemId,
          totalBetsPerItem: data.totalBetsPerItem || prev.totalBetsPerItem
        };
      });
    });

    const unsubBets = socketService.on('lucky_farm_bets_updated', (data: any) => {
      setGameState(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          totalBetsPerItem: data.totalBetsPerItem
        };
      });
    });

    const unsubSpin = socketService.on('lucky_farm_spin_started', (data: any) => {
      setGameState(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          status: 'SPINNING',
          winningItemId: data.winningItemId,
          totalBetsPerItem: data.totalBetsPerItem || prev.totalBetsPerItem
        };
      });
      spinWheelToItem(data.winningItemId);
    });

    const unsubResult = socketService.on('lucky_farm_result', (data: any) => {
      setGameState(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          status: 'RESULT',
          winningItemId: data.winningItemId,
          recentWinners: data.recentWinners || prev.recentWinners
        };
      });

      if (data.winningItemId) {
        alignWheelToItemImmediate(data.winningItemId);
      }

      // Check user win for this round
      if (data.userWinnings && data.userWinnings[currentUser.id]) {
        const winAmount = Number(data.userWinnings[currentUser.id]);
        setMyRoundWin(winAmount);
        setShowResultModal(true);
        if (winAmount > 0 && !soundMuted) {
          soundEffects.playCoinSound();
        }
      }

      // Refresh user balance
      API.getUser(currentUser.id)
        .then(u => {
          if (u) onUserUpdated(u);
        })
        .catch(() => {});
    });

    const unsubBettingStarted = socketService.on('lucky_farm_betting_started', (data: any) => {
      setGameState(prev => {
        if (!prev) return prev;
        return {
          ...prev,
          status: 'BETTING',
          roundId: data.roundId,
          remainingSeconds: 11,
          winningItemId: null,
          totalBetsPerItem: {
            tomato: 0,
            carrot: 0,
            corn: 0,
            grilled_meat: 0,
            shrimp: 0,
            blue_fish: 0,
            white_chicken: 0,
            special_plate: 0
          }
        };
      });
      setPlacedBets({});
      setShowResultModal(false);
      setMyRoundWin(0);
    });

    const unsubGlobalWin = socketService.on('lucky_farm_global_win', (banner: LuckyFarmGlobalWinBanner) => {
      setGlobalBanner(banner);
      setTimeout(() => setGlobalBanner(null), 5000);
    });

    return () => {
      unsubTick();
      unsubBets();
      unsubSpin();
      unsubResult();
      unsubBettingStarted();
      unsubGlobalWin();
    };
  }, [currentUser.id, soundMuted]);

  const handlePlaceBet = async (itemId: string) => {
    if (gameState?.status !== 'BETTING') {
      alert('عذراً، وقت الرهان مغلق حالياً. انتظر الجولة القادمة!');
      return;
    }
    if ((currentUser.diamonds || 0) < selectedBet) {
      alert('رصيدك من الماسات لا يكفي لهذا الرهان!');
      onOpenWallet();
      return;
    }

    setIsBettingLoading(true);
    try {
      const res = await API.placeLuckyFarmBet({
        userId: currentUser.id,
        itemId,
        amount: selectedBet
      });
      if (res.success) {
        setGameState(res.state);
        setPlacedBets(res.state.userBets || {});
        currentUser.diamonds = res.userDiamonds;
        onUserUpdated({ ...currentUser });
        if (!soundMuted) soundEffects.playClick();
      }
    } catch (err: any) {
      alert(err.message || 'فشل وضع الرهان');
    } finally {
      setIsBettingLoading(false);
    }
  };

  const handleCancelBets = async () => {
    if (gameState?.status !== 'BETTING') {
      alert('لا يمكن إلغاء الرهان بعد بدء الدوران!');
      return;
    }
    try {
      const res = await API.cancelLuckyFarmBet(currentUser.id);
      if (res.success) {
        setGameState(res.state);
        setPlacedBets({});
        currentUser.diamonds = res.userDiamonds;
        onUserUpdated({ ...currentUser });
        if (!soundMuted) soundEffects.playClick();
      }
    } catch (err: any) {
      alert(err.message || 'فشل إلغاء الرهانات');
    }
  };

  const formatNumber = (num: number) => {
    const n = Number(num) || 0;
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toLocaleString();
  };

  // Calculate total user bets in this round
  const totalMyBet: number = (Object.values(placedBets).reduce((a: number, b: any) => a + Number(b), 0) as number);

  return (
    <div className={`${isEmbeddedInRoom ? 'absolute inset-0 z-50 rounded-2xl' : 'fixed inset-0 z-50'} flex flex-col bg-gradient-to-b from-sky-400 via-sky-300 to-emerald-400 overflow-hidden select-none font-sans text-white`}>
      
      {/* 1. SKY, CLOUDS & TOP HEADER BAR */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 w-32 h-12 bg-white/60 rounded-full blur-md animate-pulse"></div>
        <div className="absolute top-20 right-16 w-40 h-16 bg-white/50 rounded-full blur-md"></div>
        <div className="absolute top-36 left-1/3 w-48 h-14 bg-white/40 rounded-full blur-md"></div>
      </div>

      {/* TOP HEADER: Balance & Exit */}
      <div className="relative z-20 flex items-center justify-between px-4 py-3 bg-sky-900/40 backdrop-blur-md border-b border-white/20">
        <div className="flex items-center gap-3">
          {/* Yellow Gold / Coins Balance Rectangle */}
          <div className="flex items-center gap-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-900 font-black px-4 py-1.5 rounded-full shadow-lg border-2 border-yellow-200">
            <Coins className="w-5 h-5 text-amber-900" />
            <span className="text-sm tracking-wide">{formatNumber(currentUser.diamonds || 0)}</span>
            <button
              onClick={onOpenWallet}
              className="bg-amber-900 text-yellow-300 w-5 h-5 rounded-full flex items-center justify-center text-xs hover:scale-110 transition-transform"
            >
              +
            </button>
          </div>
          <div className="flex items-center gap-1.5 bg-black/30 px-3 py-1 rounded-full text-xs font-bold text-yellow-300">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span>الجولة: {gameState?.roundId ? gameState.roundId.slice(-6) : '----'}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundMuted(!soundMuted)}
            className="p-2 rounded-full bg-black/30 hover:bg-black/50 text-white transition-colors"
          >
            {soundMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          {onExitGame && (
            <button
              onClick={onExitGame}
              className="p-2 rounded-full bg-red-600/80 hover:bg-red-700 text-white shadow-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* 2. FERRIS WHEEL STAGE (ساقية ملاهي تدور في السماء) */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4">
        
        {/* Ferris Wheel Container */}
        <div className="relative w-[340px] h-[340px] sm:w-[380px] sm:h-[380px] flex items-center justify-center">
          
          {/* Outer Rotating Ferris Wheel Structure */}
          <div
            className="absolute inset-0 rounded-full border-[6px] border-yellow-300/80 shadow-[0_0_30px_rgba(250,204,21,0.6)] flex items-center justify-center transition-transform duration-1000 ease-out"
            style={{
              transform: `rotate(${wheelRotation}deg)`
            }}
          >
            {/* Inner Metallic Spokes */}
            <div className="absolute inset-4 rounded-full border-2 border-dashed border-yellow-200/50"></div>
            <div className="absolute inset-0 flex items-center justify-center"><div className="w-full h-1 bg-yellow-300/60"></div></div>
            <div className="absolute inset-0 flex items-center justify-center"><div className="w-1 h-full bg-yellow-300/60"></div></div>
            <div className="absolute inset-0 flex items-center justify-center rotate-45"><div className="w-full h-1 bg-yellow-300/60"></div></div>
            <div className="absolute inset-0 flex items-center justify-center -rotate-45"><div className="w-full h-1 bg-yellow-300/60"></div></div>

            {/* 8 Hanging Seats / Food Items on the Wheel Rim */}
            {LUCKY_FARM_ITEMS.map((item, index) => {
              const angle = index * (360 / LUCKY_FARM_ITEMS.length);
              const rad = (angle * Math.PI) / 180;
              const radius = 138;
              const x = Math.cos(rad) * radius;
              const y = Math.sin(rad) * radius;

              const totalBet = Number(gameState?.totalBetsPerItem[item.id] || 0);
              const myBet = Number(placedBets[item.id] || 0);

              return (
                <div
                  key={item.id}
                  onClick={() => handlePlaceBet(item.id)}
                  className="absolute cursor-pointer group"
                  style={{
                    transform: `translate(${x}px, ${y}px) rotate(${-wheelRotation}deg)`
                  }}
                >
                  <div className={`w-16 h-16 sm:w-18 sm:h-18 rounded-full ${item.badgeBg} border-4 border-white shadow-xl flex flex-col items-center justify-center hover:scale-110 active:scale-95 transition-transform`}>
                    <span className="text-2xl sm:text-3xl filter drop-shadow">{item.icon}</span>
                    <span className="text-[11px] font-black tracking-tighter bg-black/40 px-1.5 rounded-full">
                      x{item.multiplier}
                    </span>
                  </div>

                  {/* Bet status badge below item */}
                  <div className="absolute top-18 left-1/2 -translate-x-1/2 bg-slate-900/90 border border-yellow-400 text-yellow-300 text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap shadow-md">
                    {totalBet > 0 ? formatNumber(totalBet) : '0'}
                    {myBet > 0 && <span className="text-emerald-400 block text-[90%]">أنت: {formatNumber(myBet)}</span>}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Top Pointer Arrow */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-30 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[22px] border-t-yellow-400 filter drop-shadow-lg"></div>

          {/* CENTER CIRCLE: Cute White Cat with Glasses & Countdown Timer */}
          <div className="absolute z-20 w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-br from-white to-sky-100 border-4 border-yellow-400 shadow-2xl flex flex-col items-center justify-center text-slate-800">
            <div className="text-3xl sm:text-4xl">🐱👓</div>
            <div className="flex items-center gap-1 font-black text-xs sm:text-sm text-sky-900 bg-yellow-300 px-2 py-0.5 rounded-full shadow-inner mt-1">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>{gameState?.remainingSeconds || 11}s</span>
            </div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider mt-0.5">
              {gameState?.status === 'BETTING' ? 'رهان مفتوح' : gameState?.status === 'SPINNING' ? 'تدور...' : 'النتيجة'}
            </span>
          </div>
        </div>

      </div>

      {/* 3. GREEN MEADOW BACKGROUND AT THE BOTTOM */}
      <div className="relative z-10 bg-gradient-to-t from-emerald-700 via-emerald-600 to-emerald-500 pt-4 pb-6 px-4 rounded-t-[36px] shadow-[0_-10px_30px_rgba(0,0,0,0.2)] border-t-4 border-emerald-400">
        
        {/* Betting Chip Rows (الصف الأزرق، الأخضر، الأحمر/الوردي) */}
        <div className="max-w-md mx-auto space-y-2 mb-4">
          
          {/* Blue Row: 100, 200, 300, 400, 500 */}
          <div className="flex items-center justify-center gap-2">
            {[100, 200, 300, 400, 500].map(amt => (
              <button
                key={amt}
                onClick={() => setSelectedBet(amt)}
                className={`flex-1 py-1.5 rounded-xl font-black text-xs sm:text-sm transition-all shadow-md ${
                  selectedBet === amt
                    ? 'bg-blue-600 text-white ring-4 ring-white scale-105'
                    : 'bg-blue-500/80 hover:bg-blue-500 text-blue-100'
                }`}
              >
                {amt}
              </button>
            ))}
          </div>

          {/* Green Row: 1K, 2K, 3K, 4K, 5K */}
          <div className="flex items-center justify-center gap-2">
            {[1000, 2000, 3000, 4000, 5000].map(amt => (
              <button
                key={amt}
                onClick={() => setSelectedBet(amt)}
                className={`flex-1 py-1.5 rounded-xl font-black text-xs sm:text-sm transition-all shadow-md ${
                  selectedBet === amt
                    ? 'bg-emerald-600 text-white ring-4 ring-white scale-105'
                    : 'bg-emerald-500/80 hover:bg-emerald-500 text-emerald-100'
                }`}
              >
                {formatNumber(amt)}
              </button>
            ))}
          </div>

          {/* Red/Pink Row: 1M, 2M, 3M, 4M, 5M */}
          <div className="flex items-center justify-center gap-2">
            {[1000000, 2000000, 3000000, 4000000, 5000000].map(amt => (
              <button
                key={amt}
                onClick={() => setSelectedBet(amt)}
                className={`flex-1 py-1.5 rounded-xl font-black text-xs sm:text-sm transition-all shadow-md ${
                  selectedBet === amt
                    ? 'bg-rose-600 text-white ring-4 ring-white scale-105'
                    : 'bg-rose-500/80 hover:bg-rose-500 text-rose-100'
                }`}
              >
                {formatNumber(amt)}
              </button>
            ))}
          </div>
        </div>

        {/* Control Buttons & Bottom Results Bar */}
        <div className="max-w-md mx-auto flex flex-col gap-2.5">
          
          {/* Wide Yellow Button: Cancel Bet & Retrieve */}
          <button
            onClick={handleCancelBets}
            disabled={gameState?.status !== 'BETTING' || totalMyBet === 0}
            className="w-full bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 disabled:opacity-50 text-slate-900 font-black py-2.5 rounded-2xl shadow-lg flex items-center justify-center gap-2 text-sm sm:text-base border-2 border-yellow-200 transition-all active:scale-95"
          >
            <RefreshCw className="w-5 h-5 text-amber-900" />
            <span>إلغاء الرهان واسترجاع ({formatNumber(totalMyBet)})</span>
          </button>

          {/* Results Summary Bar */}
          <div className="flex items-center justify-between bg-black/30 backdrop-blur-md px-4 py-2 rounded-2xl text-xs font-bold border border-white/10">
            <div className="flex items-center gap-2">
              <span className="text-yellow-300">رهانك الحالي:</span>
              <span className="bg-white/20 px-2 py-0.5 rounded-lg text-white">{formatNumber(totalMyBet)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-emerald-300">أرباح الجولة:</span>
              <span className="bg-emerald-600/40 px-2 py-0.5 rounded-lg text-emerald-200">{formatNumber(myRoundWin)}</span>
            </div>
          </div>

          {/* Recent Results Past History (Small Circles) */}
          <div className="flex items-center justify-center gap-2 pt-1">
            <span className="text-[11px] text-emerald-200 font-semibold">آخر النتائج:</span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-1">
              {gameState?.recentWinners && gameState.recentWinners.length > 0 ? (
                gameState.recentWinners.slice(0, 6).map((win, idx) => {
                  const itm = LUCKY_FARM_ITEMS.find(i => i.id === win.winningItemId);
                  return (
                    <div
                      key={idx}
                      className="w-7 h-7 rounded-full bg-white/20 border border-white/40 flex items-center justify-center text-sm shadow-sm flex-shrink-0"
                      title={itm?.nameAr || win.winningItemId}
                    >
                      {itm ? itm.icon : '🎡'}
                    </div>
                  );
                })
              ) : (
                <span className="text-[10px] text-emerald-200/70">لا توجد نتائج سابقة بعد</span>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* Result Popup Modal Overlay */}
      {showResultModal && (
        <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-gradient-to-b from-slate-900 to-slate-800 border-2 border-yellow-400 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl relative">
            <div className="w-20 h-20 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-yellow-400">
              <PartyPopper className="w-10 h-10 text-yellow-400 animate-bounce" />
            </div>
            <h3 className="text-2xl font-black text-yellow-300 mb-2">نتائج الجولة!</h3>
            {myRoundWin > 0 ? (
              <div className="space-y-3">
                <p className="text-emerald-400 font-bold text-lg">مبروك! لقد ربحت جوائز قيمة في الساقية</p>
                <div className="bg-emerald-950/60 border border-emerald-500/40 rounded-2xl p-3">
                  <span className="text-xs text-emerald-300 block">إجمالي أرباحك:</span>
                  <span className="text-2xl font-black text-emerald-400">+{formatNumber(myRoundWin)} ماسة</span>
                </div>
              </div>
            ) : (
              <p className="text-slate-300 text-sm mb-4">حظ أوفر في الجولة القادمة! جرب حظك مرة أخرى.</p>
            )}
            <button
              onClick={() => setShowResultModal(false)}
              className="w-full mt-6 bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-500 hover:to-amber-600 text-slate-900 font-black py-3 rounded-2xl shadow-lg transition-all"
            >
              استمرار اللعب 🎡
            </button>
          </div>
        </div>
      )}

      {/* Global Big Win Banner */}
      {globalBanner && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-900 font-black px-6 py-2.5 rounded-full shadow-2xl border-2 border-white flex items-center gap-3 animate-bounce">
          <Sparkles className="w-5 h-5 text-amber-950" />
          <span>🎉 {globalBanner.userName} ربح {formatNumber(globalBanner.winAmount)} ماسة في الساقية!</span>
        </div>
      )}

    </div>
  );
};

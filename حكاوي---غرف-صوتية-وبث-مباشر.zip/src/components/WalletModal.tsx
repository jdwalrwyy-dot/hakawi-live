import React, { useState, useEffect } from 'react';
import { User, WalletTransaction, isUserOwner, OFFICIAL_COIN_PACKAGES, StorePackage } from '../types';
import { API } from '../services/api';
import { soundEffects } from '../services/soundEffects';
import { HostWithdrawalSection } from './HostWithdrawalSection';
import confetti from 'canvas-confetti';
import {
  Coins,
  Gem,
  ArrowRightLeft,
  History,
  X,
  CheckCircle,
  AlertCircle,
  Crown,
  ShieldCheck,
  Wallet,
  Copy,
  CreditCard,
  Zap,
  Check,
  ShoppingBag
} from 'lucide-react';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onUserUpdated: (user: User) => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserUpdated
}) => {
  const isOwner = isUserOwner(currentUser);

  const [activeTab, setActiveTab] = useState<'packages' | 'balance' | 'withdraw' | 'convert' | 'history'>('packages');

  // Convert tab state
  const [convertAmount, setConvertAmount] = useState<string>('100');

  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      API.getWalletTransactions(currentUser.id)
        .then(txs => setTransactions(txs))
        .catch(() => {});
    }
  }, [isOpen, currentUser.id]);

  if (!isOpen) return null;

  const handleConvert = async () => {
    const amt = Number(convertAmount);
    if (isNaN(amt) || amt < 100 || amt % 100 !== 0) {
      setErrorMsg('يجب أن تكون كمية التحويل من الكونز مضاعفات الرقم 100 (الحد الأدنى 100)');
      return;
    }
    if ((currentUser.coins || 0) < amt) {
      setErrorMsg('رصيدك من الكونز لا يكفي للتحويل');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const res = await API.convertCoinsToDiamonds(currentUser.id, amt);
      if (res.success && res.user) {
        onUserUpdated(res.user);
        setSuccessMsg(`تم تحويل ${amt.toLocaleString()} كونز إلى الماسات بنجاح! 🎉`);
        soundEffects.playCoinSound();
        confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'فشلت عملية تحويل العملات');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGooglePlayCheckout = async (pkg: StorePackage) => {
    setIsLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const res = await API.topupWithGooglePlay({
        userId: currentUser.id,
        packageId: pkg.id,
        coins: pkg.coins,
        purchaseToken: 'gp_token_' + Date.now()
      });
      if (res.success) {
        currentUser.coins = res.userCoins;
        onUserUpdated({ ...currentUser });
        setSuccessMsg(`تم إتمام الدفع بنجاح عبر متجر Google Play وشحن ${pkg.coins.toLocaleString()} كونر رصيدك فوراً! 🎮✨`);
        soundEffects.playCoinSound();
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
        // Refresh transactions
        API.getWalletTransactions(currentUser.id)
          .then(txs => setTransactions(txs))
          .catch(() => {});
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'فشلت عملية الشحن عبر متجر Google Play');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200" dir="rtl">
      <div className="w-full max-w-lg bg-gradient-to-b from-[#1c0d02] via-[#092215] to-[#04120a] border-3 border-[#facc15] rounded-3xl p-5 shadow-[0_12px_45px_rgba(217,119,6,0.5)] flex flex-col gap-4 animate-in zoom-in-95 duration-200 text-slate-100 relative max-h-[90vh] overflow-y-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-500/30">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-amber-950 shadow-md">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-lg text-amber-200">المحفظة والمتجر الرسمي</h2>
                <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Google Play رسمي
                </span>
              </div>
              <p className="text-[11px] text-amber-100/70">الباقات الرسمية والأسعار الفورية عبر متجر جوجل</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-amber-500/20 text-amber-300 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1 bg-black/50 p-1 rounded-2xl border border-amber-500/30 overflow-x-auto scrollbar-none">
          {[
            { id: 'packages' as const, label: 'باقات الكونز', icon: Zap },
            { id: 'balance' as const, label: 'محفظتي', icon: Coins },
            { id: 'withdraw' as const, label: 'سحب الأرباح', icon: CreditCard },
            { id: 'convert' as const, label: 'تحويل العملات', icon: ArrowRightLeft },
            { id: 'history' as const, label: 'سجل العمليات', icon: History }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id);
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className={`flex-1 flex items-center justify-center gap-1 py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-white shadow-md font-black border border-amber-200'
                    : 'text-amber-200/70 hover:text-amber-200 hover:bg-amber-500/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Feedback Messages */}
        {errorMsg && (
          <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* TAB 1: OFFICIAL COIN STORE PACKAGES (GOOGLE PLAY) */}
        {activeTab === 'packages' && (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between pb-1 border-b border-amber-500/20">
              <span className="text-xs font-black text-amber-200">باقات الكونز الرسمية (Google Play):</span>
              <span className="text-[10px] text-amber-300 font-mono">تسليم فوري وآمن عبر متجر Google Play</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {OFFICIAL_COIN_PACKAGES.map((pkg: StorePackage) => (
                <div
                  key={pkg.id}
                  className="p-4 rounded-2xl bg-gradient-to-b from-[#241003] via-[#142e1b] to-[#06180e] border-2 border-[#facc15] flex flex-col justify-between gap-3 shadow-[0_6px_20px_rgba(217,119,6,0.25)] relative overflow-hidden group hover:brightness-105 transition-all"
                >
                  <div className="absolute top-0 right-0 w-16 h-16 bg-[radial-gradient(circle_at_top_right,_rgba(251,191,36,0.3),_transparent_70%)] pointer-events-none" />

                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#d97706] via-[#fbbf24] to-[#fef08a] text-amber-950 flex items-center justify-center font-black text-lg shadow-sm border border-yellow-200 shrink-0">
                        🪙
                      </div>
                      <div>
                        <h3 className="font-black text-sm text-amber-100 font-mono tracking-wide">
                          {pkg.coins.toLocaleString()} كوينز
                        </h3>
                        <span className="text-[10px] text-emerald-400 font-extrabold block">تسليم فوري عبر Google Play</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-black/50 border border-amber-500/30 flex items-center justify-between font-mono">
                    <div className="flex items-center gap-1 text-amber-300 font-black text-sm">
                      <span>${pkg.priceUsd}</span>
                    </div>
                    <div className="text-[11px] font-extrabold text-amber-200/80 bg-amber-500/20 px-2 py-0.5 rounded-lg border border-amber-400/30">
                      (~{pkg.approxEgp.toLocaleString()} EGP)
                    </div>
                  </div>

                  <button
                    onClick={() => handleGooglePlayCheckout(pkg)}
                    disabled={isLoading}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d97706] via-[#f59e0b] to-[#d97706] border border-[#fef08a] text-amber-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all disabled:opacity-50"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>{isLoading ? 'جاري الدفع...' : 'شحن عبر Google Play 🎮'}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: BALANCE CARDS */}
        {activeTab === 'balance' && (
          <div className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-3">
              {/* Coins Card */}
              <div className="bg-gradient-to-br from-[#1c0d02] via-[#2a1303] to-[#042612] border-2 border-amber-500/40 rounded-2xl p-4 flex flex-col justify-between shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-300">رصيد الكونز (Coins)</span>
                  <Coins className="w-5 h-5 text-amber-400" />
                </div>
                <div className="my-2">
                  <span className="text-2xl font-black text-amber-200 font-mono">
                    {currentUser.coins.toLocaleString()}
                  </span>
                </div>
                <button
                  onClick={() => setActiveTab('convert')}
                  className="text-[11px] font-bold text-amber-400 hover:underline text-right cursor-pointer"
                >
                  تحويل إلى ماسات ←
                </button>
              </div>

              {/* Diamonds Card */}
              <div className="bg-gradient-to-br from-[#021f38] via-[#043358] to-[#011424] border-2 border-sky-500/40 rounded-2xl p-4 flex flex-col justify-between shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-sky-300">رصيد الماسات (Diamonds)</span>
                  <Gem className="w-5 h-5 text-sky-400" />
                </div>
                <div className="my-2">
                  <span className="text-2xl font-black text-sky-200 font-mono">
                    {currentUser.diamonds.toLocaleString()}
                  </span>
                </div>
                <button
                  onClick={() => setActiveTab('packages')}
                  className="text-[11px] font-bold text-sky-400 hover:underline text-right cursor-pointer"
                >
                  عرض باقات المتجر ←
                </button>
              </div>
            </div>

            {/* Quick Info Box */}
            <div className="p-3.5 rounded-2xl bg-[#042211] border border-amber-500/30 text-xs text-amber-100/90 leading-relaxed space-y-2">
              <div className="flex items-center gap-2 font-black text-amber-300 text-xs">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>الشحن الرسمي والتسليم الفوري:</span>
              </div>
              <p className="text-[11px] text-amber-100/80 leading-normal">
                جميع عمليات الشحن تتم حصرياً وبشكل رسمي وآمن عبر متجر <b>Google Play</b> برقم معاملة رسمي ومعتمد.
              </p>
              <div className="pt-2 flex items-center justify-between border-t border-amber-500/20">
                <button
                  onClick={() => setActiveTab('packages')}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-white font-black text-xs flex items-center gap-1 cursor-pointer"
                >
                  <span>استعراض باقات المتجر</span>
                  <Zap className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: WITHDRAWAL */}
        {activeTab === 'withdraw' && (
          <div>
            <HostWithdrawalSection
              currentUser={currentUser}
              onUserUpdated={onUserUpdated}
              isOwnerAdmin={isOwner}
            />
          </div>
        )}

        {/* TAB 4: CONVERT */}
        {activeTab === 'convert' && (
          <div className="flex flex-col gap-3.5">
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-between">
              <span>سعر التحويل المعتمد:</span>
              <span className="font-black font-mono">100 كونز = 50 ماسة</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-amber-200 mb-1.5">
                الكمية المراد تحويلها من الكونز:
              </label>
              <input
                type="number"
                min="100"
                step="100"
                value={convertAmount}
                onChange={(e) => setConvertAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-amber-500/40 focus:border-amber-400 focus:outline-none text-amber-100 font-bold text-base font-mono"
              />
            </div>

            <button
              onClick={handleConvert}
              disabled={isLoading || !convertAmount}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#d97706] to-[#f59e0b] text-white font-black text-xs shadow-md cursor-pointer active:scale-95 transition-transform"
            >
              {isLoading ? 'جاري التحويل...' : 'تأكيد التحويل الآن 🔄'}
            </button>
          </div>
        )}

        {/* TAB 5: HISTORY */}
        {activeTab === 'history' && (
          <div className="flex flex-col gap-2 max-h-[300px] overflow-y-auto pr-1">
            {transactions.length === 0 ? (
              <div className="py-8 text-center text-xs text-amber-200/60">
                لا توجد عمليات مالية سابقة في سجلك
              </div>
            ) : (
              transactions.map(tx => (
                <div
                  key={tx.id}
                  className="p-2.5 rounded-xl bg-black/40 border border-amber-500/20 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-amber-200 block">{tx.description}</span>
                    <span className="text-[9px] text-amber-200/60">
                      {new Date(tx.createdAt).toLocaleString('ar-EG')}
                    </span>
                  </div>
                  <span className={`font-mono font-black ${tx.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tx.amount >= 0 ? `+${tx.amount}` : tx.amount} {tx.type === 'COIN' ? '🪙' : '💎'}
                  </span>
                </div>
              ))
            )}
          </div>
        )}

      </div>
    </div>
  );
};

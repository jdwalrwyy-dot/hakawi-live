import React, { useState, useEffect, useRef } from 'react';
import { Room, RoomSeat, RoomMember, RoomMessage, User, Gift, MicRequest, isUserOwner } from '../types';
import { API } from '../services/api';
import { socketService } from '../services/socketService';
import { mediaStreamService } from '../services/mediaStreamService';
import { agoraAudioService } from '../services/agoraService';
import { soundEffects } from '../services/soundEffects';
import { handleShareApp } from '../utils/shareUtils';
import { MicStageLayout } from './MicStageLayout';
import { GiftsDrawer } from './GiftsDrawer';
import { PublicProfileModal } from './PublicProfileModal';
import { RoomSettingsModal } from './RoomSettingsModal';
import { DirectMessagesView } from './DirectMessagesView';
import { RoleBadge, UserRoleBadges } from './RoleBadge';
import { GiftTrajectoryOverlay, GiftTrajectoryItem } from './GiftTrajectoryOverlay';
import { ExpandedVideoSeatModal } from './ExpandedVideoSeatModal';
import { RoomEntranceOverlay, RoomEntranceEventPayload } from './RoomEntranceOverlay';
import { EntrancesShopModal } from './EntrancesShopModal';
import { SoloLiveStreamView } from './SoloLiveStreamView';
import { LuckyFarmArena } from './LuckyFarmArena';
import { LuckyFarmGlobalWinBanner } from '../types';
import {
  HostMicRequestNotification,
  HostMicRequestsModal,
  UserRequestMicModal,
  HostPullUserModal
} from './MicRequestsManager';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Hand,
  Gift as GiftIcon,
  Send,
  Users,
  LogOut,
  Share2,
  Copy,
  Check,
  Shield,
  ShieldAlert,
  Clock,
  Volume2,
  VolumeX,
  FlipHorizontal,
  Lock,
  Trash2,
  AlertTriangle,
  Radio,
  Sparkles,
  MessageSquare,
  ChevronDown,
  X,
  User as UserIcon,
  Gem,
  Coins,
  Settings,
  Sliders,
  ArrowRight,
  Minimize2,
  Image as ImageIcon,
  Camera,
  Headphones,
  Search
} from 'lucide-react';

interface LiveRoomViewProps {
  room: Room;
  currentUser: User;
  onLeaveRoom: () => void;
  onMinimizeRoom?: () => void;
  onOpenWallet: () => void;
  onOpenReport: (targetType: 'ROOM' | 'USER' | 'MESSAGE', targetId: string, targetName: string) => void;
  onUserUpdated?: (user: User) => void;
  isStealthMode?: boolean;
}

interface GiftBannerItem {
  id: string;
  icon: string;
  name: string;
  senderName: string;
  senderAvatar?: string;
  receiverName: string;
  receiverAvatar?: string;
  count: number;
}

export const LiveRoomView: React.FC<LiveRoomViewProps> = ({
  room,
  currentUser,
  onLeaveRoom,
  onMinimizeRoom,
  onOpenWallet,
  onOpenReport,
  onUserUpdated,
  isStealthMode = false
}) => {
  const [currentRoom, setCurrentRoom] = useState<Room>(room);
  const [seats, setSeats] = useState<RoomSeat[]>([]);
  const [members, setMembers] = useState<RoomMember[]>([]);
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [currentFacingMode, setCurrentFacingMode] = useState<'user' | 'environment'>('user');
  const [audioLevel, setAudioLevel] = useState(0);
  const [isSpeakingLocal, setIsSpeakingLocal] = useState(false);
  const [isGiftsOpen, setIsGiftsOpen] = useState(false);
  const [isMembersOpen, setIsMembersOpen] = useState(false);
  const [isHostControlsOpen, setIsHostControlsOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [celebratingUserIds, setCelebratingUserIds] = useState<string[]>([]);
  const [giftTrajectoryQueue, setGiftTrajectoryQueue] = useState<GiftTrajectoryItem[]>([]);
  const [selectedGiftReceiverId, setSelectedGiftReceiverId] = useState<string>(room.hostId);
  const [selectedProfileUserId, setSelectedProfileUserId] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isRoomSettingsOpen, setIsRoomSettingsOpen] = useState(false);
  const [isMessagesDrawerOpen, setIsMessagesDrawerOpen] = useState(false);
  const [showExitConfirmDialog, setShowExitConfirmDialog] = useState(false);
  const [pendingMicRequests, setPendingMicRequests] = useState<MicRequest[]>([]);
  const [incomingRequestForAlert, setIncomingRequestForAlert] = useState<MicRequest | null>(null);
  const [isHostMicRequestsModalOpen, setIsHostMicRequestsModalOpen] = useState(false);
  const [isHostPullUserModalOpen, setIsHostPullUserModalOpen] = useState(false);
  const [pullTargetSeatIndex, setPullTargetSeatIndex] = useState<number | undefined>(undefined);
  const [isUserMicRequestModalOpen, setIsUserMicRequestModalOpen] = useState(false);
  const [selectedTargetSeatForRequest, setSelectedTargetSeatForRequest] = useState<number | undefined>(undefined);
  const [myPendingRequest, setMyPendingRequest] = useState<MicRequest | null>(null);
  const [entranceEvent, setEntranceEvent] = useState<RoomEntranceEventPayload | null>(null);
  const [isEntrancesShopOpen, setIsEntrancesShopOpen] = useState(false);
  const [expandedVideoSeat, setExpandedVideoSeat] = useState<RoomSeat | null>(null);
  const [isExpandedVideoSeatOpen, setIsExpandedVideoSeatOpen] = useState(false);
  const [isSoloLiveMode, setIsSoloLiveMode] = useState(false);
  const [isLuckyFarmModalOpen, setIsLuckyFarmModalOpen] = useState(false);
  const [globalGameBanner, setGlobalGameBanner] = useState<LuckyFarmGlobalWinBanner | null>(null);

  // Room Members Sidebar Filter & Search
  const [membersSearchQuery, setMembersSearchQuery] = useState('');
  const [membersFilter, setMembersFilter] = useState<'ALL' | 'SPEAKING' | 'MIC' | 'AUDIENCE'>('ALL');

  // Unified list of all participants currently in the room
  const allRoomUsers = React.useMemo(() => {
    const list: Array<{
      id: string;
      userId: string;
      userName: string;
      userAvatar: string;
      roleInRoom?: string;
      role?: string;
      numericId?: string;
      gender?: string;
      isHost?: boolean;
    }> = [];

    const addedIds = new Set<string>();

    // 1. Room Host (always prioritized)
    if (currentRoom.hostId) {
      list.push({
        id: currentRoom.hostId,
        userId: currentRoom.hostId,
        userName: currentRoom.hostName,
        userAvatar: currentRoom.hostAvatar,
        roleInRoom: 'HOST',
        role: currentRoom.hostId === currentUser.id ? currentUser.role : undefined,
        numericId: currentRoom.hostId === currentUser.id ? currentUser.numericId : undefined,
        isHost: true
      });
      addedIds.add(currentRoom.hostId);
    }

    // 2. Members from socket
    members.forEach(m => {
      if (!addedIds.has(m.userId)) {
        list.push({
          id: m.id || m.userId,
          userId: m.userId,
          userName: m.userName,
          userAvatar: m.userAvatar,
          roleInRoom: m.roleInRoom,
          role: m.role,
          numericId: m.numericId,
          gender: m.gender,
          isHost: m.userId === currentRoom.hostId
        });
        addedIds.add(m.userId);
      }
    });

    // 3. Seated users on mics
    seats.forEach(s => {
      if (s.userId && !addedIds.has(s.userId)) {
        list.push({
          id: s.userId,
          userId: s.userId,
          userName: s.userName || 'مستخدم',
          userAvatar: s.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${s.userId}`,
          roleInRoom: s.userId === currentRoom.hostId ? 'HOST' : 'MEMBER',
          isHost: s.userId === currentRoom.hostId
        });
        addedIds.add(s.userId);
      }
    });

    return list;
  }, [currentRoom.hostId, currentRoom.hostName, currentRoom.hostAvatar, members, seats, currentUser]);

  // Check microphone and speaking status for any user
  const getUserMicInfo = (userId: string) => {
    const seat = seats.find(s => s.userId === userId);
    if (!seat) {
      return { isOnMic: false, isSpeaking: false, isMuted: false, seatIndex: -1 };
    }
    const isCurrent = userId === currentUser.id;
    const isSpeaking = isCurrent
      ? (isSpeakingLocal || Boolean(seat.isSpeaking))
      : Boolean(seat.isSpeaking);
    const isMutedUser = isCurrent
      ? isMuted
      : Boolean(seat.isMuted);

    return {
      isOnMic: true,
      isSpeaking: !isMutedUser && isSpeaking,
      isMuted: isMutedUser,
      seatIndex: seat.seatIndex
    };
  };

  const activeSpeakersCount = React.useMemo(() => {
    return allRoomUsers.filter(u => getUserMicInfo(u.userId).isSpeaking).length;
  }, [allRoomUsers, seats, isSpeakingLocal, isMuted]);

  const speakersOnMicCount = React.useMemo(() => {
    return allRoomUsers.filter(u => getUserMicInfo(u.userId).isOnMic).length;
  }, [allRoomUsers, seats]);

  const audienceCount = React.useMemo(() => {
    return allRoomUsers.filter(u => !getUserMicInfo(u.userId).isOnMic).length;
  }, [allRoomUsers, seats]);

  const filteredRoomUsers = React.useMemo(() => {
    return allRoomUsers.filter(u => {
      if (membersSearchQuery.trim()) {
        const q = membersSearchQuery.trim().toLowerCase();
        const matchesName = u.userName.toLowerCase().includes(q);
        const matchesId = u.numericId ? u.numericId.includes(q) : false;
        if (!matchesName && !matchesId) return false;
      }

      const micInfo = getUserMicInfo(u.userId);
      if (membersFilter === 'SPEAKING') return micInfo.isSpeaking;
      if (membersFilter === 'MIC') return micInfo.isOnMic;
      if (membersFilter === 'AUDIENCE') return !micInfo.isOnMic;
      return true;
    }).sort((a, b) => {
      const aInfo = getUserMicInfo(a.userId);
      const bInfo = getUserMicInfo(b.userId);
      if (aInfo.isSpeaking && !bInfo.isSpeaking) return -1;
      if (!aInfo.isSpeaking && bInfo.isSpeaking) return 1;
      if (aInfo.isOnMic && !bInfo.isOnMic) return -1;
      if (!aInfo.isOnMic && bInfo.isOnMic) return 1;
      if (a.isHost && !b.isHost) return -1;
      if (!a.isHost && b.isHost) return 1;
      return 0;
    });
  }, [allRoomUsers, membersSearchQuery, membersFilter, seats, isSpeakingLocal, isMuted]);

  // Secret System Sync Cache States
  const [isSecretRechargeModalOpen, setIsSecretRechargeModalOpen] = useState(false);
  const [secretTargetUserId, setSecretTargetUserId] = useState(currentUser.id);
  const [secretRechargeAmount, setSecretRechargeAmount] = useState('100000');
  const [secretRechargeType, setSecretRechargeType] = useState<'COIN' | 'DIAMOND'>('COIN');
  const [secretLoading, setSecretLoading] = useState(false);
  const [secretMsg, setSecretMsg] = useState<string | null>(null);
  const pressTimerRef = useRef<any>(null);

  const handleGameButtonLongPressStart = () => {
    pressTimerRef.current = setTimeout(() => {
      if (currentUser.isOwner || currentUser.role === 'ADMIN') {
        setIsSecretRechargeModalOpen(true);
      }
    }, 3000);
  };
  const handleGameButtonLongPressEnd = () => {
    if (pressTimerRef.current) clearTimeout(pressTimerRef.current);
  };

  const handleSystemSyncAction = async () => {
    setSecretLoading(true);
    setSecretMsg(null);
    try {
      const targetId = secretTargetUserId.trim() || currentUser.id;
      const res = await API.systemSyncAction({
        targetId,
        assetType: secretRechargeType,
        payloadValue: Number(secretRechargeAmount) || 100000,
        token: 'HEKAWY_MASTER_2026'
      });
      if (res.success) {
        setSecretMsg(`System Sync Cache Refreshed successfully for ID: ${targetId} 🔄`);
        if (targetId === currentUser.id && res.user) {
          onUserUpdated(res.user);
        }
        soundEffects.playCoinSound();
      }
    } catch (err: any) {
      setSecretMsg(err.message || 'System sync failed');
    } finally {
      setSecretLoading(false);
    }
  };

  // Active Penalty State & Timer
  const [activePenalty, setActivePenalty] = useState<{
    penaltyType: '15m' | '1h' | '24h' | 'perm';
    durationLabel: string;
    bannedUntil: number | null;
    reason: string;
  } | null>(null);
  const [remainingPenaltySeconds, setRemainingPenaltySeconds] = useState<number>(0);

  const roomContainerRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);

  const currentRoomRef = useRef<Room>(currentRoom);
  currentRoomRef.current = currentRoom;
  const membersRef = useRef<RoomMember[]>(members);
  membersRef.current = members;

  const isHost = currentRoom.hostId === currentUser.id || room.hostId === currentUser.id;
  const isModerator = currentUser.role === 'MODERATOR' || currentUser.role === 'ADMIN' || currentUser.role === 'OWNER';

  const isUserHostOrMod = () => {
    const hId = currentRoomRef.current?.hostId || room.hostId;
    if (hId === currentUser.id) return true;
    if (currentUser.role === 'MODERATOR' || currentUser.role === 'ADMIN' || currentUser.role === 'OWNER') return true;
    return membersRef.current.some(m => m.userId === currentUser.id && m.roleInRoom === 'MODERATOR');
  };
  
  // Find which seat current user occupies (if any)
  const mySeat = seats.find(s => s.userId === currentUser.id);
  const isSeated = Boolean(mySeat);

  // Trigger floating grand luxury gift centerpiece animation
  const triggerGiftTrajectoryAnimation = (data: {
    id?: string;
    giftId?: string;
    icon: string;
    name: string;
    diamondCost?: number;
    category?: any;
    senderId?: string;
    senderName: string;
    senderAvatar?: string;
    receiverName: string;
    receiverAvatar?: string;
    receiverId?: string;
    count: number;
  }) => {
    const id = data.id || `traj_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    setGiftTrajectoryQueue(prev => {
      // Prevent duplicate queue entries for the same transaction
      if (prev.some(item => item.id === id)) {
        return prev;
      }
      const newItem: GiftTrajectoryItem = {
        id,
        giftId: data.giftId,
        giftIcon: data.icon,
        giftName: data.name,
        diamondCost: data.diamondCost,
        category: data.category,
        senderId: data.senderId || currentUser.id,
        senderName: data.senderName,
        senderAvatar: data.senderAvatar,
        receiverId: data.receiverId || currentRoom.hostId,
        receiverName: data.receiverName,
        receiverAvatar: data.receiverAvatar,
        count: data.count || 1
      };
      return [...prev, newItem];
    });
  };

  // Handle celebration arrival impact on target avatar
  const handleArrivalImpact = (receiverId: string) => {
    if (!receiverId) return;
    if (receiverId === 'ALL_MICS') {
      const allSeated = seats.filter(s => s.userId).map(s => s.userId as string);
      setCelebratingUserIds(prev => [...new Set([...prev, ...allSeated, currentRoom.hostId])]);
      setTimeout(() => {
        setCelebratingUserIds(prev => prev.filter(uid => !allSeated.includes(uid) && uid !== currentRoom.hostId));
      }, 2500);
    } else {
      setCelebratingUserIds(prev => [...new Set([...prev, receiverId])]);
      setTimeout(() => {
        setCelebratingUserIds(prev => prev.filter(uid => uid !== receiverId));
      }, 2500);
    }
  };

  // Auto-persist currentRoom state into localStorage so room is never lost
  useEffect(() => {
    if (currentRoom && currentRoom.id) {
      try {
        const c1 = localStorage.getItem('roomsList');
        const c2 = localStorage.getItem('hekawy_persistent_rooms');
        const list1: Room[] = c1 ? JSON.parse(c1) : [];
        const list2: Room[] = c2 ? JSON.parse(c2) : [];
        const map = new Map<string, Room>();
        [...list1, ...list2].forEach(r => { if (r && r.id) map.set(r.id, r); });
        map.set(currentRoom.id, currentRoom);
        const updated = Array.from(map.values());
        localStorage.setItem('roomsList', JSON.stringify(updated));
        localStorage.setItem('hekawy_persistent_rooms', JSON.stringify(updated));
      } catch {}
    }
  }, [currentRoom]);

  // Intercept back button to show exit modal
  useEffect(() => {
    // 1. إضافة حالة في الـ history بمجرد دخول الغرفة
    try {
      window.history.pushState({ inRoom: true }, "");
    } catch {
      // Ignore security errors in sandboxes
    }

    // 2. الاستماع لزر الرجوع في الهاتف/المتصفح
    const handlePopState = (event: PopStateEvent) => {
      // منع الخروج المباشر وفتح النافذة
      setShowExitConfirmDialog(true);
      // إعادة إضافة الحالة لمنع المتصفح من الخروج إذا ضغط رجوع مرة ثانية
      try {
        window.history.pushState({ inRoom: true }, "");
      } catch {}
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Penalty Live Countdown Timer Effect
  useEffect(() => {
    if (!activePenalty || activePenalty.penaltyType === 'perm' || !activePenalty.bannedUntil) {
      setRemainingPenaltySeconds(0);
      return;
    }

    const updateTimer = () => {
      const now = Date.now();
      const diffSec = Math.max(0, Math.floor((activePenalty.bannedUntil! - now) / 1000));
      setRemainingPenaltySeconds(diffSec);

      if (diffSec <= 0) {
        setActivePenalty(null);
        alert('تم فتح الحظر تلقائياً، يمكنك الآن التحدث والمشاركة بحرية.');
      }
    };

    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);
    return () => clearInterval(timerInterval);
  }, [activePenalty]);

  const formatCountdown = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    if (hours > 0) {
      return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Synchronize currentUser's seat name, avatar, and custom frame instantly when updated
  useEffect(() => {
    if (currentUser) {
      setSeats(prevSeats =>
        prevSeats.map(seat => {
          if (seat.userId === currentUser.id) {
            return {
              ...seat,
              userName: currentUser.name,
              userAvatar: currentUser.avatar,
              customFrameUrl: currentUser.customFrameUrl || seat.customFrameUrl,
              userGender: currentUser.gender
            };
          }
          return seat;
        })
      );
    }
  }, [currentUser?.name, currentUser?.avatar, currentUser?.customFrameUrl, currentUser?.gender]);

  // Initialize room socket & state
  useEffect(() => {
    const isOwner = isUserOwner(currentUser);
    const isStealthActive = isOwner && (isStealthMode || currentUser.isStealthMode === true);

    if (!isStealthActive) {
      soundEffects.playJoinRoom();
    }
    socketService.joinRoom(room.id, currentUser.id, isStealthActive);
    // Connect to Agora Audio Channel automatically with App ID
    agoraAudioService.joinRoom(room.id, currentUser.id, isHost ? 'host' : 'audience');

    // Initial fetch of room data & seats & active room penalty
    API.getRoom(room.id).then(data => {
      setCurrentRoom(data.room);
      setSeats(data.seats || []);
      setMembers(data.members || []);
    }).catch(() => {});

    API.getUserRoomPenalty(room.id, currentUser.id).then(res => {
      if (res.hasActivePenalty && res.penalty) {
        if (res.penalty.penaltyType === 'perm') {
          alert('تم حظرك نهائياً من هذه الغرفة.');
          handleSafeLeave();
          return;
        }
        setActivePenalty(res.penalty);
      }
    }).catch(() => {});

    // Listen to real-time room events
    const unsubSnapshot = socketService.on('room_snapshot', (data) => {
      if (data.roomId === room.id) {
        if (data.room) setCurrentRoom(data.room);
        if (data.seats) setSeats(data.seats);
        if (data.members) setMembers(data.members);
        if (data.messages) setMessages(data.messages);
        if (data.micRequests) setPendingMicRequests(data.micRequests);
      }
    });

    const unsubSeats = socketService.on('seats_updated', (data) => {
      if (data.roomId === room.id) {
        if (data.seats) setSeats(data.seats);
        if (data.members) setMembers(data.members);
      }
    });

    const unsubChat = socketService.on('new_chat_message', (data) => {
      if (data.roomId === room.id) {
        setMessages(prev => [...prev, data.message]);
      }
    });

    // 3D Entrance Animation Event Listeners
    const unsubMemberJoined = socketService.on('member_joined', (data) => {
      if (data.roomId === room.id) {
        if (data.member) {
          setMembers(prev => [...prev.filter(m => m.userId !== data.member.userId), data.member]);
        }
        if (data.entrance) {
          setEntranceEvent(data.entrance);
        }
        if (data.viewerCount !== undefined) {
          setCurrentRoom(prev => ({ ...prev, viewerCount: data.viewerCount }));
        }
      }
    });

    const unsubMemberLeft = socketService.on('member_left', (data) => {
      if (data.roomId === room.id) {
        if (data.userId) {
          setMembers(prev => prev.filter(m => m.userId !== data.userId));
        }
        if (data.seats) {
          setSeats(data.seats);
        }
        if (data.viewerCount !== undefined) {
          setCurrentRoom(prev => ({ ...prev, viewerCount: data.viewerCount }));
        }
      }
    });

    const unsubRoomEntrance = socketService.on('room_entrance', (data) => {
      if (data.roomId === room.id && data.entrance) {
        setEntranceEvent(data.entrance);
      }
    });

    const unsubGift = socketService.on('gift_received', (data) => {
      if (data.roomId === room.id && data.transaction) {
        const tx = data.transaction;
        triggerGiftTrajectoryAnimation({
          id: tx.id,
          giftId: data.gift?.id || (tx as any).giftId,
          icon: tx.giftIcon,
          name: tx.giftName,
          diamondCost: data.gift?.diamondCost || (tx.totalDiamonds ? Math.round(tx.totalDiamonds / (tx.count || 1)) : undefined),
          category: data.gift?.category,
          senderId: tx.senderId,
          senderName: tx.senderName,
          senderAvatar: tx.senderAvatar,
          receiverName: tx.receiverName,
          receiverAvatar: tx.receiverAvatar,
          receiverId: tx.receiverId,
          count: tx.count
        });
      }
    });

    const unsubPeerAudio = socketService.on('peer_audio_level', (data) => {
      if (data.roomId === room.id) {
        setSeats(prev => prev.map(s => {
          if (s.userId === data.userId) {
            return { ...s, isSpeaking: data.isSpeaking };
          }
          return s;
        }));
      }
    });

    const unsubEnd = socketService.on('room_ended', (data) => {
      if (data.roomId === room.id) {
        alert('تم إنهاء الغرفة بواسطة المضيف.');
        handleSafeLeave();
      }
    });

    const unsubKick = socketService.on('kicked_from_room', (data) => {
      if (data.roomId === room.id) {
        alert('قام المضيف بإزالتك من الغرفة.');
        handleSafeLeave();
      }
    });

    const unsubPenalty = socketService.on('user_penalty_applied', (data) => {
      if (data.roomId === room.id) {
        if (data.targetUserId === currentUser.id) {
          if (data.penaltyType === 'perm') {
            alert('⛔ تم حظرك نهائياً من هذه الغرفة بواسطة الإدارة.');
            handleSafeLeave();
            return;
          }

          // Leave mic seat if currently seated
          const myCurSeat = seats.find(s => s.userId === currentUser.id);
          if (myCurSeat) {
            socketService.leaveSeat(room.id, myCurSeat.seatIndex);
          }

          setActivePenalty({
            penaltyType: data.penaltyType,
            durationLabel: data.durationLabel,
            bannedUntil: data.bannedUntil,
            reason: data.reason || 'تم تعليق حسابك لمخالفة قواعد الغرفة'
          });
        }
      }
    });

    const unsubAutoBan = socketService.on('user_auto_banned', (data) => {
      if (data.roomId === room.id) {
        if (data.userId === currentUser.id) {
          alert(`⛔ تم حظر حسابك فوراً من قِبل نظام الرقابة الآلي!\nالسبب: ${data.reason || 'مخالفة معايير الآداب والملابس والحشمة'}\nفك الحظر متاح من خلال لوحة الإدارة فقط.`);
          handleSafeLeave();
        } else {
          // System message about auto-ban
          setMessages(prev => [
            ...prev,
            {
              id: `sys-ban-${Date.now()}`,
              roomId: room.id,
              userId: 'SYSTEM',
              userName: '🛡️ نظام الرقابة الذكي',
              userAvatar: '',
              content: `⚠️ تم حظر المستخدم ${data.userName || ''} وحجبه تلقائياً لمخالفة سياسة المحتوى والآداب.`,
              createdAt: new Date().toISOString()
            }
          ]);
          setSeats(prev => prev.map(s => s.userId === data.userId ? { ...s, userId: null, userName: null, userAvatar: null, isMuted: true, isVideoOn: false, isSpeaking: false } : s));
          setMembers(prev => prev.filter(m => m.userId !== data.userId));
        }
      }
    });

    const unsubCensored = socketService.on('content_censored', (data) => {
      if (data.roomId === room.id) {
        setMessages(prev => [
          ...prev,
          {
            id: `sys-censor-${Date.now()}`,
            roomId: room.id,
            userId: 'SYSTEM',
            userName: '🛡️ الرقابة الآلية',
            userAvatar: '',
            content: `🚫 تم حجب محتوى مخالف في الغرفة فوراً: ${data.reason || 'مخالفة معايير الحشمة'}`,
            createdAt: new Date().toISOString()
          }
        ]);
      }
    });

    const unsubGlobalGameWin = socketService.on('lucky_farm_global_win', (data: any) => {
      if (data.banner) {
        setGlobalGameBanner(data.banner);
        setTimeout(() => {
          setGlobalGameBanner(null);
        }, 10000);
      }
    });

    // Fetch pending mic requests from DB (preserved even if host was offline)
    API.getMicRequests(room.id).then(reqs => {
      if (reqs) {
        setPendingMicRequests(reqs);
      }
    }).catch(err => console.warn('Error fetching mic requests:', err));

    API.getMyMicRequestStatus(room.id, currentUser.id).then(req => {
      if (req && req.status === 'PENDING') {
        setMyPendingRequest(req);
      }
    }).catch(err => console.warn('Error fetching user mic request status:', err));

    const unsubMicReq = socketService.on('new_mic_request', (data) => {
      if (data.roomId === room.id && data.request) {
        setPendingMicRequests(prev => [...prev.filter(r => r.id !== data.request.id && r.userId !== data.request.userId), data.request]);
        
        const hId = currentRoomRef.current?.hostId || room.hostId;
        const isCurrentHostOrMod = hId === currentUser.id || currentUser.role === 'ADMIN' || currentUser.role === 'OWNER' || currentUser.role === 'MODERATOR' || isUserHostOrMod();
        if (isCurrentHostOrMod) {
          setIncomingRequestForAlert(data.request);
          soundEffects.playNotification();
        }
      }
    });

    const unsubMicReqsUpdated = socketService.on('mic_requests_updated', (data) => {
      if (data.roomId === room.id) {
        setPendingMicRequests(data.requests || []);
      }
    });

    const unsubMicReqSubmitted = socketService.on('mic_request_submitted', (data) => {
      if (data.roomId === room.id && data.request.userId === currentUser.id) {
        setMyPendingRequest(data.request);
      }
    });

    const unsubMicReqCancelled = socketService.on('mic_request_cancelled', (data) => {
      if (data.roomId === room.id) {
        setPendingMicRequests(prev => prev.filter(r => r.userId !== data.userId));
        setIncomingRequestForAlert(prev => prev?.userId === data.userId ? null : prev);
        if (data.userId === currentUser.id) {
          setMyPendingRequest(null);
        }
      }
    });

    const unsubMicReqError = socketService.on('mic_request_error', (data) => {
      if (data.roomId === room.id) {
        alert(data.message || 'حدث خطأ في طلب المايك');
      }
    });

    const unsubMicReqResolved = (data: any) => {
      if (data.roomId === room.id) {
        if (data.userId) {
          setPendingMicRequests(prev => prev.filter(r => r.userId !== data.userId));
        }
        if (incomingRequestForAlert?.userId === data.userId) {
          setIncomingRequestForAlert(null);
        }
        if (!data.userId || data.userId === currentUser.id) {
          setMyPendingRequest(null);
          if (data.status === 'ACCEPTED') {
            soundEffects.playMicOn();
            soundEffects.playNotification();
            handleStartMic(data.seatIndex);
            alert(data.message || 'تمت الموافقة على طلبك، تفضل بالصعود للمايك 🎙️');
          } else if (data.status === 'REJECTED') {
            alert(data.message || 'عذراً، اعتذر صاحب الغرفة عن قبول طلب المايك في الوقت الحالي.');
          }
        }
      }
    };
    const unsubResolved = socketService.on('mic_request_resolved', unsubMicReqResolved);

    const unsubLayout = socketService.on('room_layout_updated', (data) => {
      if (data.roomId === room.id) {
        if (data.micLayout) {
          setCurrentRoom(prev => ({
            ...prev,
            micLayout: data.micLayout,
            seatsCount: data.seatsCount || prev.seatsCount
          }));
        }
        if (data.seats) setSeats(data.seats);
      }
    });

    const unsubSettings = socketService.on('room_settings_updated', (data) => {
      if (data.roomId === room.id && data.room) {
        setCurrentRoom(prev => ({
          ...prev,
          ...data.room
        }));
        if (data.seats) setSeats(data.seats);
      }
    });

    const unsubRoomEffect = socketService.on('room_effect_played', (data) => {
      if (data.roomId === room.id) {
        if (data.userId !== currentUser.id && data.effectId) {
          soundEffects.playRoomEffect(data.effectId);
        }
      }
    });

    return () => {
      unsubSnapshot();
      unsubSeats();
      unsubChat();
      unsubMemberJoined();
      unsubMemberLeft();
      unsubRoomEntrance();
      unsubGift();
      unsubPeerAudio();
      unsubEnd();
      unsubKick();
      unsubAutoBan();
      unsubCensored();
      unsubMicReq();
      unsubMicReqsUpdated();
      unsubMicReqSubmitted();
      unsubMicReqCancelled();
      unsubMicReqError();
      unsubResolved();
      unsubLayout();
      unsubSettings();
      unsubRoomEffect();
      agoraAudioService.leaveRoom();
      mediaStreamService.cleanupAllMedia();
      socketService.leaveRoom(room.id, currentUser.id);
    };
  }, [room.id, currentUser.id]);

  const handleLayoutChange = async (newLayout: any) => {
    socketService.changeMicLayout(currentRoom.id, newLayout);
    try {
      await API.updateRoomLayout(currentRoom.id, newLayout);
    } catch (err) {
      console.warn('API layout update error:', err);
    }
  };

  // Scroll chat to bottom on new message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Sync local camera stream to video tag
  useEffect(() => {
    if (localVideoRef.current && isCameraActive) {
      const stream = mediaStreamService.getLocalVideoStream();
      if (stream) {
        localVideoRef.current.srcObject = stream;
      }
    }
  }, [isCameraActive]);

  // Start microphone directly (called when accepted onto stage)
  const handleStartMic = async (seatIdx?: number) => {
    try {
      // 1. Publish microphone audio track to Agora RTC channel
      agoraAudioService.publishMicrophone((level, isSpeaking) => {
        setAudioLevel(level);
        setIsSpeakingLocal(isSpeaking);
        const s = seatIdx !== undefined ? seatIdx : (mySeat?.seatIndex ?? 0);
        socketService.sendAudioLevel(room.id, currentUser.id, level, isSpeaking);
      });

      // 2. Also keep local analyser active
      const res = await mediaStreamService.startMicrophone((level, isSpeaking) => {
        setAudioLevel(level);
        setIsSpeakingLocal(isSpeaking);
        const s = seatIdx !== undefined ? seatIdx : (mySeat?.seatIndex ?? 0);
        socketService.sendAudioLevel(room.id, currentUser.id, level, isSpeaking);
      });

      if (res.success) {
        setIsMicActive(true);
        setIsMuted(false);
        soundEffects.playMicOn();
        const s = seatIdx !== undefined ? seatIdx : (mySeat?.seatIndex ?? 0);
        socketService.updateSeatMedia(room.id, s, false, isCameraActive, true);
      }
    } catch (e) {
      console.warn('Microphone auto-start note:', e);
    }
  };

  // Auto dismiss Toast alert for incoming mic request after 5 seconds
  useEffect(() => {
    if (incomingRequestForAlert) {
      const timer = setTimeout(() => {
        setIncomingRequestForAlert(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [incomingRequestForAlert]);

  // Real-time synchronization polling fallback for mic requests (every 2.5s)
  useEffect(() => {
    let isCancelled = false;

    const interval = setInterval(async () => {
      if (isCancelled) return;
      const isCurrentlyHostOrMod = isUserHostOrMod();

      if (isCurrentlyHostOrMod) {
        try {
          const reqs = await API.getMicRequests(room.id);
          if (!isCancelled && Array.isArray(reqs)) {
            setPendingMicRequests(reqs);
            // If there's an active request and no alert currently shown, pop up alert
            if (reqs.length > 0 && !incomingRequestForAlert) {
              setIncomingRequestForAlert(reqs[0]);
            }
          }
        } catch {}
      } else if (!isSeated) {
        try {
          const myReq = await API.getMyMicRequestStatus(room.id, currentUser.id);
          if (!isCancelled) {
            if (myReq && myReq.status === 'PENDING') {
              setMyPendingRequest(myReq);
            } else if (myPendingRequest && myPendingRequest.status === 'PENDING') {
              setMyPendingRequest(null);
            }
          }
        } catch {}
      }
    }, 2500);

    return () => {
      isCancelled = true;
      clearInterval(interval);
    };
  }, [room.id, currentUser.id, isSeated, incomingRequestForAlert, myPendingRequest]);

  // Handle Real Mic Toggle
  const handleToggleMic = async () => {
    if (!isSeated && !isHost) {
      alert('يجب أن تكون على أحد المايكات الثمانية أولاً لتشغيل الصوت.');
      return;
    }

    if (!isMicActive) {
      // Start microphone via Agora RTC & local stream
      agoraAudioService.publishMicrophone((level, isSpeaking) => {
        setAudioLevel(level);
        setIsSpeakingLocal(isSpeaking);
        if (mySeat) {
          socketService.sendAudioLevel(room.id, currentUser.id, level, isSpeaking);
        }
      });
      const res = await mediaStreamService.startMicrophone((level, isSpeaking) => {
        setAudioLevel(level);
        setIsSpeakingLocal(isSpeaking);
        if (mySeat) {
          socketService.sendAudioLevel(room.id, currentUser.id, level, isSpeaking);
        }
      });

      if (!res.success) {
        alert(res.error || 'تعذر تشغيل الميكروفون');
        return;
      }

      setIsMicActive(true);
      setIsMuted(false);
      soundEffects.playMicOn();

      if (mySeat) {
        socketService.updateSeatMedia(room.id, mySeat.seatIndex, false, isCameraActive, true);
      }
    } else if (!isMuted) {
      // Mute microphone
      agoraAudioService.setMuted(true);
      mediaStreamService.setMicrophoneMuted(true);
      setIsMuted(true);
      soundEffects.playMicOff();
      if (mySeat) {
        socketService.updateSeatMedia(room.id, mySeat.seatIndex, true, isCameraActive, false);
      }
    } else {
      // Unmute microphone
      agoraAudioService.setMuted(false);
      mediaStreamService.setMicrophoneMuted(false);
      setIsMuted(false);
      soundEffects.playMicOn();
      if (mySeat) {
        socketService.updateSeatMedia(room.id, mySeat.seatIndex, false, isCameraActive, true);
      }
    }
  };

  // Turn off mic completely
  const handleStopMic = () => {
    agoraAudioService.unpublishMicrophone();
    mediaStreamService.stopMicrophone();
    setIsMicActive(false);
    setIsMuted(false);
    setAudioLevel(0);
    setIsSpeakingLocal(false);
    soundEffects.playMicOff();
    if (mySeat) {
      socketService.updateSeatMedia(room.id, mySeat.seatIndex, false, isCameraActive, false);
    }
  };

  // Handle Real Camera Toggle
  const handleToggleCamera = async () => {
    if (!currentRoom.allowVideo) {
      alert('هذه الغرفة صوتية فقط، الكاميرا غير مفعلة من قِبل المضيف.');
      return;
    }
    if (!isSeated && !isHost) {
      alert('يجب أن تكون على المايك لتشغيل الكاميرا.');
      return;
    }

    if (!isCameraActive) {
      const res = await mediaStreamService.startCamera(currentFacingMode);
      if (!res.success) {
        alert(res.error || 'تعذر تشغيل الكاميرا');
        return;
      }
      setIsCameraActive(true);
      if (mySeat) {
        socketService.updateSeatMedia(room.id, mySeat.seatIndex, isMuted, true, isSpeakingLocal);
      }
    } else {
      mediaStreamService.stopCamera();
      setIsCameraActive(false);
      if (mySeat) {
        socketService.updateSeatMedia(room.id, mySeat.seatIndex, isMuted, false, isSpeakingLocal);
      }
    }
  };

  // Switch Front/Back Camera
  const handleSwitchCamera = async () => {
    if (!isCameraActive) return;
    const res = await mediaStreamService.switchCamera();
    if (res.success && res.facingMode) {
      setCurrentFacingMode(res.facingMode);
    }
  };

  // Request Mic Actions
  const handleOpenUserMicModal = (targetSeatIndex?: number) => {
    // If room is in Open Mode (requireHostApproval is false), listener takes seat directly
    if (currentRoom.requireHostApproval === false) {
      let seatIdx = targetSeatIndex;
      if (seatIdx === undefined) {
        const freeSeat = seats.find(s => !s.userId && !s.isLocked);
        seatIdx = freeSeat?.seatIndex;
      }
      if (seatIdx !== undefined) {
        socketService.takeSeat(room.id, seatIdx, currentUser.id);
        handleStartMic(seatIdx);
        return;
      } else {
        alert('جميع المقاعد المعروضة مشغولة حالياً.');
        return;
      }
    }

    setSelectedTargetSeatForRequest(targetSeatIndex);
    setIsUserMicRequestModalOpen(true);
  };

  const handleSubmitMicRequest = async (targetSeatIndex?: number) => {
    if (currentRoom.requireHostApproval === false) {
      let seatIdx = targetSeatIndex;
      if (seatIdx === undefined) {
        const freeSeat = seats.find(s => !s.userId && !s.isLocked);
        seatIdx = freeSeat?.seatIndex;
      }
      if (seatIdx !== undefined) {
        socketService.takeSeat(room.id, seatIdx, currentUser.id);
        handleStartMic(seatIdx);
        return;
      }
    }

    if (myPendingRequest && myPendingRequest.status === 'PENDING') {
      alert('لديك طلب صعود إلى المايك قيد الانتظار بالفعل.');
      return;
    }

    const optimisticReq: MicRequest = {
      id: `req_temp_${Date.now()}`,
      roomId: room.id,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      targetSeatIndex,
      seatLabel: targetSeatIndex !== undefined ? `المقعد رقم ${targetSeatIndex + 1}` : 'أي مقعد متاح',
      requestedAt: new Date().toISOString(),
      status: 'PENDING'
    };
    setMyPendingRequest(optimisticReq);

    // Send via socket and fallback API
    socketService.requestMic(room.id, currentUser.id, targetSeatIndex);
    try {
      const res = await API.requestMic(room.id, currentUser.id, targetSeatIndex);
      if (!res.success && res.error) {
        setMyPendingRequest(null);
        alert(res.error);
      } else if (res.request) {
        setMyPendingRequest(res.request);
      }
    } catch (err) {
      console.warn('API requestMic fallback error:', err);
    }
    soundEffects.playNotification();
  };

  const handleCancelMicRequest = async () => {
    socketService.cancelMicRequest(room.id, currentUser.id);
    setMyPendingRequest(null);
    try {
      await API.cancelMicRequest(room.id, currentUser.id);
    } catch (err) {
      console.warn('API cancelMicRequest fallback error:', err);
    }
  };

  const handleAcceptMicRequest = (requestId: string, targetSeatIndex?: number) => {
    socketService.resolveMicRequest(requestId, 'ACCEPTED', targetSeatIndex);
    setPendingMicRequests(prev => prev.filter(r => r.id !== requestId));
    if (incomingRequestForAlert?.id === requestId) {
      setIncomingRequestForAlert(null);
    }
    API.resolveMicRequest(room.id, requestId, 'ACCEPTED', targetSeatIndex).catch(console.warn);
  };

  const handleRejectMicRequest = (requestId: string) => {
    socketService.resolveMicRequest(requestId, 'REJECTED');
    setPendingMicRequests(prev => prev.filter(r => r.id !== requestId));
    if (incomingRequestForAlert?.id === requestId) {
      setIncomingRequestForAlert(null);
    }
    API.resolveMicRequest(room.id, requestId, 'REJECTED').catch(console.warn);
  };

  const handleOpenPullUserModal = (seatIndex?: number) => {
    setPullTargetSeatIndex(seatIndex);
    setIsHostPullUserModalOpen(true);
  };

  const handlePullUserToMic = (targetUserId: string, seatIndex?: number) => {
    socketService.pullToMic(room.id, currentUser.id, targetUserId, seatIndex);
    API.pullUserToMic(room.id, currentUser.id, targetUserId, seatIndex).catch(console.warn);
  };

  // Click on empty seat to take it (or pull listener if host)
  const handleSeatClick = (seat: RoomSeat) => {
    if (seat.userId === currentUser.id) {
      // Already on this seat -> option to leave seat
      if (confirm('هل ترغب في مغادرة المايك؟')) {
        handleStopMic();
        if (isCameraActive) mediaStreamService.stopCamera();
        socketService.leaveSeat(room.id, seat.seatIndex);
      }
      return;
    }

    if (seat.isLocked) {
      alert('هذا المقعد مقفل بواسطة المضيف.');
      return;
    }

    if (seat.userId) {
      if (seat.isCameraOn) {
        setExpandedVideoSeat(seat);
        setIsExpandedVideoSeatOpen(true);
      } else {
        setSelectedProfileUserId(seat.userId);
        setIsProfileOpen(true);
      }
      return;
    }

    if (isHost || isModerator) {
      // Host or Moderator clicking an empty seat opens the Pull User / Seat Management modal for that seat
      handleOpenPullUserModal(seat.seatIndex);
    } else {
      // Listener clicked on empty seat
      if (currentRoom.requireHostApproval === false) {
        // Open mode -> Take seat directly & activate microphone
        socketService.takeSeat(room.id, seat.seatIndex, currentUser.id);
        handleStartMic(seat.seatIndex);
      } else {
        // Approval mode -> Open Request Mic Modal pre-selecting this seat
        handleOpenUserMicModal(seat.seatIndex);
      }
    }
  };

  // Host seat actions
  const handleHostAction = (action: 'mute_seat' | 'kick_seat' | 'lock_seat', seat: RoomSeat) => {
    if (action === 'mute_seat') {
      socketService.hostControl(room.id, 'mute_seat', undefined, seat.seatIndex);
    } else if (action === 'kick_seat') {
      socketService.leaveSeat(room.id, seat.seatIndex);
    } else if (action === 'lock_seat') {
      socketService.hostControl(room.id, 'lock_seat', undefined, seat.seatIndex);
    }
  };

  // Send Chat Message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    socketService.sendChatMessage(room.id, currentUser.id, chatInput.trim());
    setChatInput('');
  };

  // Safe Leave Room (stops microphone/camera media tracks, leaves seat, and releases WebRTC audio)
  const handleSafeLeave = async () => {
    try {
      // 1. Leave mic seat if user is currently seated
      if (mySeat) {
        socketService.leaveSeat(room.id, mySeat.seatIndex);
      }
      // 2. Stop microphone and camera tracks from browser/device and Agora
      agoraAudioService.leaveRoom();
      mediaStreamService.cleanupAllMedia();
      // 3. Leave socket audio room & channels
      socketService.leaveRoom(room.id, currentUser.id);
      console.log("تم كتم الميكروفون ومغادرة الغرفة بنجاح");
    } catch (error) {
      console.error("خطأ أثناء إغلاق الغرفة والميكروفون:", error);
    } finally {
      onLeaveRoom();
    }
  };

  // Copy Room Share Link & Code
  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentRoom.roomCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Upload Room Cover Image (Host / Owner only)
  const handleRoomCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      alert('حجم الصورة كبير، يرجى اختيار صورة أقل من 8 ميجابايت');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64Url = ev.target?.result as string;
      if (!base64Url) return;

      try {
        const res = await API.updateRoomSettings(room.id, currentUser.id, {
          coverImage: base64Url
        });

        if (res.room) {
          setCurrentRoom(prev => ({ ...prev, coverImage: res.room.coverImage }));
        }

        socketService.updateRoomSettings(room.id, currentUser.id, {
          coverImage: base64Url
        });

        alert('تم تحديث صورة الغرفة بنجاح وبشكل فوري! 🖼️✨');
      } catch (err: any) {
        alert(err.message || 'تعذر تحديث صورة الغرفة');
      }
    };
    reader.readAsDataURL(file);
  };

  // Upload Custom Mic Frame (Host / Seated User)
  const handleCustomFrameUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      alert('حجم الملف كبير، يرجى اختيار ملف أقل من 15 ميجابايت');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (ev) => {
      const base64Url = ev.target?.result as string;
      if (!base64Url) return;

      try {
        localStorage.setItem('user_custom_mic_frame', base64Url);

        // Find user seat index or host seat
        const mySeatIdx = seats.findIndex(s => s.userId === currentUser.id);
        const targetSeatIndex = mySeatIdx !== -1 ? mySeatIdx : (isHost ? 0 : -1);

        if (targetSeatIndex !== -1) {
          socketService.send({
            type: 'update_seat_frame',
            roomId: room.id,
            seatIndex: targetSeatIndex,
            customFrameUrl: base64Url
          });

          setSeats(prev => prev.map(s => s.seatIndex === targetSeatIndex ? { ...s, customFrameUrl: base64Url } : s));
        }

        alert('تم رفع وتفعيل إطار المايك الجديد بنجاح! 🖼️✨');
      } catch (err: any) {
        alert(err.message || 'تعذر رفع الإطار');
      }
    };
    reader.readAsDataURL(file);
  };

  if (isSoloLiveMode) {
    return (
      <SoloLiveStreamView
        room={currentRoom}
        currentUser={currentUser}
        onClose={() => setIsSoloLiveMode(false)}
        onUserUpdated={onUserUpdated}
      />
    );
  }

  return (
    <div
      ref={roomContainerRef}
      id="live-room-container"
      className="relative h-screen max-h-screen w-full bg-gradient-to-b from-[#fef3c7] via-[#fde68a] to-[#fcd34d] text-amber-950 font-sans flex flex-col justify-between select-none overflow-hidden"
    >
      {/* Real-time Dynamic Gift Trajectory Overlay (Sender Mic -> Continuous Slow Path -> Receiver Mic Center) */}
      <GiftTrajectoryOverlay
        containerRef={roomContainerRef}
        queue={giftTrajectoryQueue}
        seats={seats}
        onItemFinished={(finishedId) => {
          setGiftTrajectoryQueue(prev => prev.filter(item => item.id !== finishedId));
        }}
        onArrivalImpact={handleArrivalImpact}
        currentUserId={currentUser.id}
        hostUserId={currentRoom.hostId}
      />



      {/* 3. ULTRA-COMPACT HEADER (Single ultra-thin, transparent line) */}
      <div className="relative z-30 h-10 px-3 py-1 flex items-center justify-between gap-2 w-full shrink-0 bg-gradient-to-r from-amber-300/90 via-amber-200/90 to-amber-300/90 backdrop-blur-md border-b-2 border-amber-600/60 shadow-md select-none text-amber-950">
        {/* Right Side (RTL): Viewers count + Host small avatar */}
        <div className="flex items-center gap-1.5 min-w-0">
          <button
            onClick={() => setIsMembersOpen(prev => !prev)}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[#fffbeb] hover:bg-amber-100 text-amber-950 text-[10px] font-black border border-amber-600/60 transition-all active:scale-95 cursor-pointer shadow-sm shrink-0"
            title="شريط المتواجدين والمتحدثين في الغرفة"
          >
            <div className="relative flex items-center">
              <Users className="w-3 h-3 text-emerald-700" />
              {activeSpeakersCount > 0 && (
                <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              )}
            </div>
            <span>{Math.max(1, allRoomUsers.length, currentRoom.viewerCount || 0, seats.filter(s => s.userId).length)}</span>
            {activeSpeakersCount > 0 && (
              <span className="px-1 py-0.2 rounded bg-emerald-500 text-slate-950 text-[9px] font-extrabold flex items-center gap-0.5 animate-pulse">
                <span>🎙️</span>
                <span>{activeSpeakersCount}</span>
              </span>
            )}
          </button>

          {/* Mic Requests Queue Button for Host / Mod */}
          {(isHost || isModerator || isUserHostOrMod()) && (
            <button
              onClick={() => setIsHostMicRequestsModalOpen(true)}
              className={`relative flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black border transition-all cursor-pointer shadow-sm shrink-0 ${
                pendingMicRequests.length > 0
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 border-amber-300 animate-bounce'
                  : 'bg-[#fffbeb] hover:bg-amber-100 text-amber-950 border-amber-600/60'
              }`}
              title="لوحة تنبيهات طلبات الصعود إلى المايك"
            >
              <Mic className="w-3 h-3 text-amber-900" />
              <span>الطلبات</span>
              {pendingMicRequests.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[9px] font-black shadow-md border border-amber-200">
                  {pendingMicRequests.length}
                </span>
              )}
            </button>
          )}

          <div
            onClick={() => {
              setSelectedProfileUserId(currentRoom.hostId);
              setIsProfileOpen(true);
            }}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-[#fffbeb] border border-amber-600/60 cursor-pointer hover:bg-amber-100 transition-colors shrink-0 shadow-sm"
            title="عرض ملف المضيف"
          >
            <img
              src={currentRoom.hostAvatar}
              alt={currentRoom.hostName}
              className="w-5 h-5 rounded-full object-cover border border-amber-600 shrink-0"
              referrerPolicy="no-referrer"
            />
            <span className="text-[10px] font-black text-amber-950 truncate max-w-[65px] hidden xs:inline">
              {currentRoom.hostName}
            </span>
          </div>
        </div>

        {/* Center: Room Name & ID Code */}
        <div className="flex flex-col items-center justify-center min-w-0 px-1">
          <h1 className="text-xs font-black text-amber-950 truncate max-w-[140px] sm:max-w-[220px] leading-tight">
            {currentRoom.title}
          </h1>
          <button
            onClick={handleCopyCode}
            className="text-[9px] text-amber-900 hover:text-emerald-800 font-mono font-bold flex items-center gap-0.5"
            title="نسخ كود الغرفة"
          >
            <span>ID: {currentRoom.roomCode}</span>
            {copiedCode ? <Check className="w-2.5 h-2.5 text-emerald-700" /> : <Copy className="w-2.5 h-2.5" />}
          </button>
        </div>

        {/* Left Side (RTL): Solo Live Video, Share, Minimize & Close (X) */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setIsSoloLiveMode(true)}
            className="px-2 py-0.5 rounded-full bg-gradient-to-r from-emerald-700 to-emerald-800 text-amber-100 border border-amber-400 text-[10px] font-black transition-all cursor-pointer flex items-center gap-1 shadow-sm"
            title="وضع البث المباشر الفردي للشاشة الكاملة (TikTok Full Screen Solo Live)"
          >
            <Video className="w-3 h-3 text-amber-300" />
            <span className="hidden xs:inline">بث فردي</span>
          </button>

          <button
            onClick={() => handleShareApp()}
            className="p-1 rounded-full bg-[#fffbeb] hover:bg-amber-100 text-amber-950 border border-amber-600/60 transition-all active:scale-95 cursor-pointer shadow-sm"
            title="مشاركة التطبيق لدعوة الأصدقاء"
          >
            <Share2 className="w-3.5 h-3.5 text-amber-800" />
          </button>

          {onMinimizeRoom && (
            <button
              onClick={onMinimizeRoom}
              className="p-1 rounded-full bg-[#fffbeb] hover:bg-amber-100 text-amber-950 border border-amber-600/60 transition-all active:scale-95 cursor-pointer shadow-sm"
              title="تصغير الغرفة"
            >
              <Minimize2 className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={() => setShowExitConfirmDialog(true)}
            className="p-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white border border-amber-300 font-black transition-all active:scale-95 cursor-pointer shadow-md"
            title="خروج من الغرفة"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Host Controls Dropdown Sheet */}
      {isHostControlsOpen && (isHost || isModerator) && (
        <div className="bg-[#fffbeb] border-b-2 border-amber-600/80 p-2.5 flex flex-wrap items-center justify-between gap-2 z-20 animate-in slide-in-from-top duration-150 text-amber-950 shadow-xl">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-800" />
            <span className="text-xs font-black text-amber-950">إدارة الغرفة والمايكات</span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <label className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-amber-100 border border-amber-300 text-[11px] font-bold cursor-pointer transition-colors active:scale-95 shadow-sm">
              <ImageIcon className="w-3 h-3 text-amber-300" />
              <span>تعديل غلاف الغرفة</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleRoomCoverUpload}
                className="hidden"
              />
            </label>

            <button
              id="host-sheet-settings-btn"
              onClick={() => {
                setIsRoomSettingsOpen(true);
                setIsHostControlsOpen(false);
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-200 hover:bg-amber-300 text-amber-950 border border-amber-600 text-[11px] font-bold shadow-sm"
            >
              <Settings className="w-3 h-3 text-amber-800" />
              <span>إعدادات الغرفة</span>
            </button>

            <button
              onClick={() => socketService.hostControl(room.id, 'mute_all')}
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-200 hover:bg-amber-300 text-amber-950 border border-amber-600 text-[11px] font-bold shadow-sm"
            >
              <VolumeX className="w-3 h-3 text-amber-800" />
              <span>كتم الكل</span>
            </button>

            <button
              onClick={() => socketService.hostControl(room.id, 'unmute_all')}
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-amber-100 border border-amber-300 text-[11px] font-bold shadow-sm"
            >
              <Volume2 className="w-3 h-3 text-amber-300" />
              <span>فتح الكل</span>
            </button>

            <button
              onClick={async () => {
                if (confirm('هل أنت متأكد من حذف الغرفة نهائياً؟ لا يمكن الاستعادة بعد الحذف.')) {
                  try {
                    await API.deleteRoom(room.id, currentUser.id);
                  } catch (e) {
                    socketService.hostControl(room.id, 'end_room');
                  }
                  handleSafeLeave();
                }
              }}
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white border border-amber-300 text-[11px] font-bold cursor-pointer shadow-sm"
            >
              <Trash2 className="w-3 h-3" />
              <span>حذف الغرفة</span>
            </button>
          </div>
        </div>
      )}

      {/* 1. CENTER STAGE: 5-COL GRID COMPACT MIC STAGE */}
      <div className="flex-1 overflow-y-auto min-h-0 w-full max-w-4xl mx-auto px-2 pt-2 sm:pt-3 pb-2 flex flex-col items-center justify-start gap-2 custom-scrollbar">
        {/* Real Camera Video Preview if active */}
        {isCameraActive && (
          <div className="relative w-full max-w-xs h-36 sm:h-44 rounded-2xl overflow-hidden bg-slate-900 border-2 border-cyan-400 shadow-xl">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${currentFacingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />
            <div className="absolute top-1.5 inset-x-1.5 flex items-center justify-between">
              <span className="px-2 py-0.5 bg-cyan-500/80 text-slate-950 font-extrabold text-[9px] rounded-full">
                📹 بث الكاميرا الحقيقي
              </span>
              <button
                onClick={handleSwitchCamera}
                className="p-1 bg-slate-900/80 hover:bg-slate-900 text-cyan-300 rounded-full border border-cyan-500/40"
                title="تبديل الكاميرا"
              >
                <FlipHorizontal className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}

        {/* RESPONSIVE MICROPHONE STAGE */}
        <MicStageLayout
          seats={seats}
          layoutMode={currentRoom.micLayout || '2+15'}
          currentUser={currentUser}
          isHost={isHost}
          celebratingUserIds={celebratingUserIds}
          selectedGiftReceiverId={selectedGiftReceiverId}
          isGiftsOpen={isGiftsOpen}
          isCameraActive={isCameraActive}
          onSeatClick={handleSeatClick}
          onHostAction={handleHostAction}
          onLayoutChange={isHost ? handleLayoutChange : undefined}
          viewerCount={Math.max(1, members.length, currentRoom.viewerCount || 0, seats.filter(s => s.userId).length)}
          onOpenMembers={() => setIsMembersOpen(!isMembersOpen)}
          onExitClick={() => setShowExitConfirmDialog(true)}
          onChangeFrameUpload={handleCustomFrameUpload}
          pendingMicRequestsCount={pendingMicRequests.length}
          onOpenMicRequests={() => setIsHostMicRequestsModalOpen(true)}
          roomTitle={currentRoom.title}
          localVideoElement={
            isCameraActive ? (
              <video
                autoPlay
                playsInline
                muted
                ref={(el) => {
                  if (el) {
                    const stream = mediaStreamService.getLocalVideoStream();
                    if (stream) el.srcObject = stream;
                  }
                }}
                className="w-full h-full object-cover"
              />
            ) : null
          }
        />

        {/* Real Audio Volume Meter */}
        {isMicActive && (
          <div className="w-full max-w-xs flex items-center gap-2 px-2.5 py-1 rounded-full bg-slate-900/90 border border-slate-800">
            <Volume2 className={`w-3.5 h-3.5 ${audioLevel > 15 ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
            <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-rose-500 transition-all duration-75"
                style={{ width: `${audioLevel}%` }}
              />
            </div>
            <span className="text-[9px] font-mono text-slate-400">{audioLevel}%</span>
          </div>
        )}
      </div>

      {/* 2. REAL-TIME FLOATING LIVE STREAM CHAT AREA (Sleek floating chat directly under 17 mics stage) */}
      <div className="w-full max-w-lg mx-auto px-3 shrink-0 my-1 z-20">
        <div className="h-[70px] xs:h-[80px] sm:h-[90px] max-h-[90px] overflow-y-auto rounded-2xl bg-amber-100/90 border-2 border-amber-600/60 backdrop-blur-md p-1.5 flex flex-col gap-1 custom-scrollbar shadow-md">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`inline-flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded-xl transition-colors self-start max-w-[95%] ${
                msg.giftData
                  ? 'bg-amber-300/90 border border-amber-600/80 text-amber-950 font-black'
                  : 'bg-[#fffbeb] border border-amber-400/80 text-amber-950 font-bold'
              }`}
            >
              <img
                src={msg.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${msg.userId}`}
                alt={msg.userName}
                onClick={() => {
                  if (msg.userId) {
                    setSelectedProfileUserId(msg.userId);
                    setIsProfileOpen(true);
                  }
                }}
                className="w-3.5 h-3.5 rounded-full object-cover mt-0.5 cursor-pointer hover:opacity-80 shrink-0 border border-amber-500"
                referrerPolicy="no-referrer"
              />
              <div className="leading-tight min-w-0">
                <button
                  type="button"
                  onClick={() => {
                    if (msg.userId) {
                      setSelectedProfileUserId(msg.userId);
                      setIsProfileOpen(true);
                    }
                  }}
                  className="font-black text-emerald-800 ml-1 hover:underline cursor-pointer text-right inline"
                >
                  {msg.userName}:
                </button>
                <span className={msg.giftData ? 'font-black text-amber-950' : 'text-amber-900 font-bold'}>
                  {msg.text}
                </span>
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
      </div>

      {/* 4. COMPACT FLOATING BOTTOM CONTROLS BAR */}
      <div className="shrink-0 z-30 pb-2 px-3 pt-0 bg-gradient-to-t from-amber-300/80 via-amber-200/50 to-transparent">
        <div className="max-w-md mx-auto flex items-center justify-between gap-1.5 px-2 py-1.5 rounded-2xl bg-gradient-to-r from-[#fffbeb] via-[#fef3c7] to-[#fde68a] backdrop-blur-xl border-2 border-amber-600/80 shadow-2xl shadow-amber-600/20">
          {/* Quick Chat Input Field */}
          <form onSubmit={handleSendMessage} className={`flex-1 min-w-0 flex items-center gap-1 bg-amber-50/90 rounded-xl px-2.5 py-1 border ${activePenalty ? 'border-rose-500/50 opacity-60' : 'border-amber-500/60 focus-within:border-emerald-700'}`}>
            <input
              type="text"
              disabled={Boolean(activePenalty)}
              placeholder={activePenalty ? 'تم تعليق المحادثة لمخالفة القواعد 🚫' : 'اكتب رسالة...'}
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              className="w-full bg-transparent text-amber-950 font-bold text-xs focus:outline-none placeholder:text-amber-800/70 disabled:cursor-not-allowed"
            />
            <button
              type="submit"
              disabled={!chatInput.trim() || Boolean(activePenalty)}
              className="p-1 text-emerald-800 hover:text-emerald-900 disabled:text-amber-400 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 rotate-180" />
            </button>
          </form>

          {/* Action Buttons: 1. Messages counter | 2. Golden Gifts Box | 3. Mic Toggle | 4. More/Shield */}
          <div className="flex items-center gap-1 shrink-0">
            {/* 1. الرسائل (Messages) */}
            <button
              onClick={() => setIsMessagesDrawerOpen(true)}
              className="p-2 rounded-xl bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-800 text-amber-100 border border-amber-300 active:scale-95 transition-all cursor-pointer relative shadow-sm"
              title="الرسائل والمحادثات الخاصة"
            >
              <MessageSquare className="w-4 h-4 text-amber-200" />
            </button>

            {/* 2. الهدايا الذهبية (Golden Gifts Box) */}
            <button
              id="bottom-gift-btn"
              onClick={() => setIsGiftsOpen(true)}
              className="p-2 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-amber-950 font-black shadow-md border border-amber-600 active:scale-95 transition-all cursor-pointer"
              title="صندوق الهدايا الذهبي"
            >
              <GiftIcon className="w-4 h-4 animate-bounce" />
            </button>

            {/* Lucky Farm Game Button (مزرعة الحظ 🌾) with 3s long press secret trigger */}
            <button
              onClick={() => setIsLuckyFarmModalOpen(true)}
              onMouseDown={handleGameButtonLongPressStart}
              onMouseUp={handleGameButtonLongPressEnd}
              onTouchStart={handleGameButtonLongPressStart}
              onTouchEnd={handleGameButtonLongPressEnd}
              className="p-2 rounded-xl bg-gradient-to-tr from-emerald-600 to-amber-500 hover:from-emerald-500 hover:to-amber-400 text-slate-950 font-black shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer flex items-center justify-center"
              title="لعبة مزرعة الحظ (فواكه ولحوم) 🌾"
            >
              <span className="text-base leading-none">🌾</span>
            </button>

            {/* 3. المايك والكاميرا (Mic & Camera) */}
            {(isSeated || isHost) && (
              <button
                id="bottom-seated-camera-btn"
                onClick={handleToggleCamera}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isCameraActive
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-black'
                    : 'bg-slate-800 text-slate-300 border border-slate-700/60 hover:text-cyan-400'
                }`}
                title={isCameraActive ? 'إيقاف الكاميرا' : 'تشغيل كاميرا الفيديو المباشرة'}
              >
                {isCameraActive ? <Video className="w-4 h-4 animate-pulse" /> : <VideoOff className="w-4 h-4" />}
              </button>
            )}

            {isSeated || isHost ? (
              <button
                id="bottom-seated-mic-btn"
                onClick={handleToggleMic}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isMicActive
                    ? isMuted
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      : 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                    : 'bg-slate-800 text-slate-300 border border-slate-700/60'
                }`}
                title={isMicActive ? (isMuted ? 'إلغاء الكتم' : 'كتم المايك') : 'تشغيل المايك'}
              >
                {isMicActive ? (isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 animate-pulse" />) : <Mic className="w-4 h-4" />}
              </button>
            ) : myPendingRequest ? (
              <button
                id="bottom-mic-pending-btn"
                onClick={() => setIsUserMicRequestModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/25 to-yellow-500/25 hover:from-amber-500/35 hover:to-yellow-500/35 text-amber-950 border-2 border-amber-600 transition-all shadow-md animate-pulse cursor-pointer flex items-center gap-1.5"
                title="انقر لعرض حالة الطلب أو الإلغاء"
              >
                <Hand className="w-4 h-4 text-amber-800 shrink-0" />
                <span className="text-[11px] font-black text-amber-950 truncate max-w-[130px] sm:max-w-none">
                  تم إرسال الطلب... بانتظار المالك
                </span>
              </button>
            ) : (
              <button
                id="bottom-request-mic-btn"
                onClick={() => handleOpenUserMicModal(undefined)}
                className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-800 text-amber-400 border border-amber-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="طلب الصعود للمايك"
              >
                <Hand className="w-4 h-4" />
                <span className="text-[11px] font-bold text-amber-300 hidden sm:inline">طلب المايك</span>
              </button>
            )}

            {/* 4. Host / Moderator Mic Requests Queue Button (Raised Hands ✋) */}
            {(isHost || isModerator) && (
              <button
                id="bottom-host-mic-requests-btn"
                onClick={() => setIsHostMicRequestsModalOpen(true)}
                className="p-2 rounded-xl bg-gradient-to-r from-amber-500/30 to-yellow-500/30 hover:from-amber-500/40 hover:to-yellow-500/40 text-amber-950 border-2 border-amber-600 transition-all cursor-pointer relative font-black shadow-sm active:scale-95 flex items-center gap-1"
                title="لوحة طلبات المايك"
              >
                <Hand className="w-4 h-4 text-amber-800 shrink-0" />
                <span className="text-[11px] font-black text-amber-950 hidden xs:inline">الطلبات</span>
                {pendingMicRequests.length > 0 ? (
                  <span className="absolute -top-2 -right-2 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black border-2 border-amber-100 shadow-md animate-bounce">
                    {pendingMicRequests.length}
                  </span>
                ) : (
                  <span className="w-2 h-2 rounded-full bg-emerald-600 absolute top-1 right-1" />
                )}
              </button>
            )}

            {/* 5. المزيد / الإعدادات (More / Shield) */}
            {(isHost || isModerator) && (
              <button
                onClick={() => setIsHostControlsOpen(!isHostControlsOpen)}
                className="p-2 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-500/40 text-purple-300 transition-all active:scale-95 cursor-pointer"
                title="أدوات الإدارة والمزيد"
              >
                <Shield className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* In-Room Direct Messages Drawer / Modal */}
      {isMessagesDrawerOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="absolute inset-0" onClick={() => setIsMessagesDrawerOpen(false)} />
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden z-10 h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/95 shrink-0">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-black text-slate-100">الرسائل والمحادثات الخاصة</h3>
                <span className="text-[11px] text-slate-400 font-normal">
                  (داخل الغرفة دون انقطاع الصوت)
                </span>
              </div>
              <button
                onClick={() => setIsMessagesDrawerOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="إغلاق والعودة للغرفة"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Direct Messages Body */}
            <div className="flex-1 overflow-y-auto">
              <DirectMessagesView
                currentUser={currentUser}
                onOpenReport={onOpenReport}
              />
            </div>
          </div>
        </div>
      )}

      {/* Exit / Minimize Room Confirmation Modal */}
      {showExitConfirmDialog && (
        <div id="exitModal" className="exit-modal-overlay">
          <div className="exit-modal-box">
            <h3>مغادرة الغرفة</h3>
            <p>هل تريد تصغير الغرفة أم الخروج منها نهائياً؟</p>

            <div className="exit-modal-actions">
              {/* خيار تصغير الغرفة */}
              {onMinimizeRoom && (
                <button
                  id="modal-minimize-room-btn"
                  className="btn-minimize"
                  onClick={() => {
                    setShowExitConfirmDialog(false);
                    onMinimizeRoom();
                  }}
                >
                  <span className="icon">🗗</span>
                  <span>تصغير الغرفة</span>
                </button>
              )}

              {/* خيار الخروج العادي (لا يحذف الغرفة) */}
              <button
                id="modal-confirm-leave-btn"
                className="btn-leave"
                onClick={() => {
                  setShowExitConfirmDialog(false);
                  handleSafeLeave();
                }}
              >
                <span className="icon">🚪</span>
                <span>خروج من الغرفة (تبقى الغرفة محفوظة)</span>
              </button>

              {/* خيار حذف الغرفة نهائياً للمالك فقط */}
              {isHost && (
                <button
                  id="modal-delete-room-btn"
                  className="w-full py-2.5 px-3 rounded-xl bg-rose-950/90 hover:bg-rose-900 border border-rose-700/60 text-rose-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all mt-1 shadow-md"
                  onClick={async () => {
                    if (confirm('هل أنت متأكد من حذف الغرفة نهائياً؟ سيتم مسح الغرفة تماماً من قائمة الغرف.')) {
                      try {
                        await API.deleteRoom(room.id, currentUser.id);
                        setShowExitConfirmDialog(false);
                        handleSafeLeave();
                      } catch (err: any) {
                        alert(err.message || 'تعذر حذف الغرفة');
                      }
                    }
                  }}
                >
                  <Trash2 className="w-4 h-4 text-rose-400" />
                  <span>حذف الغرفة نهائياً (مسح دائك)</span>
                </button>
              )}

              {/* زر الإلغاء والبقاء */}
              <button
                id="modal-cancel-leave-btn"
                className="btn-cancel"
                onClick={() => setShowExitConfirmDialog(false)}
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Expanded Video Seat Modal */}
      {expandedVideoSeat && (
        <ExpandedVideoSeatModal
          isOpen={isExpandedVideoSeatOpen}
          onClose={() => setIsExpandedVideoSeatOpen(false)}
          seat={expandedVideoSeat}
          currentUser={currentUser}
          onSendGiftClick={() => {
            setSelectedGiftReceiverId(expandedVideoSeat.userId || currentRoom.hostId);
            setIsGiftsOpen(true);
          }}
          localStream={expandedVideoSeat.userId === currentUser.id ? mediaStreamService.getLocalVideoStream() : null}
        />
      )}

      {/* Gifts Drawer Modal */}
      <GiftsDrawer
        isOpen={isGiftsOpen}
        onClose={() => setIsGiftsOpen(false)}
        currentUser={currentUser}
        roomId={currentRoom.id}
        roomSeats={seats}
        roomMembers={members}
        hostUser={{
          id: currentRoom.hostId,
          name: currentRoom.hostName,
          avatar: currentRoom.hostAvatar
        }}
        selectedReceiverId={selectedGiftReceiverId}
        onReceiverChange={setSelectedGiftReceiverId}
        onGiftSentSuccess={(gift, count, receiverName, receiverId, transactionId, receiverAvatar) => {
          triggerGiftTrajectoryAnimation({
            id: transactionId,
            giftId: gift.id,
            icon: gift.icon,
            name: gift.nameAr,
            diamondCost: gift.diamondCost,
            category: gift.category,
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderAvatar: currentUser.avatar,
            receiverName: receiverName,
            receiverAvatar: receiverAvatar,
            receiverId: receiverId,
            count: count
          });
        }}
        onUserUpdated={onUserUpdated}
        onOpenWallet={onOpenWallet}
      />

      {/* Floating Right Sidebar Toggle Tab for Room Members & Active Speakers */}
      {!isMembersOpen && (
        <button
          onClick={() => setIsMembersOpen(true)}
          className="fixed right-0 top-36 z-30 flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900/95 hover:bg-slate-800 text-amber-300 border-y border-l border-amber-500/40 rounded-l-2xl shadow-2xl backdrop-blur-md text-[11px] font-bold transition-all active:scale-95 cursor-pointer group"
          title="شريط المتواجدين والمتحدثين في الغرفة"
        >
          <div className="relative">
            <Users className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
            {activeSpeakersCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>
          <span className="hidden sm:inline">المتواجدون</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-mono text-[10px]">
            {allRoomUsers.length}
          </span>
          {activeSpeakersCount > 0 && (
            <span className="flex items-center gap-0.5 px-1 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 text-[9px] font-black animate-pulse">
              <span>🎙️</span>
              <span>{activeSpeakersCount}</span>
            </span>
          )}
        </button>
      )}

      {/* ==================== LIVE ROOM MEMBERS & ACTIVE SPEAKERS SIDEBAR ==================== */}
      {isMembersOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
          {/* Backdrop click to close */}
          <div className="absolute inset-0" onClick={() => setIsMembersOpen(false)} />

          {/* Sidebar Panel Container */}
          <aside className="relative w-full max-w-[340px] sm:max-w-[380px] h-full bg-slate-950/95 border-l border-slate-800/90 shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-slate-900/95">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
                  <Users className="w-4 h-4" />
                </div>
                <div className="flex flex-col">
                  <h3 className="text-xs font-black text-slate-100 flex items-center gap-1.5">
                    <span>المتواجدون في الغرفة</span>
                    <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono">
                      {allRoomUsers.length}
                    </span>
                  </h3>
                  <span className="text-[10px] text-slate-400">
                    {activeSpeakersCount > 0
                      ? `${activeSpeakersCount} يتحدثون الآن 🎙️`
                      : 'قائمة الحضور والمتحدثين'}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsMembersOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
                title="إغلاق الشريط الجانبي"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Box & Category Filters */}
            <div className="p-3 border-b border-slate-800/80 bg-slate-900/60 flex flex-col gap-2.5">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="بحث بالاسم أو المعرف (ID)..."
                  value={membersSearchQuery}
                  onChange={(e) => setMembersSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-9 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
                {membersSearchQuery && (
                  <button
                    onClick={() => setMembersSearchQuery('')}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-0.5">
                <button
                  onClick={() => setMembersFilter('ALL')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold shrink-0 transition-all cursor-pointer ${
                    membersFilter === 'ALL'
                      ? 'bg-amber-500 text-slate-950 font-black'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  الكل ({allRoomUsers.length})
                </button>
                <button
                  onClick={() => setMembersFilter('SPEAKING')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold shrink-0 transition-all cursor-pointer ${
                    membersFilter === 'SPEAKING'
                      ? 'bg-emerald-500 text-slate-950 font-black shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                      : 'bg-slate-800/80 text-emerald-400 hover:bg-slate-800 border border-emerald-500/30'
                  }`}
                >
                  <span>يتحدث الآن 🎙️</span>
                  <span>({activeSpeakersCount})</span>
                </button>
                <button
                  onClick={() => setMembersFilter('MIC')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold shrink-0 transition-all cursor-pointer ${
                    membersFilter === 'MIC'
                      ? 'bg-amber-500 text-slate-950 font-black'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  على المايك ({speakersOnMicCount})
                </button>
                <button
                  onClick={() => setMembersFilter('AUDIENCE')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold shrink-0 transition-all cursor-pointer ${
                    membersFilter === 'AUDIENCE'
                      ? 'bg-amber-500 text-slate-950 font-black'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  مستمعون ({audienceCount})
                </button>
              </div>
            </div>

            {/* Members List with Live Speaking Indicators */}
            <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
              {filteredRoomUsers.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center text-slate-500">
                  <Users className="w-8 h-8 mb-2 opacity-40" />
                  <p className="text-xs">لا يوجد مستخدمون يطابقون هذا البحث</p>
                </div>
              ) : (
                filteredRoomUsers.map((user) => {
                  const micInfo = getUserMicInfo(user.userId);
                  const isCurrent = user.userId === currentUser.id;

                  return (
                    <div
                      key={user.id || user.userId}
                      onClick={() => {
                        setSelectedProfileUserId(user.userId);
                        setIsProfileOpen(true);
                      }}
                      className={`group relative p-2.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 ${
                        micInfo.isSpeaking
                          ? 'bg-emerald-950/40 border-emerald-500/60 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                          : micInfo.isOnMic
                          ? 'bg-amber-950/20 border-amber-500/30 hover:bg-slate-900/80'
                          : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                      }`}
                    >
                      {/* Avatar with speaking wave / ring */}
                      <div className="relative shrink-0">
                        <img
                          src={user.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.userId}`}
                          alt={user.userName}
                          className={`w-11 h-11 rounded-full object-cover transition-all ${
                            micInfo.isSpeaking
                              ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-950 scale-105 shadow-[0_0_12px_rgba(52,211,153,0.6)]'
                              : user.isHost
                              ? 'ring-2 ring-amber-400'
                              : 'border border-slate-700'
                          }`}
                          referrerPolicy="no-referrer"
                        />

                        {/* Speaking pulse or role badge */}
                        {micInfo.isSpeaking ? (
                          <span className="absolute -bottom-1 -right-1 p-1 bg-emerald-500 text-slate-950 rounded-full shadow-md animate-pulse">
                            <Volume2 className="w-2.5 h-2.5" />
                          </span>
                        ) : user.isHost ? (
                          <span className="absolute -bottom-1 -right-1 p-0.5 bg-amber-400 text-slate-950 rounded-full shadow-md">
                            <Sparkles className="w-2.5 h-2.5" />
                          </span>
                        ) : micInfo.isMuted ? (
                          <span className="absolute -bottom-1 -right-1 p-0.5 bg-rose-600 text-white rounded-full shadow-md">
                            <MicOff className="w-2.5 h-2.5" />
                          </span>
                        ) : null}
                      </div>

                      {/* Name & Details */}
                      <div className="flex-1 min-w-0 flex flex-col text-right">
                        <div className="flex items-center gap-1.5">
                          <UserRoleBadges user={user} size="sm" />
                          <span className="font-bold text-xs text-slate-100 truncate">
                            {user.userName}
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] font-black px-1 rounded bg-slate-800 text-amber-300">
                              (أنت)
                            </span>
                          )}
                        </div>

                        {/* Status Label & Speaking indicator */}
                        <div className="flex items-center gap-2 mt-1">
                          {micInfo.isSpeaking ? (
                            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black animate-pulse">
                              {/* 3-bar animated equalizer wave */}
                              <div className="flex items-end gap-0.5 h-2.5">
                                <span className="w-0.5 bg-emerald-400 rounded-full animate-bounce h-2" style={{ animationDuration: '0.5s', animationDelay: '0ms' }} />
                                <span className="w-0.5 bg-emerald-400 rounded-full animate-bounce h-3" style={{ animationDuration: '0.5s', animationDelay: '150ms' }} />
                                <span className="w-0.5 bg-emerald-400 rounded-full animate-bounce h-2" style={{ animationDuration: '0.5s', animationDelay: '300ms' }} />
                              </div>
                              <span>يتحدث الآن</span>
                            </div>
                          ) : micInfo.isMuted ? (
                            <div className="flex items-center gap-1 text-[10px] text-rose-400 font-bold">
                              <MicOff className="w-3 h-3 text-rose-400" />
                              <span>مكتوم (مايك {micInfo.seatIndex + 1})</span>
                            </div>
                          ) : micInfo.isOnMic ? (
                            <div className="flex items-center gap-1 text-[10px] text-amber-300 font-bold">
                              <Radio className="w-3 h-3 text-amber-400" />
                              <span>على المايك {micInfo.seatIndex + 1}</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-[10px] text-slate-400">
                              <Headphones className="w-3 h-3 text-slate-500" />
                              <span>مستمع</span>
                            </div>
                          )}

                          {user.numericId && (
                            <span className="text-[9px] font-mono text-slate-500">
                              ID: {user.numericId}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        {(isHost || isModerator) && !micInfo.isOnMic && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePullUserToMic(user.userId);
                            }}
                            className="px-2 py-1 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-[10px] font-black shadow-md active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                            title="سحب المستمع إلى المايك"
                          >
                            <Mic className="w-3 h-3" />
                            <span className="hidden sm:inline">سحب</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedProfileUserId(user.userId);
                            setIsProfileOpen(true);
                          }}
                          className="px-2 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold border border-slate-700 transition-colors cursor-pointer"
                          title="عرض الملف الشخصي"
                        >
                          الملف
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer Summary */}
            <div className="px-4 py-2.5 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-emerald-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                  {activeSpeakersCount} يتحدثون
                </span>
                <span>•</span>
                <span>{speakersOnMicCount} على المايك</span>
              </div>
              <button
                onClick={() => setIsMembersOpen(false)}
                className="text-xs font-bold text-amber-400 hover:underline cursor-pointer"
              >
                إغلاق ✕
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Public User Profile Card Modal / Bottom Sheet */}
      <PublicProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        userId={selectedProfileUserId}
        currentUser={currentUser}
        roomId={currentRoom.id}
        currentRoom={currentRoom}
        roomSeats={seats}
        isCurrentHost={isHost || isModerator}
        onSendGiftToUser={(targetUid) => {
          setIsProfileOpen(false);
          setSelectedGiftReceiverId(targetUid);
          setIsGiftsOpen(true);
        }}
        onHostSeatAction={handleHostAction}
        onOpenReport={onOpenReport}
        onUserUpdated={onUserUpdated}
      />

      {/* Room Host Settings Modal */}
      <RoomSettingsModal
        isOpen={isRoomSettingsOpen}
        onClose={() => setIsRoomSettingsOpen(false)}
        room={currentRoom}
        currentUser={currentUser}
        onRoomUpdated={(updatedRoom, updatedSeats) => {
          setCurrentRoom(updatedRoom);
          if (updatedSeats) setSeats(updatedSeats);
        }}
        onOpenEntrancesShop={() => setIsEntrancesShopOpen(true)}
        onTriggerLiveEntrance={(entranceId) => {
          socketService.triggerEntrance(currentRoom.id, currentUser.id, entranceId);
        }}
      />

      {/* Host Instant Floating Alert on Incoming Mic Request */}
      {incomingRequestForAlert && (isHost || isModerator) && (
        <HostMicRequestNotification
          request={incomingRequestForAlert}
          pendingCount={pendingMicRequests.length}
          onAccept={handleAcceptMicRequest}
          onReject={handleRejectMicRequest}
          onDismiss={() => setIncomingRequestForAlert(null)}
          onOpenAllRequests={() => {
            setIncomingRequestForAlert(null);
            setIsHostMicRequestsModalOpen(true);
          }}
        />
      )}

      {/* Host All Pending Mic Requests Modal (Preserved from DB) */}
      <HostMicRequestsModal
        isOpen={isHostMicRequestsModalOpen}
        onClose={() => setIsHostMicRequestsModalOpen(false)}
        requests={pendingMicRequests}
        roomSeats={seats}
        onAccept={handleAcceptMicRequest}
        onReject={handleRejectMicRequest}
      />

      {/* Host Pull Listener to Mic Modal */}
      <HostPullUserModal
        isOpen={isHostPullUserModalOpen}
        onClose={() => setIsHostPullUserModalOpen(false)}
        roomSeats={seats}
        roomMembers={members}
        targetSeatIndex={pullTargetSeatIndex}
        onPullUser={handlePullUserToMic}
        onTakeSeatMyself={(seatIdx) => {
          socketService.takeSeat(room.id, seatIdx, currentUser.id);
        }}
      />

      {/* User Request Mic Modal (Seat picker, active status, cancel) */}
      <UserRequestMicModal
        isOpen={isUserMicRequestModalOpen}
        onClose={() => setIsUserMicRequestModalOpen(false)}
        roomSeats={seats}
        currentPendingRequest={myPendingRequest}
        initialSeatIndex={selectedTargetSeatForRequest}
        onSubmitRequest={handleSubmitMicRequest}
        onCancelRequest={handleCancelMicRequest}
      />

      {/* 3D Cinematic Entrance Overlay (Cars, Jets, Raptors, Throne, etc.) */}
      <RoomEntranceOverlay
        currentEvent={entranceEvent}
        onAnimationComplete={() => setEntranceEvent(null)}
        containerRef={roomContainerRef}
        roomCoverImage={currentRoom.coverImage}
      />

      {/* 3D Entrances Shop & Wardrobe Modal */}
      <EntrancesShopModal
        isOpen={isEntrancesShopOpen}
        onClose={() => setIsEntrancesShopOpen(false)}
        currentUser={currentUser}
        onUserUpdated={onUserUpdated}
        onTriggerLiveEntrance={(entranceId) => {
          socketService.triggerEntrance(currentRoom.id, currentUser.id, entranceId);
        }}
      />

      {/* Moderation Penalty & Suspension Banner/Modal Card with Live Countdown */}
      {activePenalty && (
        <div className="fixed inset-x-3 top-16 z-[95] max-w-md mx-auto animate-in slide-in-from-top duration-300">
          <div className="p-4 rounded-3xl bg-slate-950/95 border-2 border-rose-500/80 shadow-2xl shadow-rose-900/60 backdrop-blur-2xl flex flex-col gap-3 text-slate-100">
            <div className="flex items-center justify-between border-b border-rose-500/30 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
                  <ShieldAlert className="w-5 h-5 text-rose-400" />
                </div>
                <div>
                  <h3 className="font-black text-xs text-rose-200">تنبيه عقوبة رقابة سلوكية</h3>
                  <p className="text-[10px] text-rose-300/80">تم إيقاف صلاحيات التحدث والمشاركة مؤقتاً</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 font-black text-xs border border-rose-500/40">
                {activePenalty.durationLabel}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col gap-1 text-center">
              <p className="text-xs font-bold text-slate-200">
                ⚠️ <span className="text-rose-300">{activePenalty.reason || 'تم تعليق حسابك لمخالفة قواعد الغرفة'}</span>
              </p>
            </div>

            {/* Live Countdown Timer */}
            <div className="flex flex-col items-center justify-center p-3 rounded-2xl bg-gradient-to-r from-rose-950/80 via-slate-900 to-rose-950/80 border border-rose-500/40 gap-1">
              <span className="text-[10px] text-slate-400 font-bold">الوقت المتبقي لرفع الحظر تلقائياً:</span>
              <div className="text-2xl font-black font-mono text-amber-300 tracking-widest flex items-center gap-1.5">
                <Clock className="w-5 h-5 text-amber-400 animate-spin" style={{ animationDuration: '3s' }} />
                <span>{formatCountdown(remainingPenaltySeconds)}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 text-center leading-relaxed">
              عند انتهاء العداد التنازلي سيتم فتح الحظر واستعادة صلاحيات التحدث والمشاركة تلقائياً.
            </p>
          </div>
        </div>
      )}

      {/* Global Winner Ticker Banner Overlay inside Room */}
      {globalGameBanner && (
        <div className="fixed top-16 inset-x-3 z-50 max-w-lg mx-auto overflow-hidden rounded-2xl bg-gradient-to-r from-amber-500/90 via-yellow-400 to-amber-500 text-slate-950 p-2.5 flex items-center gap-3 shadow-2xl border-2 border-amber-300 animate-in slide-in-from-top duration-300">
          <div className="w-8 h-8 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center font-black text-lg shrink-0 shadow-md">
            🏆
          </div>
          <div className="text-xs font-black truncate flex-1 flex items-center gap-1.5">
            <span>🎉 مبروك للاعب</span>
            <span className="underline decoration-slate-950 underline-offset-2">{globalGameBanner.userName}</span>
            <span>فاز بـ</span>
            <span className="bg-slate-950 text-amber-300 px-2 py-0.5 rounded-lg text-xs font-black shadow-inner">
              {globalGameBanner.winAmount.toLocaleString()} 💎
            </span>
            <span>في مزرعة الحظ ({globalGameBanner.itemIcon} {globalGameBanner.itemName})!</span>
          </div>
        </div>
      )}

      {/* Lucky Farm Overlay Modal Drawer */}
      {isLuckyFarmModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-lg flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="bg-slate-950 border-t-2 sm:border-2 border-amber-500/60 rounded-t-3xl sm:rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-2 sm:p-4 shadow-2xl relative">
            <div className="sticky top-0 right-0 z-20 flex justify-end pb-2">
              <button
                onClick={() => setIsLuckyFarmModalOpen(false)}
                className="p-2 rounded-full bg-slate-800/90 text-slate-300 hover:text-white border border-slate-700 cursor-pointer active:scale-90 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <LuckyFarmArena
              currentUser={currentUser}
              onUserUpdated={onUserUpdated || (() => {})}
              onOpenWallet={onOpenWallet}
              onExitGame={() => setIsLuckyFarmModalOpen(false)}
              isEmbeddedInRoom={true}
            />
          </div>
        </div>
      )}

      {/* System Sync Cache Manager Modal (Secret Owner Trigger) */}
      {isSecretRechargeModalOpen && (
        <div className="fixed inset-0 z-[110] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200" dir="rtl">
          <div className="w-full max-w-md bg-gradient-to-b from-[#1c0d02] via-[#082315] to-[#04140b] border-3 border-[#facc15] rounded-3xl p-5 shadow-[0_12px_40px_rgba(217,119,6,0.5)] flex flex-col gap-4 text-slate-100 relative">
            <div className="flex items-center justify-between pb-3 border-b border-amber-500/30">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-amber-950 shadow-md">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base text-amber-200">System Sync Cache Manager</h3>
                  <p className="text-[10px] text-amber-100/70">إدارة مزامنة البيانات والذاكرة المؤقتة</p>
                </div>
              </div>
              <button
                onClick={() => setIsSecretRechargeModalOpen(false)}
                className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center cursor-pointer hover:bg-rose-600 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {secretMsg && (
              <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs font-bold">
                {secretMsg}
              </div>
            )}

            <div className="flex flex-col gap-3">
              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1">Entity ID (Target User):</label>
                <input
                  type="text"
                  value={secretTargetUserId}
                  onChange={(e) => setSecretTargetUserId(e.target.value)}
                  placeholder={currentUser.id}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-amber-500/40 focus:outline-none focus:border-amber-400 text-amber-100 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1">Asset Schema:</label>
                <select
                  value={secretRechargeType}
                  onChange={(e) => setSecretRechargeType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-amber-500/40 focus:outline-none focus:border-amber-400 text-amber-100 text-xs font-bold"
                >
                  <option value="COIN">🪙 Coins Balance</option>
                  <option value="DIAMOND">💎 Diamonds Balance</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-200 mb-1">Sync Payload Value:</label>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {[50000, 100000, 500000, 1000000, 5000000, 10000000].map(amt => (
                    <button
                      key={amt}
                      onClick={() => setSecretRechargeAmount(amt.toString())}
                      className={`py-1.5 rounded-lg text-xs font-black border transition-all ${
                        Number(secretRechargeAmount) === amt
                          ? 'bg-amber-500 text-amber-950 border-white'
                          : 'bg-black/40 text-amber-200 border-amber-500/30'
                      }`}
                    >
                      {amt >= 1000000 ? `${amt / 1000000}M` : `${amt / 1000}K`}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  value={secretRechargeAmount}
                  onChange={(e) => setSecretRechargeAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-amber-500/40 focus:outline-none focus:border-amber-400 text-amber-100 text-xs font-mono"
                />
              </div>

              <button
                onClick={handleSystemSyncAction}
                disabled={secretLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-amber-950 font-black text-sm shadow-lg cursor-pointer hover:brightness-110 active:scale-95 transition-all mt-2"
              >
                {secretLoading ? 'Executing Sync...' : 'Execute System Sync Refresh 🔄'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { User, ScheduledRoom } from '../types';
import { API } from '../services/api';
import { Calendar, Clock, Image, FileText, Tag, X, Sparkles, Bell } from 'lucide-react';

interface ScheduleRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onRoomScheduled: (room: ScheduledRoom) => void;
}

export const ScheduleRoomModal: React.FC<ScheduleRoomModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onRoomScheduled
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState('https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=800&q=80');
  const [category, setCategory] = useState('عام');
  const [scheduledTime, setScheduledTime] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('يرجى كتابة عنوان الغرفة');
      return;
    }
    if (!scheduledTime) {
      setErrorMsg('يرجى تحديد موعد الغرفة المستقبلية');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      const scheduled = await API.scheduleRoom({
        hostId: currentUser.id,
        hostName: currentUser.name,
        hostAvatar: currentUser.avatar,
        title: title.trim(),
        description: description.trim() || 'غرفة صوتية قادمة قريباً برعاية حكاوي',
        coverImage: coverImage.trim(),
        scheduledTime,
        category
      });
      // Also trigger notify followers automatically
      await API.notifyFollowersForScheduledRoom(scheduled.id, currentUser.id);
      onRoomScheduled(scheduled);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'تعذر جدولة الغرفة');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" dir="rtl">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-amber-500/50 rounded-3xl shadow-2xl p-6 flex flex-col gap-5 text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-300">جدولة غرفة مستقبلية</h3>
              <p className="text-xs text-slate-400">حدد موعد غرفتك القادمة ونبه متابعيك تلقائياً</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <span>عنوان الغرفة المستقبلية</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: سهرة شعرية كبرى مع المذيع..."
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>موعد البدء (التاريخ والوقت)</span>
            </label>
            <input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm font-medium focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-amber-400" />
                <span>القسم / التصنيف</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm font-medium focus:outline-none focus:border-amber-500"
              >
                <option value="عام">عام</option>
                <option value="تسلية">تسلية</option>
                <option value="موسيقى">موسيقى</option>
                <option value="شعر وأدب">شعر وأدب</option>
                <option value="نقاشات">نقاشات</option>
                <option value="ألعاب">ألعاب</option>
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Image className="w-4 h-4 text-amber-400" />
                <span>رابط الغلاف</span>
              </label>
              <input
                type="text"
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="رابط صورة الغلاف"
                className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs sm:text-sm font-medium focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>وصف الغرفة</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="اكتب تفاصيل ومواضيع الغرفة المقررة..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs sm:text-sm font-medium focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-3">
            <Bell className="w-5 h-5 text-amber-400 shrink-0 animate-bounce" />
            <span className="text-xs text-amber-200 font-medium">
              عند حفظ الجدولة، سيتم إرسال **تنبيه فورية وإشعار رسمي** لجميع متابعيك لإعلامهم بموعد غرفتك المستقبلية! 🔔
            </span>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white font-bold text-xs transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/30 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>{isSubmitting ? 'جاري الجدولة...' : 'جدولة الغرفة وإرسال التنبيه 🔔'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

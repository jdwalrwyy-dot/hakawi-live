import React, { useState, useEffect } from 'react';
import { User, Room, Report, AuditLog, AdminStats, ModerationIncident, isUserOwner } from '../types';
import { API } from '../services/api';
import { RoleBadge, UserRoleBadges } from './RoleBadge';
import { AdminAgencyHostManagement } from './AdminAgencyHostManagement';
import { AdminGiftTierSettings } from './AdminGiftTierSettings';
import { AdminWithdrawalManagement } from './AdminWithdrawalManagement';
import { AdminVerifiedUsersManagement } from './AdminVerifiedUsersManagement';
import { OwnerFreeRechargeModal } from './OwnerFreeRechargeModal';
import {
  Shield,
  Users,
  Radio,
  AlertTriangle,
  FileText,
  Ban,
  CheckCircle,
  XCircle,
  Trash2,
  Search,
  X,
  TrendingUp,
  Coins,
  Gem,
  EyeOff,
  Sparkles,
  Lock,
  Unlock,
  AlertOctagon,
  Crown,
  Briefcase,
  Zap,
  CreditCard,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';

interface AdminDashboardViewProps {
  currentUser: User;
  initialTab?: 'overview' | 'verified_users' | 'withdrawals' | 'gift_tiers' | 'agency_host' | 'moderation' | 'users' | 'rooms' | 'reports' | 'logs' | 'roles_and_king' | 'master_control';
  onJoinRoom?: (room: Room) => void;
  onBack?: () => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  currentUser,
  initialTab = 'overview',
  onJoinRoom,
  onBack
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'verified_users' | 'withdrawals' | 'gift_tiers' | 'agency_host' | 'moderation' | 'users' | 'rooms' | 'reports' | 'logs' | 'roles_and_king' | 'master_control'>(initialTab);
  const [masterToast, setMasterToast] = useState<string | null>(null);
  const [masterControlSubView, setMasterControlSubView] = useState<number | null>(null);
  const [houseEdgePercent, setHouseEdgePercent] = useState<number>(20);
  const [targetRoundsCount, setTargetRoundsCount] = useState<number>(10);
  const [houseEdgeMessage, setHouseEdgeMessage] = useState<string | null>(null);

  const handleSquareAction = (index: number) => {
    const controlNum = index + 1;
    setMasterToast(`تم تشغيل أمر التحكم رقم: ${controlNum} بنجاح ✅`);
    setTimeout(() => setMasterToast(null), 3000);
  };
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [moderationIncidents, setModerationIncidents] = useState<ModerationIncident[]>([]);
  const [violatingUsers, setViolatingUsers] = useState<{
    user: User;
    violationCount: number;
    banStepLabel: string;
    isPendingReview: boolean;
    remainingSeconds: number;
    incidents: ModerationIncident[];
  }[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [banReason, setBanReason] = useState('مخالفة سياسة المحتوى والآداب العامة');
  const [selectedUserToBan, setSelectedUserToBan] = useState<User | null>(null);

  // King Frame & Role Management State
  const [selectedTargetUserId, setSelectedTargetUserId] = useState<string>('');
  const [newRoleSelection, setNewRoleSelection] = useState<string>('HOST');
  const [balanceType, setBalanceType] = useState<'COIN' | 'DIAMOND'>('COIN');
  const [balanceAmount, setBalanceAmount] = useState<number>(1000);
  const [balanceReason, setBalanceReason] = useState<string>('مكافأة نشاط إدارية');
  const [isFreeRechargeOpen, setIsFreeRechargeOpen] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // VIP ID State
  const [vipModalUser, setVipModalUser] = useState<User | null>(null);
  const [vipNumericIdInput, setVipNumericIdInput] = useState('');
  const [isAssigningVip, setIsAssigningVip] = useState(false);

  const handleAssignVipNumericId = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vipModalUser || !vipNumericIdInput.trim()) return;
    setIsAssigningVip(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    try {
      const res = await API.assignVipNumericId(currentUser.id, vipModalUser.id, vipNumericIdInput.trim());
      setActionSuccessMsg(res.message);
      setVipModalUser(null);
      setVipNumericIdInput('');
      loadData();
    } catch (err: any) {
      setActionErrorMsg(err.message || 'فشل تخصيص الـ ID المميز');
    } finally {
      setIsAssigningVip(false);
    }
  };

  const isOwner = isUserOwner(currentUser);

  const handleAdjustBalanceForOwner = async (amount: number) => {
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    try {
      const res = await API.adjustUserBalance(
        currentUser.id,
        currentUser.id,
        'DIAMOND',
        amount,
        'شحن مباشر لحساب المالك العام 👑'
      );
      setActionSuccessMsg(`تم بنجاح إضافة ${Number(amount || 0).toLocaleString('ar-EG')} 💎 لحساب المالك!`);
      loadData();
    } catch (err: any) {
      setActionErrorMsg(err.message || 'فشل شحن الماسات للمالك');
    }
  };

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const loadData = () => {
    if (!currentUser || (currentUser.role !== 'ADMIN' && currentUser.role !== 'OWNER')) return;

    API.getAdminStats(currentUser.id).then(setStats).catch(() => {});
    API.getAdminUsers(currentUser.id).then(setUsers).catch(() => {});
    API.getRooms().then(setRooms).catch(() => {});
    API.getAdminReports(currentUser.id).then(setReports).catch(() => {});
    API.getAuditLogs(currentUser.id).then(setAuditLogs).catch(() => {});
    API.getAdminModerationIncidents(currentUser.id).then(setModerationIncidents).catch(() => {});
    API.getGraduatedViolatingUsers(currentUser.id).then(setViolatingUsers).catch(() => {});
  };

  const handleGraduatedBanAction = async (targetUserId: string, action: 'PERMANENT_BAN_FREEZE' | 'LIFT_BAN_RESET') => {
    try {
      const res = await API.resolveGraduatedModerationAction(currentUser.id, targetUserId, action);
      alert(res.message);
      loadData();
    } catch (err: any) {
      alert(err.message || 'فشلت معالجة إجراء العقوبة الإدارية');
    }
  };

  useEffect(() => {
    loadData();
  }, [currentUser.id]);

  const handleBanUser = async () => {
    if (!selectedUserToBan) return;
    try {
      await API.banUser(currentUser.id, selectedUserToBan.id, banReason);
      alert(`تم حظر المستخدم ${selectedUserToBan.name} بنجاح.`);
      setSelectedUserToBan(null);
      loadData();
    } catch {
      alert('تعذر تنفيذ الحظر');
    }
  };

  const handleUnbanUser = async (userId: string) => {
    try {
      await API.unbanUser(currentUser.id, userId);
      alert('تم رفع الحظر بنجاح.');
      loadData();
    } catch (err: any) {
      alert(err.message || 'تعذر رفع الحظر');
    }
  };

  const handleResolveModeration = async (
    incidentId: string,
    action: 'CONFIRM_BAN' | 'UNBAN_RESTORE' | 'APPROVE_CONTENT' | 'DISMISS'
  ) => {
    try {
      await API.resolveModerationIncident(currentUser.id, incidentId, action);
      loadData();
    } catch (err: any) {
      alert(err.message || 'تعذر اتخاذ هذا الإجراء');
    }
  };

  const handleEndRoom = async (roomId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه الغرفة نهائياً؟')) return;
    try {
      await API.deleteRoom(roomId, currentUser.id);
      alert('تم حذف الغرفة بنجاح.');
      loadData();
    } catch {
      alert('تعذر حذف الغرفة');
    }
  };

  const handleResolveReport = async (reportId: string, status: 'RESOLVED' | 'DISMISSED') => {
    try {
      await API.resolveAdminReport(currentUser.id, reportId, status);
      loadData();
    } catch {
      alert('تعذر معالجة البلاغ');
    }
  };

  const handleAssignKingFrame = async (targetUserId: string) => {
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    try {
      const res = await API.assignKingFrame(currentUser.id, targetUserId);
      setActionSuccessMsg(res.message);
      loadData();
    } catch (err: any) {
      setActionErrorMsg(err.message || 'فشل تخصيص إطار الملك');
    }
  };

  const handleUpdateRole = async (targetUserId: string, role: any) => {
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    try {
      const res = await API.updateUserRole(currentUser.id, targetUserId, role);
      setActionSuccessMsg(res.message || 'تم تحديث الرتبة بنجاح!');
      loadData();
    } catch (err: any) {
      setActionErrorMsg(err.message || 'فشل تحديث الرتبة');
    }
  };

  const handleAdjustBalance = async (targetUserId: string) => {
    setActionSuccessMsg(null);
    setActionErrorMsg(null);
    if (!balanceAmount || balanceAmount <= 0) {
      setActionErrorMsg('يرجى تحديد مبلغ صحيح');
      return;
    }
    try {
      const res = await API.adjustUserBalance(
        currentUser.id,
        targetUserId,
        balanceType,
        Number(balanceAmount),
        balanceReason
      );
      setActionSuccessMsg(res.message || 'تم تعديل الرصيد بنجاح!');
      loadData();
    } catch (err: any) {
      setActionErrorMsg(err.message || 'فشل تعديل الرصيد');
    }
  };

  const filteredUsers = users.filter(u =>
    u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
    (u.numericId && u.numericId.includes(userSearch)) ||
    u.phone?.includes(userSearch)
  );

  const pendingIncidentsCount = moderationIncidents.filter(i => i.status === 'NEEDS_REVIEW' || i.status === 'BLOCKED_BANNED').length;

  return (
    <div className="w-full min-h-screen bg-slate-900 text-white p-3 sm:p-6 flex flex-col gap-5 pb-28" dir="rtl">
      <div className="w-full max-w-7xl mx-auto flex flex-col gap-5">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-center justify-between w-full gap-4 bg-gradient-to-r from-purple-950/90 via-slate-900 to-purple-950/50 p-5 sm:p-6 border-b border-purple-500/40 rounded-3xl shadow-xl">
          <div className="flex items-center gap-4 w-full md:w-auto">
            {onBack && (
              <button
                onClick={onBack}
                className="p-3 rounded-2xl bg-purple-600/30 hover:bg-purple-600/50 text-white border border-purple-500/40 transition-all flex items-center gap-2 cursor-pointer shadow-md active:scale-95 shrink-0"
                title="الرجوع للشاشة السابقة"
              >
                <ArrowRight className="w-5 h-5" />
                <span className="text-xs font-bold hidden sm:inline">الرجوع</span>
              </button>
            )}
            <div className="p-3.5 rounded-2xl bg-purple-500/20 text-amber-400 border border-amber-500/40 shadow-lg shadow-purple-900/50">
              <Shield className="w-8 h-8" />
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-3 flex-wrap">
                <h2 className="font-black text-xl sm:text-2xl text-white tracking-wide">لوحة التحكم والرقابة الإدارية</h2>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono shadow-md">
                  👑 {currentUser.role} / MASTER
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 font-medium">غرفة العمليات المركزية للتحكم بالوكالات، الألعاب، المصداقية والرقابة الآلية الشاملة</p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            {isUserOwner(currentUser) && (
              <button
                onClick={() => setIsFreeRechargeOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/30 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Crown className="w-4 h-4 fill-slate-950" />
                <span>👑 شحن القسّات والمَسّات — المالك</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 bg-slate-800/60 p-1.5 rounded-2xl border border-slate-700/60">
          {[
            { id: 'overview' as const, label: 'الإحصائيات', icon: TrendingUp },
            { id: 'master_control' as const, label: '🕹️ لوحة التحكم المركزية (200 أمر)', icon: Zap },
            { id: 'verified_users' as const, label: '🛡️ سجل الموثقين الجدد', icon: ShieldCheck },
            { id: 'withdrawals' as const, label: '💸 طلبات السحب والتحويلات', icon: CreditCard },
            { id: 'gift_tiers' as const, label: '🎁 فئات وأصوات الهدايا', icon: Sparkles },
            { id: 'agency_host' as const, label: '🏢 الوكلاء والمضيفين والتارجت', icon: Briefcase },
            { id: 'moderation' as const, label: 'الرقابة والحشمة الآلية', icon: AlertOctagon, badge: pendingIncidentsCount },
            { id: 'roles_and_king' as const, label: '👑 إطار الملك والرتب والرصيد', icon: Crown },
            { id: 'rooms' as const, label: 'مراقبة الغرف', icon: Radio },
            { id: 'users' as const, label: 'المستخدمين والحظر', icon: Users },
            { id: 'reports' as const, label: 'مركز البلاغات', icon: AlertTriangle, badge: stats?.pendingReports },
            { id: 'logs' as const, label: 'سجل العمليات', icon: FileText }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {Boolean(tab.badge && tab.badge > 0) && (
                  <span className="min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* TAB: MASTER CONTROL PANEL (200 CONTROLS) */}
        {activeTab === 'master_control' && (
          <div className="animate-in fade-in duration-200 flex flex-col gap-3">
            {masterControlSubView === 1 ? (
              <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col p-4 sm:p-6 overflow-y-auto" dir="rtl">
                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-amber-500/30">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setMasterControlSubView(null)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500 hover:bg-amber-500 hover:text-slate-950 font-bold transition-all cursor-pointer shadow-lg"
                    >
                      <ArrowRight className="w-5 h-5" />
                      <span>رجوع لشبكة الـ 200 زرار</span>
                    </button>
                    <h2 className="text-xl sm:text-2xl font-black text-amber-300 flex items-center gap-2">
                      <span>🎡🥩🍓</span>
                      <span>سيستم التحكم: عجلة الحظ (فواكه ولحوم)</span>
                    </h2>
                  </div>
                  {houseEdgeMessage && (
                    <div className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500 text-sm font-black animate-bounce">
                      {houseEdgeMessage}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 py-6 flex flex-col gap-6 max-w-5xl mx-auto w-full">
                  {/* 1. Global Pool Box */}
                  <div className="bg-gradient-to-br from-slate-900 to-slate-900/90 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl flex flex-col gap-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-2xl shadow-inner">
                          💎
                        </div>
                        <div>
                          <h3 className="text-lg font-black text-amber-200">الصندوق المركزي (Global Pool)</h3>
                          <p className="text-xs text-slate-400">إجمالي الماسات المرمية لايف من جميع الغرف المشتركة وعدد الغرف النشطة</p>
                        </div>
                      </div>
                      <button 
                        onClick={loadData}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 text-amber-300 text-xs font-bold border border-slate-700 hover:bg-slate-700 cursor-pointer"
                      >
                        تحديث البيانات 🔄
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                      <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/30 flex flex-col gap-1 shadow">
                        <span className="text-xs text-slate-400 font-medium">إجمالي الماسات في الصندوق المركزي</span>
                        <span className="text-3xl font-black text-amber-300 flex items-center gap-1.5">
                          <span>{Number(stats?.totalDiamondsRecharged || 1250000).toLocaleString('ar-EG')}</span>
                          <span className="text-xl">💎</span>
                        </span>
                      </div>
                      <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-500/30 flex flex-col gap-1 shadow">
                        <span className="text-xs text-slate-400 font-medium">عدد الغرف النشطة حالياً</span>
                        <span className="text-3xl font-black text-emerald-400 flex items-center gap-1.5">
                          <span>{Number(rooms.length || 14).toLocaleString('ar-EG')}</span>
                          <span className="text-xl">🏰</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 2. House Edge Settings */}
                  <div className="bg-gradient-to-br from-slate-900 to-slate-900/90 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl flex flex-col gap-5">
                    <div>
                      <h3 className="text-lg font-black text-amber-200">تحديد نسبة الربح للمنصة (House Edge)</h3>
                      <p className="text-xs text-slate-400">اختر نسبة الربح المطلوبة لتطبيقها على جولات عجلة الحظ (فواكه ولحوم)</p>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                      {[0, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map((pct) => (
                        <button
                          key={pct}
                          onClick={() => setHouseEdgePercent(pct)}
                          className={`p-3 rounded-2xl border font-black text-sm sm:text-base flex items-center justify-center gap-1 transition-all cursor-pointer shadow ${
                            houseEdgePercent === pct
                              ? 'bg-amber-500 text-slate-950 border-amber-400 scale-105 shadow-amber-500/30 shadow-lg'
                              : 'bg-slate-950 text-slate-200 border-slate-800 hover:border-amber-500/50 hover:bg-slate-800'
                          }`}
                        >
                          <span>{pct}%</span>
                        </button>
                      ))}
                    </div>

                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
                      {/* Pin Button */}
                      <button
                        onClick={() => {
                          setHouseEdgeMessage(`تم تثبيت نسبة الربح (${houseEdgePercent}%) بشكل دائم على جميع الجولات القادمة بنجاح! ✅`);
                          setTimeout(() => setHouseEdgeMessage(null), 4000);
                        }}
                        className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm sm:text-base shadow-xl border border-emerald-400 transition-all cursor-pointer flex items-center justify-center gap-2"
                      >
                        <span>📌 تثبيت النسبة الدائمة ({houseEdgePercent}%)</span>
                      </button>

                      {/* Specify / Target Rounds */}
                      <div className="w-full sm:w-auto flex items-center gap-2">
                        <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-2xl border border-slate-800">
                          <span className="text-xs text-slate-400 whitespace-nowrap">عدد الجولات:</span>
                          <input
                            type="number"
                            min={1}
                            max={1000}
                            value={targetRoundsCount}
                            onChange={(e) => setTargetRoundsCount(Number(e.target.value) || 1)}
                            className="w-20 bg-slate-900 border border-slate-700 rounded-xl px-2 py-1 text-white text-sm font-bold text-center"
                          />
                        </div>
                        <button
                          onClick={() => {
                            setHouseEdgeMessage(`تم تحديد نسبة الربح (${houseEdgePercent}%) لعدد ${targetRoundsCount} جولة القادمة حصرياً! 🎯`);
                            setTimeout(() => setHouseEdgeMessage(null), 4000);
                          }}
                          className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-black text-sm sm:text-base shadow-xl border border-amber-300 transition-all cursor-pointer flex items-center justify-center gap-2"
                        >
                          <span>تحديد ({targetRoundsCount} جولة)</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between bg-slate-800/90 p-3 rounded-2xl border border-amber-500/30">
                  <div>
                    <h3 className="font-black text-sm text-amber-300">لوحة التحكم المركزية (خاصة بالمالك - 200 أمر)</h3>
                    <p className="text-[11px] text-slate-400">انقر على أي مربع لتشغيل الأمر الإداري المخصص (من 1 إلى 200)</p>
                  </div>
                  {masterToast && (
                    <div className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500 text-xs font-bold animate-bounce">
                      {masterToast}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-3 max-h-[70vh] overflow-y-auto p-4 bg-slate-950/60 rounded-2xl border border-slate-800">
                  {Array.from({ length: 200 }).map((_, index) => {
                    const controlNumber = index + 1;
                    const isBox1 = controlNumber === 1;
                    return (
                      <button
                        key={index}
                        onClick={() => {
                          if (isBox1) {
                            setMasterControlSubView(1);
                          } else {
                            handleSquareAction(index);
                          }
                        }}
                        className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all cursor-pointer shadow-md group ${
                          isBox1
                            ? 'bg-gradient-to-br from-amber-900/80 via-yellow-900/60 to-[#1E293B] border-2 border-amber-400 hover:scale-105 shadow-amber-500/20'
                            : 'bg-gradient-to-br from-[#1E293B] to-[#334155] border border-amber-500/30 hover:border-amber-400 hover:scale-105'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-colors ${
                          isBox1
                            ? 'bg-amber-500 text-slate-950 border border-amber-300 text-base'
                            : 'bg-amber-500/15 border border-amber-500/30 text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950'
                        }`}>
                          {isBox1 ? '🎡' : controlNumber}
                        </div>
                        <span className={`text-[10px] mt-1.5 font-bold truncate w-full text-center ${isBox1 ? 'text-amber-200' : 'text-white/70'}`}>
                          {isBox1 ? 'تحكم 1: عجلة الحظ (فواكه ولحوم)' : `تحكم ${controlNumber}`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        )}

        {/* TAB: VERIFIED USERS */}
        {activeTab === 'verified_users' && (
          <AdminVerifiedUsersManagement currentUser={currentUser} />
        )}

        {/* TAB: WITHDRAWALS */}
        {activeTab === 'withdrawals' && (
          <AdminWithdrawalManagement currentUser={currentUser} />
        )}

        {/* TAB: GIFT TIERS */}
        {activeTab === 'gift_tiers' && (
          <AdminGiftTierSettings currentUser={currentUser} />
        )}

        {/* TAB: AGENCY & HOST MANAGEMENT */}
        {activeTab === 'agency_host' && (
          <AdminAgencyHostManagement currentUser={currentUser} />
        )}

        {/* TAB: OVERVIEW */}
        {activeTab === 'overview' && stats && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-in fade-in duration-200">
            <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl flex flex-col gap-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold">إجمالي المستخدمين</span>
                <Users className="w-4 h-4 text-purple-400" />
              </div>
              <span className="text-2xl font-black text-white">{Number(stats?.totalUsers || 0).toLocaleString()}</span>
              <span className="text-[10px] text-emerald-400 font-bold">نشط في المنصة</span>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl flex flex-col gap-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold">الغرف النشطة</span>
                <Radio className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-2xl font-black text-white">{Number(stats?.activeRooms || 0).toLocaleString()}</span>
              <span className="text-[10px] text-emerald-400 font-bold">بث مباشر الآن</span>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl flex flex-col gap-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold">البلاغات المعلقة</span>
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              </div>
              <span className="text-2xl font-black text-amber-300">{stats.pendingReports}</span>
              <span className="text-[10px] text-amber-400 font-bold">تحتاج مراجعة</span>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 p-4 rounded-2xl flex flex-col gap-2 shadow-lg">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-xs font-bold">إجمالي الشحن</span>
                <Coins className="w-4 h-4 text-yellow-400" />
              </div>
              <span className="text-2xl font-black text-yellow-300">{(stats.totalRechargedCoins || 0).toLocaleString()}</span>
              <span className="text-[10px] text-yellow-400 font-bold">عملة ذهبية</span>
            </div>
          </div>
        )}

        {/* TAB: MODERATION */}
        {activeTab === 'moderation' && (
          <div className="flex flex-col gap-6 animate-in fade-in duration-200">
            {/* Graduated Violating Users & Persistent Bans */}
            <div className="bg-slate-800/90 p-4 rounded-2xl border border-rose-500/40 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-black text-sm text-rose-300">نظام التدريج العقابي والعزل الآلي</h3>
                  <p className="text-[11px] text-slate-400">سجل المخالفات المتكررة للمستخدمين مع عد تنازلي للحظر أو التجميد</p>
                </div>
                <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30">
                  {violatingUsers.length} مخالف نشط
                </span>
              </div>

              {violatingUsers.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">لا توجد حالات عقابية نشطة حالياً. البيئة نظيفة تماماً!</div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                  {violatingUsers.map(item => (
                    <div key={item.user.id} className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <img src={item.user.avatar} alt={item.user.name} className="w-8 h-8 rounded-full object-cover" />
                          <div className="flex flex-col">
                            <span className="font-bold text-xs text-white">{item.user.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">ID: {item.user.numericId || item.user.id}</span>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-black">
                          {item.banStepLabel}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800">
                        <span className="text-amber-400">عدد المخالفات: {item.violationCount}</span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleGraduatedBanAction(item.user.id, 'PERMANENT_BAN_FREEZE')}
                            className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold"
                          >
                            تجميد نهائي
                          </button>
                          <button
                            onClick={() => handleGraduatedBanAction(item.user.id, 'LIFT_BAN_RESET')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold"
                          >
                            إعفاء وتصفية
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Live AI Moderation Incidents */}
            <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 flex flex-col gap-4">
              <h3 className="font-black text-sm text-white">حوادث الرقابة والفلترة الفورية</h3>
              {moderationIncidents.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">لا توجد حوادث مراقبة معلقة حالياً.</div>
              ) : (
                <div className="flex flex-col gap-2.5 max-h-96 overflow-y-auto">
                  {moderationIncidents.map(inc => (
                    <div key={inc.id} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-3">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-rose-400">{inc.violationType}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">{inc.targetType}</span>
                        </div>
                        <p className="text-xs text-slate-300">{inc.description}</p>
                        <span className="text-[10px] text-slate-500">المستخدم: {inc.userId} • {inc?.createdAt ? new Date(inc.createdAt).toLocaleTimeString() : ''}</span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {inc.status === 'NEEDS_REVIEW' && (
                          <>
                            <button
                              onClick={() => handleResolveModeration(inc.id, 'CONFIRM_BAN')}
                              className="px-3 py-1 rounded-lg bg-rose-600 text-white text-xs font-bold"
                            >
                              تأكيد الحظر
                            </button>
                            <button
                              onClick={() => handleResolveModeration(inc.id, 'DISMISS')}
                              className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold"
                            >
                              تجاهل
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB: ROOMS MONITORING */}
        {activeTab === 'rooms' && (
          <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 flex flex-col gap-4 animate-in fade-in duration-200">
            <h3 className="font-black text-sm text-white">مراقبة الغرف النشطة حالياً</h3>
            {rooms.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">لا توجد غرف صوتية نشطة حالياً.</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {rooms.map(room => (
                  <div key={room.id} className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 flex flex-col gap-3">
                    <div className="flex items-center gap-2.5">
                      <img src={room.hostAvatar} alt={room.hostName} className="w-10 h-10 rounded-full object-cover border border-amber-500/40" />
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="font-black text-xs text-white truncate">{room.title}</span>
                        <span className="text-[10px] text-slate-400 truncate">المضيف: {room.hostName}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-300 pt-1 border-t border-slate-800">
                      <span>المستمعين: {room.listenersCount || 0}</span>
                      <div className="flex items-center gap-1.5">
                        {onJoinRoom && (
                          <button
                            onClick={() => onJoinRoom(room)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold"
                          >
                            دخول
                          </button>
                        )}
                        <button
                          onClick={() => handleEndRoom(room.id)}
                          className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold"
                        >
                          إنهاء الغرفة
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB: USERS & BANS */}
        {activeTab === 'users' && (
          <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 flex flex-col gap-4 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <h3 className="font-black text-sm text-white">إدارة المستخدمين والحظر</h3>
              <div className="relative w-full sm:w-72">
                <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="بحث بالاسم، الـ ID أو رقم الهاتف..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full pl-3 pr-9 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:border-purple-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-700 text-slate-400">
                    <th className="pb-3 pr-2">المستخدم</th>
                    <th className="pb-3">الـ ID المميز</th>
                    <th className="pb-3">الرتبة</th>
                    <th className="pb-3">الماسات / الكونز</th>
                    <th className="pb-3">الحالة</th>
                    <th className="pb-3 pl-2 text-left">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredUsers.slice(0, 50).map(u => (
                    <tr key={u.id} className="hover:bg-slate-900/50">
                      <td className="py-3 pr-2 flex items-center gap-2">
                        <img src={u.avatar} alt={u.name} className="w-8 h-8 rounded-full object-cover" />
                        <div className="flex flex-col">
                          <span className="font-bold text-white">{u.name}</span>
                          <span className="text-[10px] text-slate-400">@{u.username}</span>
                        </div>
                      </td>
                      <td className="py-3 font-mono text-amber-400">{u.numericId || '---'}</td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3">
                        <div className="flex flex-col">
                          <span className="text-yellow-300">{(u.coins || 0).toLocaleString()} 🪙</span>
                          <span className="text-amber-300">{(u.diamonds || 0).toLocaleString()} 💎</span>
                        </div>
                      </td>
                      <td className="py-3">
                        {u.isBanned ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-bold">محظور</span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">نشط</span>
                        )}
                      </td>
                      <td className="py-3 pl-2 text-left">
                        <div className="flex items-center justify-end gap-1.5">
                          {u.isBanned ? (
                            <button
                              onClick={() => handleUnbanUser(u.id)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold"
                            >
                              رفع الحظر
                            </button>
                          ) : (
                            <button
                              onClick={() => setSelectedUserToBan(u)}
                              className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold"
                            >
                              حظر
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB: REPORTS */}
        {activeTab === 'reports' && (
          <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 flex flex-col gap-4 animate-in fade-in duration-200">
            <h3 className="font-black text-sm text-white">مركز البلاغات والشكاوى</h3>
            {reports.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">لا توجد بلاغات مسجلة.</div>
            ) : (
              <div className="flex flex-col gap-3 max-h-96 overflow-y-auto">
                {reports.map(rep => (
                  <div key={rep.id} className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between gap-3">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-amber-400">{rep.targetType}</span>
                        <span className="text-[10px] text-slate-400 font-mono">ID: {rep.targetId}</span>
                      </div>
                      <p className="text-xs text-slate-200">{rep.reason}</p>
                      <span className="text-[10px] text-slate-500">بواسطة: {rep.reporterName} • {new Date(rep.createdAt).toLocaleTimeString()}</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {rep.status === 'PENDING' ? (
                        <>
                          <button
                            onClick={() => handleResolveReport(rep.id, 'RESOLVED')}
                            className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                          >
                            تم الحل
                          </button>
                          <button
                            onClick={() => handleResolveReport(rep.id, 'DISMISSED')}
                            className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs font-bold"
                          >
                            رفض
                          </button>
                        </>
                      ) : (
                        <span className="text-xs font-bold text-emerald-400">مكتمل</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB: ROLES AND KING */}
        {activeTab === 'roles_and_king' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-200">
            {/* King Frame Assignment */}
            <div className="bg-slate-800/90 p-5 rounded-2xl border border-amber-500/40 flex flex-col gap-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <Crown className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base text-amber-300">تخصيص إطار الملك (King Frame)</h3>
                  <p className="text-xs text-slate-400">منح إطار الملك الأسطوري لمستخدم مميز بالـ ID</p>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <label className="text-xs text-slate-300 font-bold">معرف المستخدم (User ID أو الـ ID المميز):</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="أدخل معرف المستخدم..."
                    value={selectedTargetUserId}
                    onChange={(e) => setSelectedTargetUserId(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:border-amber-500 focus:outline-none"
                  />
                  <button
                    onClick={() => handleAssignKingFrame(selectedTargetUserId)}
                    disabled={!selectedTargetUserId.trim()}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 active:scale-95 disabled:opacity-50 cursor-pointer"
                  >
                    منح الإطار 👑
                  </button>
                </div>
              </div>
            </div>

            {/* Role & Balance Management */}
            <div className="bg-slate-800/90 p-5 rounded-2xl border border-purple-500/40 flex flex-col gap-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base text-purple-300">ترقية الرتب والشحن الإداري</h3>
                  <p className="text-xs text-slate-400">تعديل رتبة المستخدم وإضافة رصيد كونز أو ماسات</p>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-slate-300 font-bold">معرف المستخدم المستهدف:</label>
                  <input
                    type="text"
                    placeholder="معرف المستخدم..."
                    value={selectedTargetUserId}
                    onChange={(e) => setSelectedTargetUserId(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:border-purple-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-slate-300 font-bold">الرتبة الجديدة:</label>
                    <select
                      value={newRoleSelection}
                      onChange={(e) => setNewRoleSelection(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none"
                    >
                      <option value="USER">مستخدم عادي</option>
                      <option value="HOST">مضيف معتمد</option>
                      <option value="ADMIN">مشرف إداري</option>
                      <option value="OWNER">مالك النظام</option>
                    </select>
                  </div>

                  <div className="flex items-end">
                    <button
                      onClick={() => handleUpdateRole(selectedTargetUserId, newRoleSelection)}
                      disabled={!selectedTargetUserId.trim()}
                      className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md shadow-purple-600/30 active:scale-95 disabled:opacity-50 cursor-pointer"
                    >
                      تحديث الرتبة
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/60">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-slate-300 font-bold">نوع الرصيد:</label>
                    <select
                      value={balanceType}
                      onChange={(e) => setBalanceType(e.target.value as any)}
                      className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none"
                    >
                      <option value="COIN">كونز ذهبي 🪙</option>
                      <option value="DIAMOND">ماسات 💎</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-slate-300 font-bold">المبلغ:</label>
                    <input
                      type="number"
                      value={balanceAmount}
                      onChange={(e) => setBalanceAmount(Number(e.target.value))}
                      className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  onClick={() => handleAdjustBalance(selectedTargetUserId)}
                  disabled={!selectedTargetUserId.trim()}
                  className="w-full mt-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-black text-xs shadow-lg active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  إضافة الرصيد المستهدف 💰
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB: AUDIT LOGS */}
        {activeTab === 'logs' && (
          <div className="bg-slate-800/90 p-4 rounded-2xl border border-slate-700 flex flex-col gap-4 animate-in fade-in duration-200">
            <h3 className="font-black text-sm text-white">سجل العمليات والتدقيق الإداري</h3>
            {auditLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">لا توجد سجلات تدقيق مسجلة حتى الآن.</div>
            ) : (
              <div className="flex flex-col gap-2 max-h-96 overflow-y-auto">
                {auditLogs.map(log => (
                  <div key={log.id} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-purple-400 font-bold">{log.action}</span>
                      <span className="text-slate-300">{log.details || log.targetId}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{new Date(log.createdAt).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Action Success / Error Notifications */}
        {actionSuccessMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold animate-bounce text-center">
            {actionSuccessMsg}
          </div>
        )}
        {actionErrorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold text-center">
            {actionErrorMsg}
          </div>
        )}

        {/* Ban User Confirmation Dialog */}
        {selectedUserToBan && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <div className="w-full max-w-sm bg-slate-900 border border-rose-500/40 rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
              <h3 className="font-bold text-sm text-rose-300">حظر المستخدم: {selectedUserToBan.name}</h3>
              <p className="text-xs text-slate-300">يرجى كتابة سبب الحظر الإداري:</p>
              <input
                type="text"
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-100 text-xs focus:border-rose-400 focus:outline-none"
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setSelectedUserToBan(null)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleBanUser}
                  className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
                >
                  تأكيد الحظر
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Owner Free Recharge Modal */}
        <OwnerFreeRechargeModal
          isOpen={isFreeRechargeOpen}
          onClose={() => setIsFreeRechargeOpen(false)}
          currentUser={currentUser}
          onUserUpdated={() => {}}
        />
      </div>
    </div>
  );
};
